/**
 * Navigation Bar Component
 * 
 * Redesigned from scratch per PRD Section 6.3.1 and Vercel Design Guidelines.
 * Features:
 * - REGA sandbox badge
 * - Arabic navigation links
 * - Language toggle (Arabic/English)
 * - RTL-aware hamburger menu
 * - Keyboard navigation support
 * - Accessible focus states
 * 
 * Implements Vercel Design Guidelines:
 * - Keyboard navigation (Tab, Shift+Tab, Enter, Space, Esc)
 * - Clear focus rings (:focus-visible)
 * - Semantic HTML (<nav>, <header>)
 * - Links are links (<a> tags)
 * - Touch targets ≥44x44px
 * 
 * @fileoverview Main navigation component with RTL support
 */

import { Component, HostListener, signal, effect, inject, viewChild } from '@angular/core';
import { NgClass, CommonModule } from '@angular/common';
import { LanguageService } from '../../services/language.service';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faBars, faX, faGlobe } from '@fortawesome/free-solid-svg-icons';
import { ZohoFormModal } from '../zoho-form-modal/zoho-form-modal';

@Component({
  selector: 'app-navbar',
  imports: [NgClass, CommonModule, FontAwesomeModule, ZohoFormModal],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Reference to Zoho form modal (optional to prevent errors if not found)
   */
  private readonly zohoModal = viewChild(ZohoFormModal);

  /**
   * Navigation links per PRD 6.3.1 (Arabic-first)
   */
  navLinks = [
    { nameAr: 'كيف يشتغل', nameEn: 'How It Works', href: '#how-it-works' },
    { nameAr: 'ليش CapNest', nameEn: 'Why CapNest', href: '#benefits' },
    { nameAr: 'العقارات', nameEn: 'Properties', href: '#properties' },
    { nameAr: 'الأسئلة الشائعة', nameEn: 'FAQ', href: '#faq' },
  ];

  /**
   * Scroll state signal
   */
  isScrolled = signal<boolean>(false);

  /**
   * Mobile menu open state signal
   */
  isMobileMenuOpen = signal<boolean>(false);

  /**
   * Current language (computed from service)
   */
  readonly currentLang = signal<'ar' | 'en'>('ar');

  /**
   * Icons
   */
  readonly menuIcon = faBars;
  readonly closeIcon = faX;
  readonly globeIcon = faGlobe;

  constructor() {
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:73',message:'Navbar constructor entry',data:{hasLanguageService:!!this.languageService},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
    // #endregion
    
    // Sync with language service
    try {
      effect(() => {
        const lang = this.languageService.getCurrentLanguage();
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:79',message:'Language effect executed',data:{lang,serviceAvailable:!!this.languageService},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
        // #endregion
        this.currentLang.set(lang);
      });
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:85',message:'Navbar constructor exit',data:{effectCreated:true},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
      // #endregion
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:88',message:'Navbar constructor error',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
      // #endregion
      console.error('Navbar initialization error:', error);
    }
  }

  /**
   * Window scroll listener - updates navbar appearance
   * Per Vercel Guidelines: Respect scroll positions
   */
  @HostListener('window:scroll')
  onWindowScroll(): void {
    this.isScrolled.set(window.scrollY > 50);
  }

  /**
   * Toggle mobile menu
   * Per Vercel Guidelines: Keyboard accessible, focus management
   */
  toggleMobileMenu(): void {
    this.isMobileMenuOpen.update((open) => !open);
  }

  /**
   * Close mobile menu
   */
  closeMobileMenu(): void {
    this.isMobileMenuOpen.set(false);
  }

  /**
   * Toggle language (Arabic/English)
   * Per Vercel Guidelines: Locale-aware functionality
   */
  toggleLanguage(): void {
    this.languageService.toggleLanguage();
  }

  /**
   * Get navigation link text based on current language
   * @param link - Navigation link object
   * @returns Display text in current language
   */
  getLinkText(link: { nameAr: string; nameEn: string }): string {
    return this.currentLang() === 'ar' ? link.nameAr : link.nameEn;
  }

  /**
   * Handle keyboard navigation for mobile menu
   * Per Vercel Guidelines: Esc key closes modals/menus
   */
  @HostListener('window:keydown', ['$event'])
  handleKeyboard(event: KeyboardEvent): void {
    if (event.key === 'Escape' && this.isMobileMenuOpen()) {
      this.closeMobileMenu();
    }
  }

  /**
   * Check if current direction is RTL
   * @returns true if RTL
   */
  get isRTL(): boolean {
    return this.languageService.isRTL();
  }

  /**
   * Open waiting list modal
   */
  openWaitingListModal(): void {
    try {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:167',message:'openWaitingListModal called',data:{hasZohoModal:!!this.zohoModal},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
      // #endregion
      
      const modal = this.zohoModal();
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:171',message:'Modal retrieved from viewChild',data:{hasModal:!!modal,hasOpenModal:typeof modal?.openModal === 'function'},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
      // #endregion
      
      if (modal && typeof modal.openModal === 'function') {
        modal.openModal();
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:176',message:'Modal openModal called successfully',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
      }
      
      // Always dispatch custom event as backup to ensure modal opens
      // This ensures the modal opens even if viewChild fails
      if (typeof window !== 'undefined') {
        // Dispatch immediately
        window.dispatchEvent(new CustomEvent('open-zoho-modal'));
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:183',message:'Dispatched custom event as backup',data:{hasModal:!!modal},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
        
        // Also try DOM fallback after a short delay
        setTimeout(() => {
          const modalElement = document.querySelector('app-zoho-form-modal');
          if (modalElement && !modal) {
            // Try to access Angular component instance
            const modalComponent = (modalElement as any).__ngContext__?.[8]?.[0];
            if (modalComponent && typeof modalComponent.openModal === 'function') {
              modalComponent.openModal();
              // #region agent log
              fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:193',message:'Modal opened via DOM fallback',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
              // #endregion
            }
          }
        }, 50);
      }
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'navbar.ts:203',message:'Error opening waiting list modal',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
      // #endregion
      console.error('Error opening waiting list modal from navbar:', error);
    }
  }
}
