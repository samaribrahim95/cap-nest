/**
 * Language Service
 * 
 * Manages language switching between Arabic and English,
 * handles RTL/LTR direction switching, and content translation.
 * 
 * Implements Vercel Design Guidelines for locale-aware functionality.
 * 
 * @fileoverview Language and direction management service
 */

import { Injectable, signal, computed, effect } from '@angular/core';
import { setDirection, isRTL } from '../utils/rtl-utils';

export type Language = 'ar' | 'en';

/**
 * Language configuration interface
 */
export interface LanguageConfig {
  code: Language;
  name: string;
  nativeName: string;
  direction: 'rtl' | 'ltr';
}

/**
 * Available languages configuration
 */
const LANGUAGES: Record<Language, LanguageConfig> = {
  ar: {
    code: 'ar',
    name: 'Arabic',
    nativeName: 'العربية',
    direction: 'rtl',
  },
  en: {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    direction: 'ltr',
  },
};

@Injectable({
  providedIn: 'root',
})
export class LanguageService {
  /**
   * Current language signal (default: Arabic per PRD)
   */
  private readonly currentLanguage = signal<Language>('ar');

  /**
   * Current language configuration (computed)
   */
  readonly currentLangConfig = computed(() => LANGUAGES[this.currentLanguage()]);

  /**
   * Is RTL direction (computed)
   */
  readonly isRTL = computed(() => this.currentLangConfig().direction === 'rtl');

  /**
   * Available languages
   */
  readonly availableLanguages = Object.values(LANGUAGES);

  constructor() {
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:69',message:'LanguageService constructor entry',data:{hasDocument:typeof document !== 'undefined'},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
    // #endregion
    
    // Initialize direction on service creation
    try {
      this.initializeDirection();
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:75',message:'Direction initialized',data:{currentLang:this.currentLanguage()},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
      // #endregion

      // Effect: Update document direction when language changes
      effect(() => {
        const config = this.currentLangConfig();
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:81',message:'Language effect executed',data:{direction:config.direction,code:config.code},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
        // #endregion
        setDirection(config.direction);
        
        // Update HTML lang attribute
        if (typeof document !== 'undefined') {
          document.documentElement.lang = config.code;
          // #region agent log
          fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:87',message:'Document lang updated',data:{lang:document.documentElement.lang,dir:document.documentElement.dir},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
          // #endregion
        }
      });
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:92',message:'LanguageService constructor exit',data:{effectCreated:true},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
      // #endregion
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:95',message:'LanguageService constructor error',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'B'})}).catch(()=>{});
      // #endregion
      console.error('LanguageService initialization error:', error);
    }
  }

  /**
   * Initialize direction from browser or default to Arabic
   * Per PRD: Arabic-first approach - default to Arabic unless explicitly English preference
   */
  private initializeDirection(): void {
    try {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:111',message:'Initializing direction',data:{hasNavigator:typeof navigator !== 'undefined'},timestamp:Date.now(),sessionId:'debug-session',runId:'run2',hypothesisId:'B'})}).catch(()=>{});
      // #endregion
      
      // Per PRD: Arabic-first - only use English if browser explicitly prefers English
      // Check browser language preference
      if (typeof navigator !== 'undefined' && navigator.languages) {
        const browserLang = navigator.languages[0]?.substring(0, 2);
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:118',message:'Browser language detected',data:{browserLang,allLanguages:navigator.languages},timestamp:Date.now(),sessionId:'debug-session',runId:'run2',hypothesisId:'B'})}).catch(()=>{});
        // #endregion
        
        // Only use English if browser explicitly prefers English (not just any non-Arabic language)
        // Default to Arabic per PRD Arabic-first requirement
        if (browserLang === 'en') {
          this.setLanguage('en');
          return;
        }
        // For any other language (including Arabic), default to Arabic per PRD
      }

      // Default to Arabic per PRD requirements (Arabic-first approach)
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:130',message:'Defaulting to Arabic',data:{reason:'PRD Arabic-first requirement'},timestamp:Date.now(),sessionId:'debug-session',runId:'run2',hypothesisId:'B'})}).catch(()=>{});
      // #endregion
      this.setLanguage('ar');
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'language.service.ts:133',message:'LanguageService init error',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run2',hypothesisId:'B'})}).catch(()=>{});
      // #endregion
      console.error('LanguageService: Failed to initialize direction:', error);
      // Fallback to Arabic on error
      this.setLanguage('ar');
    }
  }

  /**
   * Set the current language
   * @param lang - Language code ('ar' or 'en')
   */
  setLanguage(lang: Language): void {
    try {
      // Validate input
      if (!lang || typeof lang !== 'string') {
        throw new Error(`Invalid language: ${lang} is not a valid language code`);
      }

      if (!LANGUAGES[lang]) {
        console.warn(`Language ${lang} is not supported. Defaulting to Arabic.`);
        lang = 'ar';
      }

      this.currentLanguage.set(lang);
    } catch (error) {
      console.error('LanguageService: Failed to set language:', error);
      // Fallback to Arabic on error
      this.currentLanguage.set('ar');
    }
  }

  /**
   * Get current language code
   * @returns Current language code
   */
  getCurrentLanguage(): Language {
    return this.currentLanguage();
  }

  /**
   * Toggle between Arabic and English
   */
  toggleLanguage(): void {
    const newLang = this.currentLanguage() === 'ar' ? 'en' : 'ar';
    this.setLanguage(newLang);
  }

  /**
   * Get translation for a key (placeholder for future i18n implementation)
   * @param key - Translation key
   * @param params - Optional parameters for interpolation
   * @returns Translated string
   */
  translate(key: string, params?: Record<string, string>): string {
    // Placeholder implementation
    // In production, this would use Angular i18n or a translation service
    return key;
  }
}
