/**
 * Comprehensive Test Runner
 * 
 * Runs all test categories:
 * - Performance tests
 * - Accessibility tests
 * - Mobile responsiveness tests
 * - Security tests
 * - Cross-browser compatibility checks
 * 
 * @fileoverview Comprehensive test runner for all audit categories
 */

import { runAccessibilityAudit } from './accessibility-audit';
import { runMobileResponsivenessAudit } from './mobile-responsiveness-checker';
import { runSecurityAudit } from './security-audit';
import { measurePerformance } from './performance-optimizer';
import { runAutomatedAccessibilityTests, logAccessibilityTestResults } from './accessibility-automated-tests';
import { validateCSPForProduction, getCSPProductionRecommendations } from './csp-validator';

/**
 * Run all comprehensive tests
 */
export async function runComprehensiveTests(): Promise<{
  performance: any;
  accessibility: {
    keyboardAccessible: number;
    hasAriaLabels: number;
    hasFocusStyles: number;
    totalElements: number;
    automatedTests: ReturnType<typeof runAutomatedAccessibilityTests>;
  };
  mobileResponsiveness: ReturnType<typeof runMobileResponsivenessAudit>;
  security: ReturnType<typeof runSecurityAudit> & {
    cspValidation: ReturnType<typeof validateCSPForProduction>;
    cspRecommendations: ReturnType<typeof getCSPProductionRecommendations>;
  };
  timestamp: number;
}> {
  // Measure performance
  const performanceMetrics = await new Promise<any>((resolve) => {
    if (typeof window !== 'undefined' && 'performance' in window) {
      window.addEventListener('load', () => {
        setTimeout(() => {
          const perfData = window.performance.timing;
          const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
          const domContentLoaded = perfData.domContentLoadedEventEnd - perfData.navigationStart;
          const firstPaint = performance.getEntriesByType('paint').find(
            (entry) => entry.name === 'first-contentful-paint'
          );
          
          resolve({
            pageLoadTime: `${pageLoadTime}ms`,
            domContentLoaded: `${domContentLoaded}ms`,
            firstContentfulPaint: firstPaint ? `${Math.round(firstPaint.startTime)}ms` : 'N/A',
          });
        }, 0);
      });
    } else {
      resolve({ error: 'Performance API not available' });
    }
  });
  
  // Run accessibility audit
  const accessibility = runAccessibilityAudit();
  const accessibilityTests = runAutomatedAccessibilityTests();
  
  // Run mobile responsiveness audit
  const mobileResponsiveness = runMobileResponsivenessAudit();
  
  // Run security audit
  const security = runSecurityAudit();
  
  // Validate CSP for production
  const cspValidation = validateCSPForProduction();
  const cspRecommendations = getCSPProductionRecommendations();
  
  return {
    performance: performanceMetrics,
    accessibility: {
      keyboardAccessible: accessibility.keyboardAccessible,
      hasAriaLabels: accessibility.hasAriaLabels,
      hasFocusStyles: accessibility.hasFocusStyles,
      totalElements: accessibility.totalElements,
      automatedTests: accessibilityTests,
    },
    mobileResponsiveness,
    security: {
      csp: security.csp,
      securityHeaders: security.securityHeaders,
      iframeUrlValid: security.iframeUrlValid,
      cspValidation,
      cspRecommendations,
    },
    timestamp: Date.now(),
  };
}

/**
 * Log comprehensive test results
 */
export function logComprehensiveTestResults(results: Awaited<ReturnType<typeof runComprehensiveTests>>): void {
  if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
    console.group('🧪 Comprehensive Test Results');
    console.log('Performance:', results.performance);
    console.log('Accessibility:', results.accessibility);
    console.log('Accessibility Automated Tests:', results.accessibility.automatedTests);
    console.log('Mobile Responsiveness:', results.mobileResponsiveness);
    console.log('Security:', results.security);
    console.log('CSP Validation:', results.security.cspValidation);
    if (results.security.cspValidation.issues.length > 0) {
      console.warn('CSP Issues:', results.security.cspValidation.issues);
      console.log('CSP Recommendations:', results.security.cspRecommendations);
    }
    console.groupEnd();
    
    // Also log accessibility test results separately
    logAccessibilityTestResults();
  }
}
