/**
 * Cross-Browser Polyfills
 * 
 * Provides polyfills for browser compatibility:
 * - IntersectionObserver polyfill
 * - CSS custom properties fallback
 * - RTL support fallback
 * 
 * @fileoverview Cross-browser compatibility utilities
 */

/**
 * Check if IntersectionObserver is supported
 */
export function checkIntersectionObserver(): boolean {
  return typeof window !== 'undefined' && 'IntersectionObserver' in window;
}

/**
 * Check if CSS custom properties are supported
 */
export function checkCSSVariables(): boolean {
  if (typeof window === 'undefined') return false;
  
  const supports = CSS.supports('color', 'var(--test)');
  return supports;
}

/**
 * Add RTL support fallback for older browsers
 */
export function addRTLFallback(): void {
  if (typeof document === 'undefined') return;
  
  // Check if browser supports logical properties
  const testEl = document.createElement('div');
  testEl.style.marginInlineStart = '10px';
  const supportsLogical = testEl.style.marginInlineStart === '10px';
  
  if (!supportsLogical) {
    // Add fallback styles for older browsers
    const style = document.createElement('style');
    style.textContent = `
      [dir="rtl"] {
        direction: rtl;
        text-align: right;
      }
      [dir="ltr"] {
        direction: ltr;
        text-align: left;
      }
    `;
    document.head.appendChild(style);
  }
}

/**
 * Initialize cross-browser compatibility
 */
export function initCrossBrowserSupport(): void {
  addRTLFallback();
  
  // Log compatibility status in development
  if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
    console.log('Browser Compatibility:', {
      intersectionObserver: checkIntersectionObserver() ? 'Supported' : 'Polyfill needed',
      cssVariables: checkCSSVariables() ? 'Supported' : 'Fallback needed',
    });
  }
}
