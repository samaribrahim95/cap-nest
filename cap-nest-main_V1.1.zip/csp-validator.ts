/**
 * CSP Validator Utility
 * 
 * Validates Content Security Policy configuration and checks
 * if production domains are properly configured.
 * 
 * @fileoverview CSP validation and domain checking utilities
 */

/**
 * Production domains configuration
 * Update these with your actual production domains
 */
export const PRODUCTION_DOMAINS = {
  main: 'your-production-domain.com', // Replace with actual domain
  cdn: 'cdn.your-production-domain.com', // If using CDN
  api: 'api.your-production-domain.com', // If using API
  analytics: 'www.google-analytics.com',
  zoho: 'zfrmz.sa',
  fonts: 'fonts.googleapis.com',
  fontsStatic: 'fonts.gstatic.com',
};

/**
 * Check if CSP is properly configured for production domains
 */
export function validateCSPForProduction(): {
  isValid: boolean;
  issues: string[];
  recommendations: string[];
} {
  const issues: string[] = [];
  const recommendations: string[] = [];
  
  if (typeof document === 'undefined') {
    return {
      isValid: false,
      issues: ['Document not available'],
      recommendations: ['Run this check in browser environment'],
    };
  }
  
  // Check if CSP meta tag exists
  const cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
  if (!cspMeta) {
    issues.push('CSP meta tag not found in HTML');
    recommendations.push('Add CSP meta tag to index.html');
  } else {
    const cspContent = cspMeta.getAttribute('content') || '';
    
    // Check for placeholder domains
    if (cspContent.includes('your-production-domain.com')) {
      issues.push('CSP contains placeholder domain "your-production-domain.com"');
      recommendations.push('Replace placeholder with actual production domain');
    }
    
    // Check for unsafe-inline (should be minimized in production)
    if (cspContent.includes("'unsafe-inline'")) {
      recommendations.push('Consider removing unsafe-inline from script-src and style-src for better security');
      recommendations.push('Use nonces or hashes instead of unsafe-inline');
    }
    
    // Verify required directives
    const requiredDirectives = ['default-src', 'script-src', 'style-src', 'frame-src'];
    requiredDirectives.forEach(directive => {
      if (!cspContent.includes(directive)) {
        issues.push(`Missing required CSP directive: ${directive}`);
      }
    });
  }
  
  // Check HTTP headers (requires server response)
  // This will be checked via server-side validation
  
  return {
    isValid: issues.length === 0,
    issues,
    recommendations,
  };
}

/**
 * Get CSP configuration recommendations for production
 */
export function getCSPProductionRecommendations(): {
  current: string;
  recommended: string;
  changes: string[];
} {
  const currentCSP = `
    default-src 'self';
    script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://www.google-analytics.com;
    style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
    font-src 'self' https://fonts.gstatic.com;
    img-src 'self' data: https:;
    connect-src 'self' https://www.google-analytics.com https://zfrmz.sa;
    frame-src 'self' https://zfrmz.sa;
    object-src 'none';
    base-uri 'self';
    form-action 'self' https://zfrmz.sa;
  `.trim();
  
  const recommendedCSP = `
    default-src 'self' https://your-production-domain.com;
    script-src 'self' https://www.googletagmanager.com https://www.google-analytics.com;
    style-src 'self' https://fonts.googleapis.com;
    font-src 'self' https://fonts.gstatic.com;
    img-src 'self' data: https: https://your-production-domain.com;
    connect-src 'self' https://www.google-analytics.com https://zfrmz.sa https://api.your-production-domain.com;
    frame-src 'self' https://zfrmz.sa;
    object-src 'none';
    base-uri 'self';
    form-action 'self' https://zfrmz.sa;
    upgrade-insecure-requests;
  `.trim();
  
  return {
    current: currentCSP,
    recommended: recommendedCSP,
    changes: [
      "Replace 'your-production-domain.com' with actual domain",
      "Remove 'unsafe-inline' from script-src (use nonces/hashes)",
      "Remove 'unsafe-inline' from style-src (use nonces/hashes)",
      "Add 'upgrade-insecure-requests' for HTTPS enforcement",
      "Add specific production domains to each directive",
    ],
  };
}
