/**
 * CTA Section Component
 * 
 * Redesigned from scratch per PRD Section 6.3.8 and Vercel Design Guidelines.
 * Features:
 * - Green background #006C35 per PRD
 * - Arabic content
 * - Compliance footer
 * - Responsive button sizing
 * - Accessible focus states
 * 
 * @fileoverview Call-to-action section with form trigger
 */

import { Component, inject, computed, viewChild } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';
import { ZohoFormModal } from '../zoho-form-modal/zoho-form-modal';

@Component({
  selector: 'app-ctasection',
  imports: [FontAwesomeModule, ZohoFormModal],
  templateUrl: './ctasection.html',
  styleUrl: './ctasection.css',
})
export class CTASection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Icons
   */
  readonly arrowRightIcon = faArrowRight;

  /**
   * Zoho form modal reference (optional to prevent errors if not found)
   */
  private readonly zohoModal = viewChild(ZohoFormModal);

  /**
   * CTA content per PRD 6.3.8
   */
  readonly ctaContent = computed(() => {
    const lang = this.currentLang();
    return {
      headline: lang === 'ar' 
        ? 'أنت جاهز تبدأ رحلتك الاستثمارية؟'
        : 'Ready to Build Your Real Estate Portfolio?',
      subheadline: lang === 'ar'
        ? 'انضم لآلاف المستثمرين اللي يحققون دخل سلبي من خلال ملكية العقارات الجزئية. ابدأ رحلتك اليوم.'
        : 'Join thousands of investors earning passive income through fractional property ownership. Start your journey today.',
      ctaPrimary: lang === 'ar' ? 'سجل في قائمة الانتظار' : 'Join the Waiting List', // Saudi Arabic dialect for Arabic
      ctaSecondary: lang === 'ar' ? 'جدولة مكالمة' : 'Schedule a Call',
      footer: lang === 'ar'
        ? 'ما تحتاج بطاقة ائتمانية • ابدأ الاستثمار في دقايق'
        : 'No credit card required • Start investing in minutes',
    };
  });

  /**
   * Open waiting list modal
   * Tracks CTA click event in analytics
   */
  openWaitingListModal(): void {
    // Track CTA click event
    if (typeof window !== 'undefined') {
      import('../../services/analytics.service').then(module => {
        const analyticsService = new module.AnalyticsService();
        analyticsService.trackEvent('cta_click', {
          location: 'cta_section',
          language: this.currentLang(),
        });
      }).catch(() => {});
    }
    try {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'ctasection.ts:70',message:'CTA opening waiting list modal',data:{hasZohoModal:!!this.zohoModal},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      const modal = this.zohoModal();
      if (modal && typeof modal.openModal === 'function') {
        modal.openModal();
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'ctasection.ts:75',message:'CTA modal openModal called',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
      }
      
      // Always dispatch custom event as backup to ensure modal opens
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('open-zoho-modal'));
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'ctasection.ts:81',message:'Dispatched custom event as backup',data:{hasModal:!!modal},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
      }
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'ctasection.ts:84',message:'CTA error opening modal',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      console.error('Error opening waiting list modal from CTA:', error);
    }
  }
}
