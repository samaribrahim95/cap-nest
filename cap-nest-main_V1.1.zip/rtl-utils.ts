/**
 * RTL Utility Functions
 * 
 * Provides utilities for Right-to-Left (RTL) and Left-to-Right (LTR) direction handling
 * in the CapNest landing page. Supports Arabic-first design with bilingual content.
 * 
 * @fileoverview RTL/LTR direction utilities for Angular components
 */

/**
 * Gets the current text direction from the document
 * @returns 'rtl' or 'ltr'
 */
export function getCurrentDirection(): 'rtl' | 'ltr' {
  if (typeof document === 'undefined') {
    return 'rtl'; // Default to RTL for SSR
  }
  return document.documentElement.dir === 'ltr' ? 'ltr' : 'rtl';
}

/**
 * Sets the document direction
 * @param direction - 'rtl' or 'ltr'
 */
export function setDirection(direction: 'rtl' | 'ltr'): void {
  if (typeof document === 'undefined') {
    return;
  }
  document.documentElement.dir = direction;
  document.documentElement.lang = direction === 'rtl' ? 'ar' : 'en';
}

/**
 * Checks if current direction is RTL
 * @returns true if RTL, false if LTR
 */
export function isRTL(): boolean {
  return getCurrentDirection() === 'rtl';
}

/**
 * Gets the appropriate margin/padding class based on direction
 * @param rtlClass - Class to use when RTL (e.g., 'mr-4')
 * @param ltrClass - Class to use when LTR (e.g., 'ml-4')
 * @returns The appropriate class for current direction
 */
export function getDirectionalClass(rtlClass: string, ltrClass: string): string {
  return isRTL() ? rtlClass : ltrClass;
}

/**
 * Gets the appropriate text alignment class
 * @returns 'text-right' for RTL, 'text-left' for LTR
 */
export function getTextAlignClass(): string {
  return isRTL() ? 'text-right' : 'text-left';
}

/**
 * Mirrors a value based on direction (useful for transforms)
 * @param value - Numeric value to mirror
 * @returns Negative value for RTL, positive for LTR
 */
export function mirrorValue(value: number): number {
  return isRTL() ? -value : value;
}
