/**
 * Properties Section Component
 * 
 * Redesigned from scratch per PRD requirements and Vercel Design Guidelines.
 * Features:
 * - First Digishares asset display
 * - Lazy loading per Vercel guidelines
 * - Responsive grid (3 desktop, 1 mobile)
 * - Browse All link
 * - Explicit image dimensions to prevent CLS
 * 
 * @fileoverview Properties section with first asset display
 */

import { Component, inject, computed } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faLocationDot, faUsers, faArrowTrendUp } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-properties-section',
  imports: [FontAwesomeModule],
  templateUrl: './properties-section.html',
  styleUrl: './properties-section.css',
})
export class PropertiesSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Icons
   */
  readonly locationIcon = faLocationDot;
  readonly usersIcon = faUsers;
  readonly arrowTrendUpIcon = faArrowTrendUp;

  /**
   * Properties data - First Digishares asset placeholder
   */
  readonly properties = computed(() => {
    const lang = this.currentLang();
    return [
      {
        image: '/assets/imgs/property-1.jpg',
        title: lang === 'ar' ? 'العقار الأول' : 'First Property',
        location: lang === 'ar' ? 'الرياض، السعودية' : 'Riyadh, Saudi Arabia',
        price: lang === 'ar' ? '1,200,000 ريال' : 'SAR 1,200,000',
        minInvestment: lang === 'ar' ? '100 ريال' : 'SAR 100',
        funded: 72,
        investors: 148,
        returns: '12.4%',
        type: lang === 'ar' ? 'سكني' : 'Residential',
      },
    ];
  });
}
