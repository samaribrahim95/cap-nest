/**
 * Hero Section Component
 * 
 * Redesigned from scratch per PRD Section 6.3.2 and Vercel Design Guidelines.
 * Features:
 * - Arabic headline per PRD: "استثمر في العقارات السعودية من 100 ريال فقط"
 * - REGA sandbox status badge
 * - Arabic CTAs
 * - Performance-optimized (no hero image on initial load)
 * - Trust indicators
 * 
 * Implements Vercel Design Guidelines:
 * - Semantic HTML (<main>, <section>)
 * - Proper heading hierarchy (h1 → h2)
 * - Button states (hover, active, focus, disabled)
 * - Loading states with minimum duration
 * - Explicit image dimensions (prevent CLS)
 * 
 * @fileoverview Hero section with Arabic-first content
 */

import { Component, inject, signal, computed, viewChild } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faArrowRight, faPlay, faShield, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';
import { ZohoFormModal } from '../zoho-form-modal/zoho-form-modal';

@Component({
  selector: 'app-hero-section',
  imports: [FontAwesomeModule, ZohoFormModal],
  templateUrl: './hero-section.html',
  styleUrl: './hero-section.css',
})
export class HeroSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Icons
   */
  readonly arrowRightIcon = faArrowRight;
  readonly playIcon = faPlay;
  readonly shieldIcon = faShield;
  readonly checkIcon = faCheckCircle;

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Is RTL direction (computed)
   */
  readonly isRTL = computed(() => this.languageService.isRTL());

  /**
   * Zoho form modal reference (optional to prevent errors if not found)
   */
  private readonly zohoModal = viewChild(ZohoFormModal);

  /**
   * Hero content per PRD 6.3.2
   */
  readonly heroContent = {
    ar: {
      headline: 'استثمر في عقارات السعودية من 100 ريال بس',
      subheadline: 'ابدأ رحلتك الاستثمارية في عقارات السعودية بسهولة وأمان. استثمر في عقارات حقيقية من خلال منصة CapNest المنظمة من هيئة السوق المالية (REGA). من ما عندك أي أصول إلى عندك أصول في أقل من 3 دقايق (120 ثانية).',
      ctaPrimary: 'ابدأ الاستثمار الحين',
      ctaSecondary: 'شوف كيف يشتغل',
      badgeText: 'REGA Sandbox Applicant',
      trustIndicators: [
        { label: 'الحد الأدنى للاستثمار', value: '100 ريال' },
        { label: 'العائد المتوقع', value: '8-12%' },
        { label: 'حالة REGA', value: 'قيد التقييم' },
        { label: 'متوافق مع الشريعة', value: 'نعم' },
      ],
    },
    en: {
      headline: 'Invest in Saudi Real Estate from 100 SAR Only',
      subheadline: 'Start your investment journey in Saudi real estate easily and safely. Invest in real properties through CapNest platform regulated by the Capital Market Authority (REGA). From owning zero assets to owning assets in under 3 minutes (120 seconds).',
      ctaPrimary: 'Start Investing Now',
      ctaSecondary: 'Discover How It Works',
      badgeText: 'REGA Sandbox Applicant',
      trustIndicators: [
        { label: 'Minimum Investment', value: '100 SAR' },
        { label: 'Expected Yield', value: '8-12%' },
        { label: 'REGA Status', value: 'Pending' },
        { label: 'Sharia Compliant', value: 'Yes' },
      ],
    },
  };

  /**
   * Get current content based on language (computed signal)
   */
  readonly content = computed(() => {
    try {
      const lang = this.currentLang();
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:92',message:'Hero content computed',data:{lang,hasContent:!!this.heroContent[lang]},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'D'})}).catch(()=>{});
      // #endregion
      return this.heroContent[lang];
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:97',message:'Hero content computed error',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'D'})}).catch(()=>{});
      // #endregion
      console.error('Hero content error:', error);
      return this.heroContent.ar; // Fallback to Arabic
    }
  });

  /**
   * Open waiting list modal
   * Tracks CTA click event in analytics
   */
  openWaitingListModal(): void {
    // Track CTA click event
    if (typeof window !== 'undefined') {
      import('../../services/analytics.service').then(module => {
        const analyticsService = new module.AnalyticsService();
        analyticsService.trackEvent('cta_click', {
          location: 'hero_section',
          language: this.currentLang(),
        });
      }).catch(() => {});
    }
    try {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:118',message:'Opening waiting list modal',data:{hasZohoModal:!!this.zohoModal},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      const modal = this.zohoModal();
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:122',message:'Modal retrieved',data:{hasModal:!!modal,hasOpenModal:typeof modal?.openModal === 'function'},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      if (modal && typeof modal.openModal === 'function') {
        modal.openModal();
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:126',message:'Modal openModal called',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
      }
      
      // Always dispatch custom event as backup to ensure modal opens
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('open-zoho-modal'));
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:132',message:'Dispatched custom event as backup',data:{hasModal:!!modal},timestamp:Date.now(),sessionId:'debug-session',runId:'run4',hypothesisId:'I'})}).catch(()=>{});
        // #endregion
      }
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'hero-section.ts:135',message:'Error opening modal',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      console.error('Error opening waiting list modal:', error);
    }
  }
}
