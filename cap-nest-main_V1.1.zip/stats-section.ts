/**
 * Stats/Trust Bar Section Component
 * 
 * Redesigned from scratch per PRD Section 6.3.3 and Vercel Design Guidelines.
 * Features:
 * - Four metrics per PRD 6.3.3:
 *   1. Minimum investment: 100 SAR
 *   2. Expected yield: 8-12%
 *   3. REGA regulation status
 *   4. Sharia compliance status
 * - SGDS green accents
 * - Mobile-responsive stacking
 * 
 * Implements Vercel Design Guidelines for data display:
 * - Semantic HTML
 * - Accessible data presentation
 * - Responsive grid layout
 * 
 * @fileoverview Trust indicators and statistics display
 */

import { Component, inject, computed } from '@angular/core';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-stats-section',
  imports: [],
  templateUrl: './stats-section.html',
  styleUrl: './stats-section.css',
})
export class StatsSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Stats per PRD 6.3.3 - Four metrics
   */
  readonly stats = computed(() => {
    const lang = this.currentLang();
    return [
      {
        value: '100 ﷼',
        label: lang === 'ar' ? 'الحد الأدنى للاستثمار' : 'Minimum Investment',
        icon: 'currency',
      },
      {
        value: '8-12%',
        label: lang === 'ar' ? 'العائد المتوقع' : 'Expected Yield',
        icon: 'chart',
      },
      {
        value: lang === 'ar' ? 'قيد التقييم' : 'Pending',
        label: lang === 'ar' ? 'حالة REGA' : 'REGA Status',
        icon: 'shield',
      },
      {
        value: lang === 'ar' ? 'نعم' : 'Yes',
        label: lang === 'ar' ? 'متوافق مع الشريعة' : 'Sharia Compliant',
        icon: 'check',
      },
    ];
  });
}
