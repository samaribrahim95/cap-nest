/**
 * Mobile Responsiveness Checker
 * 
 * Provides utilities for checking mobile responsiveness:
 * - Viewport width checks
 * - Touch target sizes
 * - Text readability
 * - Layout breakpoints
 * 
 * @fileoverview Mobile responsiveness checker utilities
 */

/**
 * Check if viewport is mobile size
 */
export function isMobileViewport(): boolean {
  if (typeof window === 'undefined') return false;
  return window.innerWidth < 768;
}

/**
 * Check if viewport is tablet size
 */
export function isTabletViewport(): boolean {
  if (typeof window === 'undefined') return false;
  return window.innerWidth >= 768 && window.innerWidth < 1024;
}

/**
 * Check if viewport is desktop size
 */
export function isDesktopViewport(): boolean {
  if (typeof window === 'undefined') return false;
  return window.innerWidth >= 1024;
}

/**
 * Check if touch targets meet minimum size (44x44px per Vercel Guidelines)
 */
export function checkTouchTargetSize(element: HTMLElement): {
  meetsMinimum: boolean;
  width: number;
  height: number;
} {
  const rect = element.getBoundingClientRect();
  const minSize = 44;
  
  return {
    meetsMinimum: rect.width >= minSize && rect.height >= minSize,
    width: rect.width,
    height: rect.height,
  };
}

/**
 * Check text readability on mobile
 */
export function checkTextReadability(element: HTMLElement): {
  fontSize: number;
  lineHeight: number;
  readable: boolean;
} {
  const style = window.getComputedStyle(element);
  const fontSize = parseFloat(style.fontSize);
  const lineHeight = parseFloat(style.lineHeight) || fontSize * 1.5;
  
  // Minimum 16px font size for mobile readability
  return {
    fontSize,
    lineHeight,
    readable: fontSize >= 16,
  };
}

/**
 * Run mobile responsiveness audit
 */
export function runMobileResponsivenessAudit(): {
  viewport: {
    width: number;
    height: number;
    isMobile: boolean;
    isTablet: boolean;
    isDesktop: boolean;
  };
  touchTargets: {
    total: number;
    meetsMinimum: number;
    issues: Array<{ element: string; width: number; height: number }>;
  };
  textReadability: {
    total: number;
    readable: number;
    issues: Array<{ element: string; fontSize: number }>;
  };
} {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return {
      viewport: { width: 0, height: 0, isMobile: false, isTablet: false, isDesktop: false },
      touchTargets: { total: 0, meetsMinimum: 0, issues: [] },
      textReadability: { total: 0, readable: 0, issues: [] },
    };
  }
  
  const viewport = {
    width: window.innerWidth,
    height: window.innerHeight,
    isMobile: isMobileViewport(),
    isTablet: isTabletViewport(),
    isDesktop: isDesktopViewport(),
  };
  
  const interactiveElements = document.querySelectorAll<HTMLElement>(
    'button, a, input, select, textarea, [role="button"], [role="link"]'
  );
  
  const touchTargetIssues: Array<{ element: string; width: number; height: number }> = [];
  let meetsMinimum = 0;
  
  interactiveElements.forEach((element) => {
    const check = checkTouchTargetSize(element);
    if (check.meetsMinimum) {
      meetsMinimum++;
    } else {
      touchTargetIssues.push({
        element: element.tagName + (element.className ? '.' + element.className.split(' ')[0] : ''),
        width: check.width,
        height: check.height,
      });
    }
  });
  
  const textElements = document.querySelectorAll<HTMLElement>('p, span, div, h1, h2, h3, h4, h5, h6');
  const textReadabilityIssues: Array<{ element: string; fontSize: number }> = [];
  let readable = 0;
  
  textElements.forEach((element) => {
    const check = checkTextReadability(element);
    if (check.readable) {
      readable++;
    } else {
      textReadabilityIssues.push({
        element: element.tagName + (element.className ? '.' + element.className.split(' ')[0] : ''),
        fontSize: check.fontSize,
      });
    }
  });
  
  return {
    viewport,
    touchTargets: {
      total: interactiveElements.length,
      meetsMinimum,
      issues: touchTargetIssues,
    },
    textReadability: {
      total: textElements.length,
      readable,
      issues: textReadabilityIssues,
    },
  };
}
