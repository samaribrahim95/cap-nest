/**
 * Accessibility Audit Utility
 * 
 * Provides utilities for WCAG 2.1 AA compliance checks:
 * - Keyboard navigation
 * - Screen reader support
 * - Color contrast
 * - Focus management
 * - ARIA attributes
 * 
 * @fileoverview Accessibility audit utilities
 */

/**
 * Check if element is keyboard accessible
 */
export function isKeyboardAccessible(element: HTMLElement): boolean {
  const tabIndex = element.tabIndex;
  const role = element.getAttribute('role');
  const isInteractive = ['button', 'link', 'input', 'select', 'textarea'].includes(
    element.tagName.toLowerCase()
  );
  
  return tabIndex >= 0 || isInteractive || role === 'button' || role === 'link';
}

/**
 * Check color contrast ratio (WCAG AA requires 4.5:1 for normal text, 3:1 for large text)
 */
export function checkColorContrast(foreground: string, background: string): {
  ratio: number;
  passesAA: boolean;
  passesAAA: boolean;
} {
  // Simplified contrast check - in production, use a proper library
  // This is a placeholder that returns a basic check
  const ratio = 4.5; // Placeholder - actual calculation needed
  
  return {
    ratio,
    passesAA: ratio >= 4.5,
    passesAAA: ratio >= 7,
  };
}

/**
 * Check if element has proper ARIA labels
 */
export function hasAriaLabels(element: HTMLElement): boolean {
  const ariaLabel = element.getAttribute('aria-label');
  const ariaLabelledBy = element.getAttribute('aria-labelledby');
  const title = element.getAttribute('title');
  const textContent = element.textContent?.trim();
  
  return !!(ariaLabel || ariaLabelledBy || title || textContent);
}

/**
 * Check focus visibility
 */
export function hasFocusStyles(element: HTMLElement): boolean {
  const style = window.getComputedStyle(element, ':focus-visible');
  const outline = style.outline;
  const outlineWidth = style.outlineWidth;
  
  return outline !== 'none' && outlineWidth !== '0px';
}

/**
 * Run accessibility audit
 */
export function runAccessibilityAudit(): {
  keyboardAccessible: number;
  hasAriaLabels: number;
  hasFocusStyles: number;
  totalElements: number;
} {
  if (typeof document === 'undefined') {
    return {
      keyboardAccessible: 0,
      hasAriaLabels: 0,
      hasFocusStyles: 0,
      totalElements: 0,
    };
  }
  
  const interactiveElements = document.querySelectorAll<HTMLElement>(
    'button, a, input, select, textarea, [role="button"], [role="link"], [tabindex]'
  );
  
  let keyboardAccessible = 0;
  let hasAriaLabelsCount = 0;
  let hasFocusStylesCount = 0;
  
  interactiveElements.forEach((element) => {
    if (isKeyboardAccessible(element)) keyboardAccessible++;
    if (hasAriaLabels(element)) hasAriaLabelsCount++;
    if (hasFocusStyles(element)) hasFocusStylesCount++;
  });
  
  return {
    keyboardAccessible,
    hasAriaLabels: hasAriaLabelsCount,
    hasFocusStyles: hasFocusStylesCount,
    totalElements: interactiveElements.length,
  };
}
