/**
 * Footer Component
 * 
 * Redesigned from scratch per PRD Section 6.3.9 and Vercel Design Guidelines.
 * Features:
 * - Four-column layout per PRD 6.3.9
 * - Regulatory badges
 * - Privacy Policy/Terms links
 * - REGA license display
 * - Social media channels (editable placeholders)
 * 
 * @fileoverview Footer with regulatory compliance and navigation
 */

import { Component, inject, computed } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faLinkedin, faFacebook, faInstagram, faMedium } from '@fortawesome/free-brands-svg-icons';
import { faEnvelope, faBuilding } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';
import { SocialMediaService } from '../../services/social-media.service';

@Component({
  selector: 'app-footer',
  imports: [FontAwesomeModule],
  templateUrl: './footer.html',
  styleUrl: './footer.css',
})
export class Footer {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Social media service injection
   */
  private readonly socialMediaService = inject(SocialMediaService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Social media icons mapping
   */
  readonly socialIcons = {
    linkedin: faLinkedin,
    facebook: faFacebook,
    instagram: faInstagram,
    medium: faMedium,
    crunchbase: faBuilding,
    email: faEnvelope,
  };

  /**
   * Get social media channels
   */
  readonly socialChannels = computed(() => this.socialMediaService.getAllChannels());

  /**
   * Get external link attributes per Vercel Guidelines
   */
  readonly externalLinkAttrs = computed(() => this.socialMediaService.getExternalLinkAttributes());

  /**
   * Footer links per PRD 6.3.9
   */
  readonly footerLinks = computed(() => {
    const lang = this.currentLang();
    return {
      platform: [
        { name: lang === 'ar' ? 'كيف يشتغل' : 'How It Works', href: '#how-it-works' },
        { name: lang === 'ar' ? 'ليش CapNest' : 'Why CapNest', href: '#benefits' },
        { name: lang === 'ar' ? 'العقارات' : 'Properties', href: '#properties' },
        { name: lang === 'ar' ? 'الأسئلة الشائعة' : 'FAQ', href: '#faq' },
      ],
      legal: [
        { name: lang === 'ar' ? 'شروط الخدمة' : 'Terms of Service', href: '/terms' },
        { name: lang === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy', href: '/privacy' },
        { name: lang === 'ar' ? 'الإفصاحات' : 'Disclosures', href: '/disclosures' },
        { name: lang === 'ar' ? 'سياسة ملفات تعريف الارتباط' : 'Cookie Policy', href: '/cookies' },
      ],
      contact: [
        { name: lang === 'ar' ? 'مركز المساعدة' : 'Help Center', href: '/help' },
        { name: lang === 'ar' ? 'اتصل بنا' : 'Contact Us', href: '/contact' },
        { name: lang === 'ar' ? 'موارد المستثمرين' : 'Investor Resources', href: '/resources' },
      ],
    };
  });

  /**
   * Get icon for social channel
   */
  getSocialIcon(channelName: string) {
    return this.socialIcons[channelName as keyof typeof this.socialIcons] || faBuilding;
  }

  /**
   * Get current year for copyright
   */
  getCurrentYear(): number {
    return new Date().getFullYear();
  }
}
