/**
 * Performance Optimizer Utility
 * 
 * Provides utilities for performance optimization including:
 * - Lazy loading components
 * - Image optimization
 * - Resource hints
 * - Bundle size monitoring
 * 
 * @fileoverview Performance optimization utilities
 */

/**
 * Preload critical resources
 */
export function preloadCriticalResources(): void {
  if (typeof document === 'undefined') return;

  // Preload critical fonts
  const fontPreload = document.createElement('link');
  fontPreload.rel = 'preload';
  fontPreload.as = 'font';
  fontPreload.type = 'font/woff2';
  fontPreload.crossOrigin = 'anonymous';
  fontPreload.href = 'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap';
  document.head.appendChild(fontPreload);
}

/**
 * Lazy load images with intersection observer
 */
export function setupLazyImages(): void {
  if (typeof document === 'undefined' || !('IntersectionObserver' in window)) {
    // Fallback: load all images immediately
    const images = document.querySelectorAll('img[loading="lazy"]');
    images.forEach((img) => {
      (img as HTMLImageElement).loading = 'eager';
    });
    return;
  }

  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const img = entry.target as HTMLImageElement;
        if (img.dataset['src']) {
          img.src = img.dataset['src'];
          img.removeAttribute('data-src');
        }
        observer.unobserve(img);
      }
    });
  });

  const lazyImages = document.querySelectorAll('img[loading="lazy"]');
  lazyImages.forEach((img) => imageObserver.observe(img));
}

/**
 * Measure and log performance metrics
 */
export function measurePerformance(): void {
  if (typeof window === 'undefined' || !('performance' in window)) return;

  window.addEventListener('load', () => {
    setTimeout(() => {
      const perfData = window.performance.timing;
      const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
      const domContentLoaded = perfData.domContentLoadedEventEnd - perfData.navigationStart;
      const firstPaint = performance.getEntriesByType('paint').find(
        (entry) => entry.name === 'first-contentful-paint'
      );

      if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
        console.log('Performance Metrics:', {
          pageLoadTime: `${pageLoadTime}ms`,
          domContentLoaded: `${domContentLoaded}ms`,
          firstContentfulPaint: firstPaint ? `${Math.round(firstPaint.startTime)}ms` : 'N/A',
        });
      }
    }, 0);
  });
}

/**
 * Initialize all performance optimizations
 */
export function initPerformanceOptimizations(): void {
  preloadCriticalResources();
  setupLazyImages();
  measurePerformance();
}
