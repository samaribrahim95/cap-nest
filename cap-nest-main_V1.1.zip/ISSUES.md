# Known Issues and Bugs

This document tracks all known issues, bugs, and outstanding requirements for the CapNest landing page project.

## Critical Issues

### 1. Zoho Waiting List Form - Non-Functional
**Status**: 🔴 Under Active Remediation  
**Priority**: High  
**Assigned**: Frontend Development Team  
**Last Updated**: 2026-01-23

**Description**:  
The embedded Zoho inquiry form is currently non-functional. When users click any of the following buttons:
- "Start Investing Now" (Hero section)
- "Waiting List" (Navbar)
- "Join the Waiting List" (CTA section)

The modal opens correctly, but the iframe fails to load the Zoho form content. The interface displays a continuous "loading" indicator and does not render the form.

**Expected Behavior**:  
- Modal should open as a responsive pop-up
- Zoho form should load within the iframe
- Form should be fully functional and submittable
- Thank you message should display after successful submission

**Current Behavior**:  
- Modal opens successfully
- Loading indicator appears but form never loads
- Iframe is present in DOM but content fails to load
- Console shows: "Zoho form iframe not found in DOM after modal open"

**Technical Details**:  
- Component: `zoho-form-modal`
- Form URL: Zoho Forms integration
- Issue appears to be related to iframe loading/rendering
- Custom event system is in place but form content doesn't load

**Workaround**:  
None available. Users cannot currently submit the waiting list form.

**Related Files**:  
- `src/app/components/zoho-form-modal/zoho-form-modal.ts`
- `src/app/components/zoho-form-modal/zoho-form-modal.html`
- `src/app/components/navbar/navbar.ts`
- `src/app/components/hero-section/hero-section.ts`
- `src/app/components/ctasection/ctasection.ts`

---

## Medium Priority Issues

### 2. Console Warnings
**Status**: 🟡 Minor  
**Priority**: Medium  
**Last Updated**: 2026-01-23

**Description**:  
Some console warnings appear during development:
- TypeScript compilation warnings (if any)
- Browser console warnings about iframe accessibility (resolved)
- X-Frame-Options meta tag warning (resolved - moved to HTTP headers)

**Action Required**:  
Monitor and resolve any remaining console warnings in production build.

---

## Low Priority / Enhancement Requests

### 3. REGA Official Icon
**Status**: 🟢 Enhancement  
**Priority**: Low  
**Last Updated**: 2026-01-23

**Description**:  
The REGA badge currently uses a placeholder shield icon. The official REGA (Saudi Capital Market Authority) icon should be integrated when available.

**Current Implementation**:  
- Placeholder SVG icon in hero section
- Badge text: "REGA Sandbox Applicant"
- Proper color schemes and transitions implemented

**Action Required**:  
Replace placeholder icon with official REGA icon when provided.

---

### 4. Content Updates
**Status**: 🟢 Content  
**Priority**: Low  
**Last Updated**: 2026-01-23

**Description**:  
Various content elements may need updates:
- Property listings (currently showing placeholder data)
- Testimonials (Saudi market-specific content implemented)
- Footer links (some may need actual URLs)

**Action Required**:  
Update content as real data becomes available.

---

## Resolved Issues

### ✅ Iframe Accessibility
**Status**: ✅ Resolved  
**Resolved**: 2026-01-23

**Description**:  
Linter warning about iframe missing title attribute.

**Resolution**:  
Added both `[title]` and `[attr.title]` bindings to ensure proper accessibility.

---

### ✅ REGA Badge Colors
**Status**: ✅ Resolved  
**Resolved**: 2026-01-23

**Description**:  
REGA badge colors not animating correctly with navbar scroll state.

**Resolution**:  
Enhanced CSS specificity and added proper transitions for dynamic color changes.

---

### ✅ Hamburger Menu Text Visibility
**Status**: ✅ Resolved  
**Resolved**: 2026-01-23

**Description**:  
Text colors within hamburger menu were not visible.

**Resolution**:  
Added highly specific CSS rules with `!important` flags to ensure text visibility.

---

### ✅ RTL Icon Alignment
**Status**: ✅ Resolved  
**Resolved**: 2026-01-23

**Description**:  
Icons not properly aligned for RTL direction in Arabic version.

**Resolution**:  
Enhanced RTL icon alignment CSS with explicit margin rules and `!important` flags.

---

### ✅ Middle Sections Visibility
**Status**: ✅ Resolved  
**Resolved**: 2026-01-23

**Description**:  
Text, elements, animations, and boxes in middle sections were not visible.

**Resolution**:  
Added explicit CSS with `!important` flags for background and text colors across all sections.

---

## Reporting New Issues

When reporting new issues, please include:
1. **Description**: Clear description of the issue
2. **Steps to Reproduce**: Detailed steps to reproduce the issue
3. **Expected Behavior**: What should happen
4. **Actual Behavior**: What actually happens
5. **Environment**: Browser, OS, device information
6. **Screenshots**: If applicable
7. **Console Errors**: Any relevant console errors or warnings

---

## Issue Status Legend

- 🔴 **Critical**: Blocks core functionality, needs immediate attention
- 🟡 **Medium**: Affects user experience but has workarounds
- 🟢 **Low**: Enhancement or minor issue
- ✅ **Resolved**: Issue has been fixed and verified
