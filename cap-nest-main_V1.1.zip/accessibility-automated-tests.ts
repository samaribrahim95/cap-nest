/**
 * Automated Accessibility Tests
 * 
 * Automated accessibility testing scripts that can be run
 * in browser console or integrated into test suites.
 * 
 * @fileoverview Automated accessibility testing utilities
 */

import { runAccessibilityAudit } from './accessibility-audit';

/**
 * Run automated accessibility tests and generate report
 */
export function runAutomatedAccessibilityTests(): {
  passed: number;
  failed: number;
  warnings: number;
  details: Array<{
    test: string;
    status: 'pass' | 'fail' | 'warning';
    message: string;
    element?: string;
  }>;
} {
  const results = runAccessibilityAudit();
  const details: Array<{
    test: string;
    status: 'pass' | 'fail' | 'warning';
    message: string;
    element?: string;
  }> = [];
  
  let passed = 0;
  let failed = 0;
  let warnings = 0;
  
  if (typeof document === 'undefined') {
    return {
      passed: 0,
      failed: 1,
      warnings: 0,
      details: [{
        test: 'Document availability',
        status: 'fail',
        message: 'Document not available - run in browser environment',
      }],
    };
  }
  
  // Test 1: Keyboard Accessibility
  const keyboardScore = results.totalElements > 0
    ? (results.keyboardAccessible / results.totalElements) * 100
    : 100;
  
  if (keyboardScore === 100) {
    passed++;
    details.push({
      test: 'Keyboard Accessibility',
      status: 'pass',
      message: `All ${results.keyboardAccessible} interactive elements are keyboard accessible`,
    });
  } else if (keyboardScore >= 90) {
    warnings++;
    details.push({
      test: 'Keyboard Accessibility',
      status: 'warning',
      message: `${results.keyboardAccessible}/${results.totalElements} elements keyboard accessible (${keyboardScore.toFixed(1)}%)`,
    });
  } else {
    failed++;
    details.push({
      test: 'Keyboard Accessibility',
      status: 'fail',
      message: `Only ${results.keyboardAccessible}/${results.totalElements} elements keyboard accessible (${keyboardScore.toFixed(1)}%)`,
    });
  }
  
  // Test 2: ARIA Labels
  const ariaScore = results.totalElements > 0
    ? (results.hasAriaLabels / results.totalElements) * 100
    : 100;
  
  if (ariaScore === 100) {
    passed++;
    details.push({
      test: 'ARIA Labels',
      status: 'pass',
      message: `All ${results.hasAriaLabels} interactive elements have ARIA labels`,
    });
  } else if (ariaScore >= 90) {
    warnings++;
    details.push({
      test: 'ARIA Labels',
      status: 'warning',
      message: `${results.hasAriaLabels}/${results.totalElements} elements have ARIA labels (${ariaScore.toFixed(1)}%)`,
    });
  } else {
    failed++;
    details.push({
      test: 'ARIA Labels',
      status: 'fail',
      message: `Only ${results.hasAriaLabels}/${results.totalElements} elements have ARIA labels (${ariaScore.toFixed(1)}%)`,
    });
  }
  
  // Test 3: Focus Styles
  const focusScore = results.totalElements > 0
    ? (results.hasFocusStyles / results.totalElements) * 100
    : 100;
  
  if (focusScore === 100) {
    passed++;
    details.push({
      test: 'Focus Styles',
      status: 'pass',
      message: `All ${results.hasFocusStyles} interactive elements have focus styles`,
    });
  } else if (focusScore >= 90) {
    warnings++;
    details.push({
      test: 'Focus Styles',
      status: 'warning',
      message: `${results.hasFocusStyles}/${results.totalElements} elements have focus styles (${focusScore.toFixed(1)}%)`,
    });
  } else {
    failed++;
    details.push({
      test: 'Focus Styles',
      status: 'fail',
      message: `Only ${results.hasFocusStyles}/${results.totalElements} elements have focus styles (${focusScore.toFixed(1)}%)`,
    });
  }
  
  // Test 4: Images have alt text
  const images = document.querySelectorAll<HTMLImageElement>('img');
  const imagesWithAlt = Array.from(images).filter(img => img.alt || img.getAttribute('aria-label'));
  const altScore = images.length > 0 ? (imagesWithAlt.length / images.length) * 100 : 100;
  
  if (altScore === 100) {
    passed++;
    details.push({
      test: 'Image Alt Text',
      status: 'pass',
      message: `All ${images.length} images have alt text or aria-label`,
    });
  } else {
    failed++;
    details.push({
      test: 'Image Alt Text',
      status: 'fail',
      message: `Only ${imagesWithAlt.length}/${images.length} images have alt text (${altScore.toFixed(1)}%)`,
    });
  }
  
  // Test 5: Form inputs have labels
  const inputs = document.querySelectorAll<HTMLInputElement>('input, select, textarea');
  const inputsWithLabels = Array.from(inputs).filter(input => {
    const id = input.id;
    const label = id ? document.querySelector(`label[for="${id}"]`) : null;
    const ariaLabel = input.getAttribute('aria-label');
    const ariaLabelledBy = input.getAttribute('aria-labelledby');
    return label || ariaLabel || ariaLabelledBy || input.closest('label');
  });
  const labelScore = inputs.length > 0 ? (inputsWithLabels.length / inputs.length) * 100 : 100;
  
  if (labelScore === 100) {
    passed++;
    details.push({
      test: 'Form Input Labels',
      status: 'pass',
      message: `All ${inputs.length} form inputs have labels`,
    });
  } else {
    failed++;
    details.push({
      test: 'Form Input Labels',
      status: 'fail',
      message: `Only ${inputsWithLabels.length}/${inputs.length} form inputs have labels (${labelScore.toFixed(1)}%)`,
    });
  }
  
  // Test 6: Heading hierarchy
  const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
  let hasH1 = false;
  let hierarchyValid = true;
  let previousLevel = 0;
  
  Array.from(headings).forEach(heading => {
    const level = parseInt(heading.tagName.charAt(1));
    if (level === 1) hasH1 = true;
    if (previousLevel > 0 && level > previousLevel + 1) {
      hierarchyValid = false;
    }
    previousLevel = level;
  });
  
  if (hasH1 && hierarchyValid) {
    passed++;
    details.push({
      test: 'Heading Hierarchy',
      status: 'pass',
      message: 'Heading hierarchy is valid (h1 present, no skipped levels)',
    });
  } else {
    failed++;
    details.push({
      test: 'Heading Hierarchy',
      status: 'fail',
      message: hasH1
        ? 'Heading hierarchy has skipped levels'
        : 'Page is missing h1 heading',
    });
  }
  
  return {
    passed,
    failed,
    warnings,
    details,
  };
}

/**
 * Generate accessibility test report
 */
export function generateAccessibilityReport(): string {
  const results = runAutomatedAccessibilityTests();
  
  const report = `
# Accessibility Test Report
Generated: ${new Date().toISOString()}

## Summary
- ✅ Passed: ${results.passed}
- ❌ Failed: ${results.failed}
- ⚠️  Warnings: ${results.warnings}

## Test Details
${results.details.map(detail => {
  const icon = detail.status === 'pass' ? '✅' : detail.status === 'fail' ? '❌' : '⚠️';
  return `${icon} **${detail.test}**: ${detail.message}`;
}).join('\n')}

## Recommendations
${results.failed > 0
  ? '- Fix all failed tests to meet WCAG 2.1 AA compliance'
  : '- All automated tests passed! Consider manual testing with Axe or WAVE for comprehensive coverage.'}
${results.warnings > 0
  ? '- Review warnings and improve where possible'
  : ''}
  `.trim();
  
  return report;
}

/**
 * Log accessibility test results to console
 */
export function logAccessibilityTestResults(): void {
  const results = runAutomatedAccessibilityTests();
  const report = generateAccessibilityReport();
  
  console.group('🔍 Automated Accessibility Test Results');
  console.log(report);
  console.groupEnd();
  
  // Also log structured data
  if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
    console.table(results.details);
  }
}
