/**
 * Benefits Section Component
 * 
 * Redesigned from scratch per PRD Section 6.3.5 and Vercel Design Guidelines.
 * Features:
 * - Six benefits per PRD 6.3.5
 * - Responsive grid (2 mobile, 3 desktop)
 * - No mobile hover effects (performance)
 * - Accessible focus states
 * 
 * @fileoverview Benefits section with six key benefits
 */

import { Component, inject, computed } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  faWallet,
  faBarChart,
  faShield,
  faUsers,
  faGlobe,
  faClock,
} from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-benefits-section',
  imports: [FontAwesomeModule],
  templateUrl: './benefits-section.html',
  styleUrl: './benefits-section.css',
})
export class BenefitsSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Six benefits per PRD 6.3.5
   */
  readonly benefits = computed(() => {
    const lang = this.currentLang();
    return [
      {
        icon: faWallet,
        title: lang === 'ar' ? 'استثمار منخفض' : 'Low Minimum Investment',
        description: lang === 'ar'
          ? 'ابدأ تبني محفظتك من 100 ريال بس. بدون دفعات مقدمة كبيرة مطلوبة.'
          : 'Start building your portfolio from just 100 SAR. No massive down payments required.',
      },
      {
        icon: faBarChart,
        title: lang === 'ar' ? 'محفظة متنوعة' : 'Diversified Portfolio',
        description: lang === 'ar'
          ? 'وزع استثمارك على عدة عقارات لتقليل المخاطر وزيادة العوائد.'
          : 'Spread your investment across multiple properties to reduce risk and maximize returns.',
      },
      {
        icon: faShield,
        title: lang === 'ar' ? 'منظمة من REGA' : 'REGA Regulated',
        description: lang === 'ar'
          ? 'كل الاستثمارات متوافقة تماماً مع لوائح REGA، وهذا يضمن حماية فلوسك.'
          : 'All investments are fully compliant with REGA regulations, ensuring your money is protected.',
      },
      {
        icon: faUsers,
        title: lang === 'ar' ? 'إدارة احترافية' : 'Professional Management',
        description: lang === 'ar'
          ? 'فريقنا الخبير يتولى إدارة العقارات والمستأجرين والصيانة - أنت بس تربح.'
          : 'Our expert team handles property management, tenants, and maintenance – you just earn.',
      },
      {
        icon: faClock,
        title: lang === 'ar' ? 'دخل شهري' : 'Monthly Income',
        description: lang === 'ar'
          ? 'احصل على حصتك من دخل الإيجار مباشرة لحسابك كل شهر.'
          : 'Receive your share of rental income directly to your account every month.',
      },
      {
        icon: faGlobe,
        title: lang === 'ar' ? 'استثمر من أي مكان' : 'Invest Anywhere',
        description: lang === 'ar'
          ? 'الوصول إلى العقارات المميزة في كل أنحاء المملكة من راحة بيتك.'
          : 'Access premium properties nationwide from the comfort of your home.',
      },
    ];
  });
}
