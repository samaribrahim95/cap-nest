/**
 * Social Media Service
 * 
 * Centralized service for managing social media channel configurations.
 * All URLs and emails are editable placeholders that can be easily updated.
 * 
 * Implements Vercel Design Guidelines for external links and accessibility.
 * 
 * @fileoverview Social media configuration management service
 */

import { Injectable, signal } from '@angular/core';
import {
  SocialMediaConfig,
  SocialMediaChannel,
  DEFAULT_SOCIAL_MEDIA_CONFIG,
} from '../models/social-media.model';

@Injectable({
  providedIn: 'root',
})
export class SocialMediaService {
  /**
   * Social media configuration signal (editable)
   */
  private readonly config = signal<SocialMediaConfig>(DEFAULT_SOCIAL_MEDIA_CONFIG);

  /**
   * Get all social media channels
   * @returns Array of social media channels
   */
  getAllChannels(): SocialMediaChannel[] {
    const config = this.config();
    return [
      config.linkedin,
      config.facebook,
      config.instagram,
      config.medium,
      config.crunchbase,
      config.email,
    ];
  }

  /**
   * Get a specific social media channel
   * @param key - Channel key (linkedin, facebook, instagram, medium, crunchbase, email)
   * @returns Social media channel configuration
   */
  getChannel(key: keyof SocialMediaConfig): SocialMediaChannel {
    return this.config()[key];
  }

  /**
   * Update a social media channel URL/email
   * @param key - Channel key
   * @param url - New URL or email address
   */
  updateChannelUrl(key: keyof SocialMediaConfig, url: string): void {
    const currentConfig = this.config();
    const updatedConfig = {
      ...currentConfig,
      [key]: {
        ...currentConfig[key],
        url,
      },
    };
    this.config.set(updatedConfig);
  }

  /**
   * Update entire social media configuration
   * @param config - New configuration object
   */
  updateConfig(config: SocialMediaConfig): void {
    this.config.set(config);
  }

  /**
   * Get current configuration (read-only)
   * @returns Current social media configuration
   */
  getConfig(): SocialMediaConfig {
    return this.config();
  }

  /**
   * Get external link attributes per Vercel Design Guidelines
   * @returns Object with target and rel attributes
   */
  getExternalLinkAttributes(): { target: string; rel: string } {
    return {
      target: '_blank',
      rel: 'noopener noreferrer',
    };
  }
}
