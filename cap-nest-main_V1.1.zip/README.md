# CapNest - Fractional Real Estate Investment Platform

[![Angular](https://img.shields.io/badge/Angular-21.0.0-red.svg)](https://angular.io/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.9.2-blue.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.1.12-38bdf8.svg)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-Proprietary-yellow.svg)](LICENSE)

CapNest is a fractional real estate investment platform that enables Saudi investors to invest in real estate properties starting from just 100 SAR. The platform is regulated by the Capital Market Authority (REGA) and provides a Sharia-compliant investment solution.

## 🚀 Features

- **Bilingual Support**: Full Arabic (Saudi dialect) and English language support with RTL/LTR layout switching
- **Responsive Design**: Mobile-first design optimized for all devices
- **REGA Compliance**: Platform status badge and regulatory compliance indicators
- **Accessibility**: WCAG 2.1 AA compliant with comprehensive accessibility features
- **Performance Optimized**: Lighthouse-optimized with lazy loading and resource hints
- **Security**: Content Security Policy (CSP) and security HTTP headers configured
- **Analytics**: Google Analytics 4 (GA4) integration for user behavior tracking

## 📋 Project Status

**Current Version**: `1.0.0-alpha.1`

This is an alpha release of the CapNest landing page. The project is actively under development.

### Known Issues

⚠️ **Zoho Waiting List Form**: The embedded Zoho inquiry form is currently non-functional and is being actively remedied by the frontend development team. See [ISSUES.md](ISSUES.md) for details.

For a complete list of known issues, see [ISSUES.md](ISSUES.md).

## 🛠️ Technology Stack

- **Framework**: Angular 21.0.0 (Standalone Components)
- **Language**: TypeScript 5.9.2
- **Styling**: Tailwind CSS 4.1.12
- **Icons**: FontAwesome (Free Solid & Brands)
- **Server**: Express 5.1.0 (SSR)
- **Testing**: Vitest 4.0.8
- **Build Tool**: Angular Build (@angular/build)

## 📦 Installation

### Prerequisites

- Node.js 20.x or higher
- npm 11.6.2 or higher

### Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd cap-nest-main
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm start
   ```

4. **Open your browser**
   Navigate to `http://localhost:4200/`

## 🏗️ Project Structure

```
cap-nest-main/
├── src/
│   ├── app/
│   │   ├── components/          # Angular components
│   │   │   ├── navbar/          # Navigation bar
│   │   │   ├── hero-section/    # Hero section with CTAs
│   │   │   ├── stats-section/   # Trust indicators
│   │   │   ├── how-it-works-section/  # 3-step process
│   │   │   ├── benefits-section/      # Fractional ownership benefits
│   │   │   ├── properties-section/    # Investment opportunities
│   │   │   ├── testimonials-section/  # User testimonials
│   │   │   ├── ctasection/            # Call-to-action section
│   │   │   ├── footer/               # Footer with links
│   │   │   └── zoho-form-modal/       # Waiting list form modal
│   │   ├── services/            # Angular services
│   │   │   ├── language.service.ts    # i18n language switching
│   │   │   ├── analytics.service.ts    # GA4 integration
│   │   │   └── zoho-integration.service.ts  # Zoho form integration
│   │   └── utils/               # Utility functions
│   │       ├── synthesis-squad-orchestrator.ts  # Test orchestrator
│   │       ├── comprehensive-test-runner.ts      # Test runner
│   │       ├── accessibility-audit.ts           # Accessibility checks
│   │       └── ...                              # Other utilities
│   ├── assets/                  # Static assets
│   │   └── imgs/                # Images
│   ├── styles.css               # Global styles
│   └── index.html               # Main HTML file
├── archive/                     # Unrelated files (excluded from git)
├── .gitignore                   # Git ignore rules
├── CHANGELOG.md                 # Version history
├── ISSUES.md                    # Known issues and bugs
├── package.json                 # Dependencies and scripts
└── README.md                    # This file
```

## 🧪 Development

### Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm run watch` - Build and watch for changes
- `npm test` - Run unit tests
- `npm run serve:ssr:cap-nest` - Serve SSR build

### Code Style

The project uses Prettier for code formatting:
- Print width: 100 characters
- Single quotes for strings
- Angular HTML parser for `.html` files

## 🌐 Internationalization (i18n)

The application supports two languages:
- **Arabic (ar)**: Saudi dialect, RTL layout
- **English (en)**: LTR layout

Language switching is handled by the `LanguageService` and all components use computed signals for reactive language updates.

## ♿ Accessibility

The project follows WCAG 2.1 AA standards:
- Semantic HTML structure
- ARIA labels and roles
- Keyboard navigation support
- Screen reader compatibility
- Focus management
- Color contrast compliance

## 🔒 Security

- Content Security Policy (CSP) configured
- Security HTTP headers set at server level
- XSS prevention measures
- Iframe sandbox attributes
- Input sanitization

## 📊 Analytics

Google Analytics 4 (GA4) is integrated for:
- Page view tracking
- CTA click tracking
- Modal open/close events
- Form submission tracking (when functional)

## 🧩 Components Overview

### Navbar
- Language toggle (Arabic/English)
- REGA Sandbox Applicant badge
- Navigation links
- Mobile hamburger menu
- Dynamic color changes on scroll

### Hero Section
- Main headline and subheadline
- Primary and secondary CTAs
- Trust indicators (100 SAR, 8-12% yield, REGA status, Sharia compliance)
- REGA badge with official icon

### Stats Section
- Key statistics display
- Trust indicators

### How It Works
- 3-step investment process
- Visual step indicators
- Icon-based cards

### Benefits Section
- Fractional ownership advantages
- 6 key benefits with icons
- Gradient background

### Properties Section
- Investment opportunities
- Property cards with details
- Funding progress indicators

### Testimonials Section
- Saudi market-specific testimonials
- User avatars and quotes

### CTA Section
- Final call-to-action
- Waiting list button
- Schedule a call link

### Footer
- Company information
- Legal links
- Contact information
- Social media links

## 🐛 Known Issues

See [ISSUES.md](ISSUES.md) for a complete list of known issues, bugs, and outstanding requirements.

**Critical Issue**: The Zoho waiting list form is currently non-functional and is being actively remedied by the frontend development team.

## 📝 Changelog

See [CHANGELOG.md](CHANGELOG.md) for a detailed history of changes.

## 📄 License

This project is proprietary and confidential. All rights reserved.

## 👥 Contributing

This is a private project. For contributions, please contact the project maintainers.

## 📞 Support

For issues, questions, or support, please refer to the [ISSUES.md](ISSUES.md) file or contact the development team.

## 🔗 Related Documentation

- [Product Requirements Document](CapNest%20Sandbox%20MVP%20(PRD)%20+%20BRS.md)
- [Changelog](CHANGELOG.md)
- [Known Issues](ISSUES.md)

---

**Last Updated**: January 23, 2026  
**Version**: 1.0.0-alpha.1
