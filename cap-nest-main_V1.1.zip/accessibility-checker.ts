/**
 * Accessibility Checker Utility
 * 
 * Provides utilities for accessibility validation and improvements:
 * - ARIA label validation
 * - Keyboard navigation testing
 * - Focus management
 * - Screen reader compatibility
 * 
 * @fileoverview Accessibility validation utilities
 */

/**
 * Check for missing ARIA labels
 */
export function checkAriaLabels(): { missing: number; total: number } {
  if (typeof document === 'undefined') return { missing: 0, total: 0 };

  const interactiveElements = document.querySelectorAll(
    'button, a, input, select, textarea, [role="button"], [role="link"]'
  );
  let missing = 0;

  interactiveElements.forEach((element) => {
    const hasLabel =
      element.hasAttribute('aria-label') ||
      element.hasAttribute('aria-labelledby') ||
      element.textContent?.trim() ||
      (element as HTMLInputElement).placeholder ||
      element.getAttribute('title');

    if (!hasLabel) {
      missing++;
    }
  });

  return { missing, total: interactiveElements.length };
}

/**
 * Check keyboard navigation support
 */
export function checkKeyboardNavigation(): boolean {
  if (typeof document === 'undefined') return false;

  const focusableElements = document.querySelectorAll(
    'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );

  let allFocusable = true;
  focusableElements.forEach((element) => {
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden') {
      // Hidden elements shouldn't be focusable
      return;
    }
    // Check if element can receive focus
    if ((element as HTMLElement).tabIndex === undefined && !element.hasAttribute('tabindex')) {
      // Some elements might not be keyboard accessible
      if (element.tagName === 'DIV' || element.tagName === 'SPAN') {
        allFocusable = false;
      }
    }
  });

  return allFocusable;
}

/**
 * Add skip to main content link
 */
export function addSkipLink(): void {
  if (typeof document === 'undefined') return;

  // Check if skip link already exists
  if (document.getElementById('skip-to-main')) return;

  const skipLink = document.createElement('a');
  skipLink.id = 'skip-to-main';
  skipLink.href = '#home';
  skipLink.className = 'sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[9999] focus:px-4 focus:py-2 focus:bg-sgdsGreen focus:text-white focus:rounded-md';
  skipLink.textContent = 'Skip to main content';
  document.body.insertBefore(skipLink, document.body.firstChild);
}

/**
 * Initialize accessibility improvements
 */
export function initAccessibility(): void {
  addSkipLink();
  
  // Log accessibility status in development
  if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
    const ariaCheck = checkAriaLabels();
    const keyboardCheck = checkKeyboardNavigation();
    
    console.log('Accessibility Status:', {
      ariaLabels: `${ariaCheck.total - ariaCheck.missing}/${ariaCheck.total} elements have labels`,
      keyboardNavigation: keyboardCheck ? 'Supported' : 'Issues found',
    });
  }
}
