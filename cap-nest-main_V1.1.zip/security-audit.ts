/**
 * Security Audit Utility
 * 
 * Provides utilities for security validation:
 * - XSS protection checks
 * - CSRF token validation
 * - Content Security Policy validation
 * - Input sanitization checks
 * 
 * @fileoverview Security audit utilities
 */

/**
 * Check if Content Security Policy is set
 */
export function checkCSP(): boolean {
  if (typeof document === 'undefined') return false;
  
  const metaCSP = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
  return !!metaCSP;
}

/**
 * Validate URL for safe iframe embedding
 */
export function validateIframeUrl(url: string): boolean {
  try {
    const urlObj = new URL(url);
    // Only allow https URLs
    if (urlObj.protocol !== 'https:') return false;
    
    // Whitelist allowed domains
    const allowedDomains = ['zfrmz.sa', 'zoho.com', 'zoho.eu'];
    return allowedDomains.some(domain => urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain));
  } catch {
    return false;
  }
}

/**
 * Sanitize user input (basic XSS prevention)
 */
export function sanitizeInput(input: string): string {
  if (typeof input !== 'string') return '';
  
  // Remove script tags and event handlers
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
    .replace(/javascript:/gi, '')
    .trim();
}

/**
 * Check for security headers (both meta tags and HTTP headers)
 */
export function checkSecurityHeaders(): {
  xContentTypeOptions: boolean;
  xFrameOptions: boolean;
  xXSSProtection: boolean;
  referrerPolicy: boolean;
  strictTransportSecurity: boolean;
  permissionsPolicy: boolean;
  source: 'meta' | 'http' | 'both' | 'none';
} {
  if (typeof document === 'undefined') {
    return {
      xContentTypeOptions: false,
      xFrameOptions: false,
      xXSSProtection: false,
      referrerPolicy: false,
      strictTransportSecurity: false,
      permissionsPolicy: false,
      source: 'none',
    };
  }

  // Check meta tags
  const metas = Array.from(document.querySelectorAll('meta[http-equiv]'));
  const metaHeaders: Record<string, boolean> = {
    xContentTypeOptions: false,
    xFrameOptions: false,
    xXSSProtection: false,
    referrerPolicy: false,
  };

  metas.forEach((meta) => {
    const httpEquiv = meta.getAttribute('http-equiv')?.toLowerCase();
    if (httpEquiv === 'x-content-type-options') metaHeaders['xContentTypeOptions'] = true;
    if (httpEquiv === 'x-frame-options') metaHeaders['xFrameOptions'] = true;
    if (httpEquiv === 'x-xss-protection') metaHeaders['xXSSProtection'] = true;
    if (httpEquiv === 'referrer-policy') metaHeaders['referrerPolicy'] = true;
  });

  // Check HTTP headers (via fetch to current page)
  // Note: This requires CORS to be enabled, which may not work in all cases
  // In production, use server-side header checking
  let httpHeaders: Record<string, boolean> = {
    xContentTypeOptions: false,
    xFrameOptions: false,
    xXSSProtection: false,
    referrerPolicy: false,
    strictTransportSecurity: false,
    permissionsPolicy: false,
  };
  
  let source: 'meta' | 'http' | 'both' | 'none' = 'none';
  
  // Try to check HTTP headers (async, may not always work due to CORS)
  if (typeof fetch !== 'undefined') {
    fetch(window.location.href, { method: 'HEAD', cache: 'no-store' })
      .then(response => {
        httpHeaders = {
          xContentTypeOptions: response.headers.has('X-Content-Type-Options'),
          xFrameOptions: response.headers.has('X-Frame-Options'),
          xXSSProtection: response.headers.has('X-XSS-Protection'),
          referrerPolicy: response.headers.has('Referrer-Policy'),
          strictTransportSecurity: response.headers.has('Strict-Transport-Security'),
          permissionsPolicy: response.headers.has('Permissions-Policy'),
        };
      })
      .catch(() => {
        // CORS or other fetch issues - headers may still be set by server
        // This is expected in many cases
      });
  }
  
  // Combine results (HTTP headers take precedence, but meta tags provide fallback)
  const combined = {
    xContentTypeOptions: httpHeaders['xContentTypeOptions'] || metaHeaders['xContentTypeOptions'],
    xFrameOptions: httpHeaders['xFrameOptions'] || metaHeaders['xFrameOptions'],
    xXSSProtection: httpHeaders['xXSSProtection'] || metaHeaders['xXSSProtection'],
    referrerPolicy: httpHeaders['referrerPolicy'] || metaHeaders['referrerPolicy'],
    strictTransportSecurity: httpHeaders['strictTransportSecurity'],
    permissionsPolicy: httpHeaders['permissionsPolicy'],
  };
  
  // Determine source
  const hasMeta = Object.values(metaHeaders).some(v => v);
  const hasHttp = Object.values(httpHeaders).some(v => v);
  if (hasMeta && hasHttp) source = 'both';
  else if (hasHttp) source = 'http';
  else if (hasMeta) source = 'meta';
  else source = 'none';
  
  return {
    ...combined,
    source,
  };
}

/**
 * Run security audit
 */
export function runSecurityAudit(): {
  csp: boolean;
  securityHeaders: ReturnType<typeof checkSecurityHeaders>;
  iframeUrlValid: boolean;
} {
  const zohoUrl = 'https://zfrmz.sa/PnG9yx0hykI0YxroY6Mi';
  
  return {
    csp: checkCSP(),
    securityHeaders: checkSecurityHeaders(),
    iframeUrlValid: validateIframeUrl(zohoUrl),
  };
}
