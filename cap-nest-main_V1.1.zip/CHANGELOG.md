# Changelog

All notable changes to the CapNest project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0-alpha.1] - 2026-01-23

### Added
- Initial project setup with Angular 21.0.0
- Landing page with bilingual support (Arabic/English)
- Hero section with trust indicators
- Navigation bar with language toggle and REGA badge
- Benefits section showcasing fractional ownership advantages
- How It Works section with 3-step process
- Properties section with investment opportunities
- Testimonials section with Saudi market-specific content
- CTA section with waiting list integration
- Footer with legal links and contact information
- Zoho form modal component (non-functional - under remediation)
- Analytics service integration (GA4)
- Language service for i18n support
- RTL/LTR support for Arabic and English
- Comprehensive testing utilities (SYNTHESIS SQUAD)
- Security headers configuration
- Accessibility audit tools
- Performance optimization utilities
- Mobile responsiveness checker
- Cross-browser polyfills

### Changed
- Updated REGA status from "Regulated" to "Pending" in trust indicators
- Enhanced navbar text colors with dynamic scroll-based transitions
- Improved REGA badge styling with official icon and proper color schemes
- Fixed hamburger menu text visibility
- Enhanced RTL icon alignment across all components
- Improved CSS specificity for better style override handling

### Fixed
- Iframe accessibility - added proper title attributes
- REGA badge color transitions (transparent/scrolled states)
- Hamburger menu text color visibility
- RTL icon alignment across all page sections
- Middle sections visibility (background and text colors)

### Known Issues
- **Zoho Waiting List Form**: The embedded Zoho inquiry form accessed via "Start Investing Now", "Waiting List", and "Join the Waiting List" buttons is currently non-functional. This is being actively remedied by the frontend development team. The modal opens but the iframe fails to load the form content properly.

### Technical Details
- Angular 21.0.0 with standalone components
- Tailwind CSS 4.1.12 for styling
- FontAwesome icons for UI elements
- Express 5.1.0 for SSR
- TypeScript 5.9.2
- Vitest 4.0.8 for testing
