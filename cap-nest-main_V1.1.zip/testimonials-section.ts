/**
 * Testimonials Section Component
 * 
 * Redesigned from scratch per PRD requirements and Vercel Design Guidelines.
 * Features:
 * - Bilingual testimonials (Arabic/English)
 * - SGDS color scheme
 * - Responsive grid layout
 * 
 * @fileoverview Testimonials section with investor reviews
 */

import { Component, inject, computed } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-testimonials-section',
  imports: [FontAwesomeModule],
  templateUrl: './testimonials-section.html',
  styleUrl: './testimonials-section.css',
})
export class TestimonialsSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Star icon
   */
  readonly starIcon = faStar;

  /**
   * Testimonials content (bilingual) - Saudi market-relevant with Saudi individuals
   */
  readonly testimonials = computed(() => {
    const lang = this.currentLang();
    return [
      {
        name: lang === 'ar' ? 'فاطمة العلي' : 'Fatima Al-Ali',
        role: lang === 'ar' ? 'مستثمرة عقارية، الرياض' : 'Real Estate Investor, Riyadh',
        content: lang === 'ar'
          ? 'كنت أدور على طريقة آمنة للاستثمار في عقارات السعودية. CapNest سهلت الموضوع كثير. استثمرت 500 ريال في عقار في الرياض وأحصل على عائد شهري ثابت. أنصح كل واحد يبي يبدأ في الاستثمار العقاري.'
          : 'I was looking for a safe way to invest in Saudi real estate. CapNest made it so easy. I invested 500 SAR in a property in Riyadh and receive a steady monthly return. I recommend it to anyone wanting to start real estate investing.',
        rating: 5,
        avatar: 'FA',
      },
      {
        name: lang === 'ar' ? 'خالد الأحمد' : 'Khalid Al-Ahmad',
        role: lang === 'ar' ? 'مهندس برمجيات، جدة' : 'Software Engineer, Jeddah',
        content: lang === 'ar'
          ? 'كشخص شاب في بداية مسيرته المهنية، ما كنت أتوقع أقدر أستثمر في العقارات. CapNest غيرت الوضع. الحين عندي محفظة متنوعة من 3 عقارات في مدن مختلفة. العوائد أحسن من حساب التوفير بكثير.'
          : 'As a young professional starting my career, I didn\'t think I could invest in real estate. CapNest changed that. Now I have a diversified portfolio of 3 properties in different cities. The returns are much better than a savings account.',
        rating: 5,
        avatar: 'KA',
      },
      {
        name: lang === 'ar' ? 'نورة السالم' : 'Noura Al-Salem',
        role: lang === 'ar' ? 'معلمة، الدمام' : 'Teacher, Dammam',
        content: lang === 'ar'
          ? 'أبي أبني مصدر دخل إضافي للمستقبل. CapNest منصة موثوقة ومنظمة من REGA، وهذا مهم جداً بالنسبة لي. استثمرت 1000 ريال وأحصل على دخل شهري يساعدني في تخطيط مالي أحسن. الله يعطيكم العافية CapNest!'
          : 'I wanted to build an additional income source for the future. CapNest is a trusted platform regulated by REGA, which is very important to me. I invested 1000 SAR and receive monthly income that helps me with better financial planning. Thank you CapNest!',
        rating: 5,
        avatar: 'NS',
      },
    ];
  });

  /**
   * Get array of stars for rating
   */
  getStars(rating: number): number[] {
    return Array.from({ length: rating });
  }
}
