import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

// Handle unhandled promise rejections and errors (filter out browser extension errors)
if (typeof window !== 'undefined') {
  // Known browser extension error patterns (harmless)
  const browserExtensionErrors = [
    'Could not establish connection',
    'Receiving end does not exist',
    'Extension context invalidated',
    'message port closed',
    'A listener indicated an asynchronous response',
    'chrome-extension://',
    'moz-extension://',
    'safari-extension://',
  ];
  
  /**
   * Check if error is from a browser extension (harmless)
   */
  const isBrowserExtensionError = (error: unknown): boolean => {
    if (!error) return false;
    
    const errorMessage = error && typeof error === 'object' && 'message' in error 
      ? String((error as { message: unknown }).message) 
      : String(error || '');
    const errorString = String(error || '');
    const stack = error && typeof error === 'object' && 'stack' in error
      ? String((error as { stack: unknown }).stack || '')
      : '';
    
    return browserExtensionErrors.some(pattern => 
      errorMessage.includes(pattern) || 
      errorString.includes(pattern) ||
      stack.includes(pattern)
    );
  };
  
  // Store original console.error to restore if needed
  const originalConsoleError = console.error.bind(console);
  
  // Intercept console.error to filter browser extension errors
  console.error = (...args: unknown[]) => {
    const errorText = args.map(arg => String(arg)).join(' ');
    if (isBrowserExtensionError(errorText)) {
      // Suppress browser extension errors in console
      return;
    }
    // Call original console.error for legitimate errors
    originalConsoleError(...args);
  };
  
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
    if (isBrowserExtensionError(event.reason)) {
      // Suppress browser extension errors - they're harmless and clutter the console
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    
    // Log other unhandled rejections for debugging (development only)
    // In production, these should be sent to error tracking service
    if ((window as unknown as { __DEV__?: boolean }).__DEV__) {
      console.warn('Unhandled promise rejection:', event.reason);
    }
  }, true); // Use capture phase to catch early
  
  // Handle global errors (catch-all for any remaining errors)
  window.addEventListener('error', (event: ErrorEvent) => {
    if (isBrowserExtensionError(event.error || event.message)) {
      // Suppress browser extension errors
      event.preventDefault();
      event.stopPropagation();
      return;
    }
  }, true);
}

bootstrapApplication(App, appConfig)
  .catch((err: unknown) => console.error(err));
