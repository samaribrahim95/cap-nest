/**
 * App Root Component
 * 
 * Main application component orchestrating all landing page sections.
 * Includes Zoho form wrapper for lead capture.
 * 
 * @fileoverview Root component for CapNest landing page
 */

import { Component, signal, OnInit, inject } from '@angular/core';
import { Navbar } from './components/navbar/navbar';
import { HeroSection } from './components/hero-section/hero-section';
import { StatsSection } from './components/stats-section/stats-section';
import { HowItWorksSection } from './components/how-it-works-section/how-it-works-section';
import { BenefitsSection } from './components/benefits-section/benefits-section';
import { PropertiesSection } from './components/properties-section/properties-section';
import { TestimonialsSection } from './components/testimonials-section/testimonials-section';
import { CTASection } from './components/ctasection/ctasection';
import { Footer } from './components/footer/footer';
import { AnalyticsService } from './services/analytics.service';
import { initPerformanceOptimizations } from './utils/performance-optimizer';
import { runComprehensiveTests, logComprehensiveTestResults } from './utils/comprehensive-test-runner';
import { runSynthesisSquadTests } from './utils/synthesis-squad-orchestrator';

@Component({
  selector: 'app-root',
  imports: [
    Navbar,
    HeroSection,
    StatsSection,
    HowItWorksSection,
    BenefitsSection,
    PropertiesSection,
    TestimonialsSection,
    CTASection,
    Footer,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly title = signal('cap-nest');
  
  /**
   * Analytics service injection
   */
  private readonly analyticsService = inject(AnalyticsService);

  ngOnInit(): void {
    // Initialize performance optimizations
    if (typeof window !== 'undefined') {
      initPerformanceOptimizations();
    }
    
    // Track initial page view
    this.analyticsService.trackPageView('/');
    
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:42',message:'App ngOnInit entry',data:{hasWindow:typeof window !== 'undefined'},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
    // #endregion
    
    // Make test runner available globally in development
    if (typeof window !== 'undefined') {
      // Dynamically import test runner to avoid build issues
      import('./utils/test-runner').then(module => {
        (window as unknown as { runAllTests: typeof module.runAllTests }).runAllTests = module.runAllTests;
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:49',message:'Test runner loaded',data:{hasRunAllTests:typeof (window as any).runAllTests === 'function'},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
        // #endregion
        console.log('🧪 Test runner loaded. Call runAllTests() in console to execute tests.');
        
        // Also load CSS checker
        import('./utils/css-checker').then(cssModule => {
          // Run CSS checks after a short delay to ensure DOM is ready
          setTimeout(() => {
            cssModule.runCSSChecks('debug-session', 'run1');
          }, 500);
        }).catch(() => {});
        
        // Run comprehensive visibility and styling checks
        setTimeout(() => {
          if (typeof document !== 'undefined') {
            // Check all sections for visibility
            const sections = [
              { id: 'benefits', name: 'Benefits' },
              { id: 'how-it-works', name: 'How It Works' },
              { id: 'testimonials', name: 'Testimonials' },
              { id: 'properties', name: 'Properties' },
              { id: 'cta', name: 'CTA' },
            ];
            
            sections.forEach(section => {
              const element = document.querySelector(`#${section.id}`);
              if (element) {
                const styles = getComputedStyle(element as HTMLElement);
                fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:visibility-check',message:`${section.name} section styles`,data:{sectionId:section.id,backgroundColor:styles.backgroundColor,backgroundImage:styles.backgroundImage,color:styles.color,opacity:styles.opacity,visibility:styles.visibility,display:styles.display,hasGradientClass:element.classList.contains('bg-gradient-benefits') || element.classList.contains('bg-cta-section')},timestamp:Date.now(),sessionId:'debug-session',runId:'run-visibility',hypothesisId:'A'})}).catch(()=>{});
              } else {
                fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:visibility-check',message:`${section.name} section not found`,data:{sectionId:section.id,found:false},timestamp:Date.now(),sessionId:'debug-session',runId:'run-visibility',hypothesisId:'A'})}).catch(()=>{});
              }
            });
            
            // Check CSS variables
            const rootStyles = getComputedStyle(document.documentElement);
            const cssVars = {
              sgdsGreen: rootStyles.getPropertyValue('--sgdsGreen'),
              sgdsGreenLight: rootStyles.getPropertyValue('--sgdsGreen-light'),
              sgdsGreenDark: rootStyles.getPropertyValue('--sgdsGreen-dark'),
              colorSgdsGreen: rootStyles.getPropertyValue('--color-sgdsGreen'),
            };
            fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:css-vars-check',message:'CSS variables check',data:cssVars,timestamp:Date.now(),sessionId:'debug-session',runId:'run-visibility',hypothesisId:'B'})}).catch(()=>{});
          }
        }, 2000);
        
        // Load SYNTHESIS SQUAD orchestrator
        import('./utils/synthesis-squad-orchestrator').then(squadModule => {
          (window as unknown as { runSynthesisSquadTests: typeof squadModule.runSynthesisSquadTests }).runSynthesisSquadTests = squadModule.runSynthesisSquadTests;
          console.log('🚀 SYNTHESIS SQUAD orchestrator loaded. Call runSynthesisSquadTests() in console to execute comprehensive tests.');
        }).catch(() => {});
        
        // Run comprehensive tests after page load
        if (document.readyState === 'complete') {
          runComprehensiveTests().then(logComprehensiveTestResults);
          // Also run SYNTHESIS SQUAD tests
          setTimeout(() => {
            runSynthesisSquadTests('synthesis-squad-session', 'run1').then(report => {
              console.log('📊 SYNTHESIS SQUAD Report:', report);
            });
          }, 2000);
        } else {
          window.addEventListener('load', () => {
            setTimeout(() => {
              runComprehensiveTests().then(logComprehensiveTestResults);
              // Also run SYNTHESIS SQUAD tests
              setTimeout(() => {
                runSynthesisSquadTests('synthesis-squad-session', 'run1').then(report => {
                  console.log('📊 SYNTHESIS SQUAD Report:', report);
                });
              }, 2000);
            }, 1000);
          });
        }
      }).catch((error) => {
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app.ts:60',message:'Test runner load failed',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'E'})}).catch(()=>{});
        // #endregion
        console.warn('Test runner not available. Tests can be run manually.');
      });
    }
  }
}
