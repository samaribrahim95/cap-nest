/**
 * Zoho Form Wrapper Component
 * 
 * Embeds Zoho waiting list form (https://zfrmz.sa/PnG9yx0hykI0YxroY6Mi)
 * with RTL compatibility, responsive iframe styling, and accessibility compliance.
 * 
 * Implements Vercel Design Guidelines:
 * - Loading states with minimum duration (150-300ms show delay, 300-500ms minimum visible)
 * - Error handling with recovery instructions
 * - Responsive sizing (mobile-first)
 * - Accessibility: Proper iframe title, ARIA labels
 * 
 * @fileoverview Zoho form embedding component
 */

import { Component, signal, inject, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-zoho-form-wrapper',
  imports: [CommonModule],
  templateUrl: './zoho-form-wrapper.html',
  styleUrl: './zoho-form-wrapper.css',
})
export class ZohoFormWrapper implements OnInit, AfterViewInit {
  /**
   * Language service injection
   * Protected to allow template access
   */
  protected readonly languageService = inject(LanguageService);

  /**
   * DomSanitizer for safe URL handling
   */
  private readonly sanitizer = inject(DomSanitizer);

  /**
   * Zoho form URL (sanitized for iframe)
   */
  readonly formUrl: SafeResourceUrl;

  constructor() {
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-wrapper.ts:44',message:'ZohoFormWrapper constructor entry',data:{hasSanitizer:!!this.sanitizer,hasLanguageService:!!this.languageService},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'C'})}).catch(()=>{});
    // #endregion
    
    try {
      // Sanitize the URL to allow it in iframe src
      this.formUrl = this.sanitizer.bypassSecurityTrustResourceUrl('https://zfrmz.sa/PnG9yx0hykI0YxroY6Mi');
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-wrapper.ts:49',message:'Form URL sanitized',data:{hasFormUrl:!!this.formUrl},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'C'})}).catch(()=>{});
      // #endregion
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-wrapper.ts:52',message:'ZohoFormWrapper constructor error',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'C'})}).catch(()=>{});
      // #endregion
      console.error('ZohoFormWrapper initialization error:', error);
      // Fallback: assign a sanitized empty URL to ensure formUrl is always assigned
      this.formUrl = this.sanitizer.bypassSecurityTrustResourceUrl('about:blank');
    }
  }

  /**
   * Loading state signal
   */
  readonly isLoading = signal<boolean>(true);

  /**
   * Error state signal
   */
  readonly hasError = signal<boolean>(false);

  /**
   * Iframe loaded state
   */
  readonly isLoaded = signal<boolean>(false);

  /**
   * Minimum loading display time (per Vercel Guidelines: 300-500ms)
   */
  private readonly minLoadingTime = 300;

  /**
   * Loading start time
   */
  private loadingStartTime = 0;

  ngOnInit(): void {
    this.loadingStartTime = Date.now();
  }

  /**
   * Handle iframe load event
   */
  onIframeLoad(): void {
    const elapsed = Date.now() - this.loadingStartTime;
    const remainingTime = Math.max(0, this.minLoadingTime - elapsed);

    setTimeout(() => {
      this.isLoading.set(false);
      this.isLoaded.set(true);
    }, remainingTime);
  }

  /**
   * Handle iframe error
   */
  onIframeError(): void {
    this.isLoading.set(false);
    this.hasError.set(true);
  }

  /**
   * Retry loading form
   */
  retry(): void {
    this.hasError.set(false);
    this.isLoading.set(true);
    this.loadingStartTime = Date.now();
    // Force iframe reload by updating src
    const iframe = document.querySelector('iframe[data-zoho-form]') as HTMLIFrameElement;
    if (iframe) {
      // Reload iframe by reassigning the sanitized URL
      // The formUrl is already sanitized, so we can use it directly
      // For retry, we need to extract the URL string from SafeResourceUrl
      const urlString = this.formUrl as unknown as string;
      if (urlString) {
        iframe.src = urlString;
      }
    }
  }

  /**
   * Get current language for iframe title
   */
  getFormTitle(): string {
    const lang = this.languageService.getCurrentLanguage();
    return lang === 'ar' 
      ? 'نموذج قائمة الانتظار CapNest' 
      : 'CapNest Waiting List Form';
  }

  ngAfterViewInit(): void {
    // Ensure minimum loading time is respected
    if (this.isLoading()) {
      const elapsed = Date.now() - this.loadingStartTime;
      if (elapsed < this.minLoadingTime) {
        setTimeout(() => {
          if (this.isLoading() && !this.isLoaded()) {
            // Still loading after minimum time, show loading state
          }
        }, this.minLoadingTime - elapsed);
      }
    }
  }
}
