/**
 * Social Media Configuration Model
 * 
 * TypeScript interfaces for social media channel configuration.
 * All URLs and emails are editable placeholders that can be updated later.
 * 
 * @fileoverview Social media configuration types
 */

/**
 * Social media channel configuration
 */
export interface SocialMediaChannel {
  /** Platform name */
  name: string;
  /** Display label (Arabic/English) */
  label: string;
  /** URL or email address (editable placeholder) */
  url: string;
  /** Icon identifier (for FontAwesome or similar) */
  icon: string;
  /** Whether this is an email link */
  isEmail: boolean;
  /** ARIA label for accessibility */
  ariaLabel: string;
}

/**
 * Social media configuration object
 * All values are placeholders and can be edited
 */
export interface SocialMediaConfig {
  linkedin: SocialMediaChannel;
  facebook: SocialMediaChannel;
  instagram: SocialMediaChannel;
  medium: SocialMediaChannel;
  crunchbase: SocialMediaChannel;
  email: SocialMediaChannel;
}

/**
 * Default social media configuration with editable placeholders
 */
export const DEFAULT_SOCIAL_MEDIA_CONFIG: SocialMediaConfig = {
  linkedin: {
    name: 'LinkedIn',
    label: 'LinkedIn',
    url: 'https://www.linkedin.com/company/capnest', // EDITABLE PLACEHOLDER
    icon: 'faLinkedin',
    isEmail: false,
    ariaLabel: 'Visit CapNest on LinkedIn',
  },
  facebook: {
    name: 'Facebook',
    label: 'Facebook',
    url: 'https://www.facebook.com/capnest', // EDITABLE PLACEHOLDER
    icon: 'faFacebook',
    isEmail: false,
    ariaLabel: 'Visit CapNest on Facebook',
  },
  instagram: {
    name: 'Instagram',
    label: 'Instagram',
    url: 'https://www.instagram.com/capnest', // EDITABLE PLACEHOLDER
    icon: 'faInstagram',
    isEmail: false,
    ariaLabel: 'Visit CapNest on Instagram',
  },
  medium: {
    name: 'Medium',
    label: 'Medium',
    url: 'https://medium.com/@capnest', // EDITABLE PLACEHOLDER
    icon: 'faMedium',
    isEmail: false,
    ariaLabel: 'Read CapNest on Medium',
  },
  crunchbase: {
    name: 'Crunchbase',
    label: 'Crunchbase',
    url: 'https://www.crunchbase.com/organization/capnest', // EDITABLE PLACEHOLDER
    icon: 'faBuilding',
    isEmail: false,
    ariaLabel: 'View CapNest on Crunchbase',
  },
  email: {
    name: 'Email',
    label: 'Email',
    url: 'mailto:info@capnest.sa', // EDITABLE PLACEHOLDER
    icon: 'faEnvelope',
    isEmail: true,
    ariaLabel: 'Send email to CapNest',
  },
};
