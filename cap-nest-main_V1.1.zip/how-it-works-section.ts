/**
 * How It Works Section Component
 * 
 * Redesigned from scratch per PRD Section 6.3.4 and Vercel Design Guidelines.
 * Features:
 * - Three steps per PRD 6.3.4:
 *   Step 1: Sign Up & Capture Lead Details
 *   Step 2: Choose Property (first asset)
 *   Step 3: Invest & Earn (roadmap)
 * - RTL-optimized layout
 * - Numbered indicators
 * 
 * @fileoverview How It Works section with three steps
 */

import { Component, inject, computed } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faUserPlus, faBuilding, faChartLine } from '@fortawesome/free-solid-svg-icons';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-how-it-works-section',
  imports: [FontAwesomeModule],
  templateUrl: './how-it-works-section.html',
  styleUrl: './how-it-works-section.css',
})
export class HowItWorksSection {
  /**
   * Language service injection
   */
  private readonly languageService = inject(LanguageService);

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * Steps per PRD 6.3.4
   */
  readonly steps = computed(() => {
    const lang = this.currentLang();
    return [
    {
        icon: faUserPlus,
      number: '01',
        title: lang === 'ar' ? 'سجل وانضم' : 'Sign Up & Join',
        description: lang === 'ar' 
          ? 'سوي حسابك المجاني واملأ بياناتك الأساسية للانضمام إلى قائمة الانتظار.'
          : 'Create your free account and fill in your basic details to join the waiting list.',
    },
    {
        icon: faBuilding,
      number: '02',
        title: lang === 'ar' ? 'اختر العقار' : 'Choose Property',
        description: lang === 'ar'
          ? 'شوف أول عقار متاح من خلال Digishares واختر حصتك الاستثمارية.'
          : 'Browse the first available property through Digishares and choose your investment share.',
    },
    {
        icon: faChartLine,
      number: '03',
        title: lang === 'ar' ? 'استثمر واربح' : 'Invest & Earn',
        description: lang === 'ar'
          ? 'استثمر وابدأ تجني العوائد الشهرية من استثماراتك العقارية.'
          : 'Invest and start earning monthly returns from your real estate investments.',
    },
  ];
  });
}
