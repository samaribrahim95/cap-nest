/**
 * Zoho Form Modal Component
 * 
 * Modal component for Zoho waiting list form with:
 * - Responsive iframe modal with scaled borders
 * - Saudi Arabic dialect CTA for Arabic version
 * - English CTA for English version
 * - Culturally appropriate thank you message after submission
 * 
 * @fileoverview Modal wrapper for Zoho form with cultural localization
 */

import { Component, signal, inject, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { LanguageService } from '../../services/language.service';
import { AnalyticsService } from '../../services/analytics.service';

@Component({
  selector: 'app-zoho-form-modal',
  imports: [CommonModule],
  templateUrl: './zoho-form-modal.html',
  styleUrl: './zoho-form-modal.css',
})
export class ZohoFormModal {
  /**
   * Language service injection
   */
  protected readonly languageService = inject(LanguageService);
  
  /**
   * Analytics service injection
   */
  private readonly analyticsService = inject(AnalyticsService);

  /**
   * DomSanitizer for safe URL handling
   */
  private readonly sanitizer = inject(DomSanitizer);

  /**
   * Zoho form URL (sanitized for iframe)
   */
  readonly formUrl: SafeResourceUrl;

  /**
   * Modal open state
   */
  readonly isOpen = signal<boolean>(false);

  /**
   * Form submitted state
   */
  readonly isSubmitted = signal<boolean>(false);

  /**
   * Loading state
   */
  readonly isLoading = signal<boolean>(true);

  /**
   * Error state
   */
  readonly hasError = signal<boolean>(false);

  /**
   * Loading timeout (10 seconds)
   */
  private loadingTimeout?: ReturnType<typeof setTimeout>;

  /**
   * Current language (computed)
   */
  readonly currentLang = computed(() => this.languageService.getCurrentLanguage());

  /**
   * CTA text based on language (Saudi Arabic dialect for Arabic)
   */
  readonly ctaText = computed(() => {
    const lang = this.currentLang();
    return lang === 'ar' 
      ? 'سجل في قائمة الانتظار' // Saudi Arabic dialect
      : 'Join the Waiting List';
  });

  /**
   * Thank you message based on language
   */
  readonly thankYouMessage = computed(() => {
    const lang = this.currentLang();
    return lang === 'ar'
      ? {
          title: 'الله يعطيك العافية!',
          message: 'تم استلام طلبك بنجاح. راح نتواصل معك قريباً عبر البريد الإلكتروني أو الجوال.',
          closeButton: 'إغلاق'
        }
      : {
          title: 'Thank You!',
          message: 'Your request has been received successfully. We will contact you soon via email or phone.',
          closeButton: 'Close'
        };
  });

  constructor() {
    // Validate and sanitize the URL to allow it in iframe src
    const formUrl = 'https://zfrmz.sa/PnG9yx0hykI0YxroY6Mi';
    // Additional validation: ensure URL is safe
    if (formUrl.startsWith('https://') && (formUrl.includes('zfrmz.sa') || formUrl.includes('zoho.com'))) {
      this.formUrl = this.sanitizer.bypassSecurityTrustResourceUrl(formUrl);
    } else {
      // Fallback to blank if URL is invalid
      this.formUrl = this.sanitizer.bypassSecurityTrustResourceUrl('about:blank');
    }
    
    // Listen for form submission messages from iframe
    if (typeof window !== 'undefined') {
      window.addEventListener('message', (event) => {
        // Verify origin for security
        if (event.origin === 'https://zfrmz.sa' || event.origin.includes('zoho')) {
          if (event.data && event.data.type === 'zoho-form-submit') {
            this.handleFormSubmit();
          }
        }
      });
      
      // Listen for custom event to open modal (fallback for components that can't access viewChild)
      // Use once: false to allow multiple opens
      window.addEventListener('open-zoho-modal', () => {
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:127',message:'Custom event received to open modal',data:{isOpen:this.isOpen(),modalComponent:!!this},timestamp:Date.now(),sessionId:'debug-session',runId:'run5',hypothesisId:'J'})}).catch(()=>{});
        // #endregion
        // Always try to open - the openModal method handles state
        try {
          this.openModal();
          // #region agent log
          fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:134',message:'Modal opened via custom event',data:{isOpen:this.isOpen()},timestamp:Date.now(),sessionId:'debug-session',runId:'run5',hypothesisId:'J'})}).catch(()=>{});
          // #endregion
        } catch (error) {
          // #region agent log
          fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:138',message:'Error opening modal from custom event',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run5',hypothesisId:'J'})}).catch(()=>{});
          // #endregion
          console.error('Error opening modal from custom event:', error);
        }
      }, { once: false }); // Allow multiple event listeners
    }
  }

  /**
   * Open modal
   */
  openModal(): void {
    // Track modal open event
    this.analyticsService.trackEvent('waiting_list_modal_opened', {
      language: this.currentLang(),
    });
    try {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:113',message:'openModal called',data:{currentState:this.isOpen()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
      // #endregion
      
      // Reset states
      this.isOpen.set(true);
      this.isLoading.set(true);
      this.hasError.set(false);
      this.isSubmitted.set(false);
      
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:122',message:'Modal state set to open',data:{isOpen:this.isOpen(),isLoading:this.isLoading()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
      // #endregion
      
      // Set loading timeout (30 seconds) - Zoho forms can take time to load, especially on slow connections
      this.loadingTimeout = setTimeout(() => {
        if (this.isLoading()) {
          // #region agent log
          fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:128',message:'Loading timeout reached',data:{isLoading:this.isLoading()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
          // #endregion
          
          // Check if iframe exists and has content - try multiple selectors
          let iframe = document.querySelector('iframe[data-zoho-form]') as HTMLIFrameElement;
          if (!iframe) {
            iframe = document.querySelector('.zoho-form-iframe') as HTMLIFrameElement;
          }
          if (!iframe) {
            iframe = document.querySelector('iframe[src*="zfrmz.sa"]') as HTMLIFrameElement;
          }
          
          // #region agent log
          fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:133',message:'Checking iframe after timeout',data:{hasIframe:!!iframe,hasContentWindow:!!iframe?.contentWindow,iframeSrc:iframe?.src,iframeReadyState:iframe?.contentDocument?.readyState},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
          // #endregion
          
          if (iframe) {
            // Iframe exists - check if it has loaded content
            try {
              // Try to access iframe content (may fail due to CORS)
              const hasContent = iframe.contentDocument && iframe.contentDocument.readyState === 'complete';
              if (hasContent || iframe.contentWindow) {
                // Iframe has content or content window, consider it loaded
                // #region agent log
                fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:138',message:'Iframe found with content, clearing loading',data:{hasContent},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
                // #endregion
                this.isLoading.set(false);
                this.hasError.set(false);
              } else {
                // Iframe exists but no content yet - give it more time or show error
                // #region agent log
                fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:144',message:'Iframe exists but no content detected',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
                // #endregion
                // Don't show error yet - the load event might still fire
              }
            } catch (e) {
              // CORS error accessing iframe content - this is normal, iframe might still be loading
              // #region agent log
              fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:149',message:'CORS error checking iframe - normal, iframe may still be loading',data:{error:String(e)},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
              // #endregion
              // Iframe exists, assume it's loading - don't show error yet
              // The load event should fire when ready
            }
          } else {
            // No iframe found - this is a problem
            // #region agent log
            fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:155',message:'Iframe not found in DOM - template rendering issue',data:{isOpen:this.isOpen(),isLoading:this.isLoading(),hasError:this.hasError()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
            // #endregion
            this.isLoading.set(false);
            this.hasError.set(true);
          }
        }
      }, 30000); // Increased to 30 seconds for very slow connections
      
      // Prevent body scroll when modal is open
      if (typeof document !== 'undefined') {
        document.body.style.overflow = 'hidden';
        // #region agent log
        fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:183',message:'Body scroll disabled',data:{overflow:document.body.style.overflow},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
        // #endregion
        
        // Wait for Angular change detection to render the iframe, then verify it exists
        // Use multiple checks with increasing delays to catch the iframe as soon as it renders
        const checkIframe = (attempt: number, maxAttempts: number = 5) => {
          setTimeout(() => {
            let iframe = document.querySelector('iframe[data-zoho-form]') as HTMLIFrameElement;
            if (!iframe) {
              iframe = document.querySelector('.zoho-form-iframe') as HTMLIFrameElement;
            }
            if (!iframe) {
              iframe = document.querySelector('iframe[src*="zfrmz.sa"]') as HTMLIFrameElement;
            }
            
            // #region agent log
            fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:188',message:`Checking iframe after Angular change detection (attempt ${attempt})`,data:{hasIframe:!!iframe,iframeSrc:iframe?.src,isLoading:this.isLoading(),attempt,maxAttempts},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
            // #endregion
            
            if (iframe) {
              // Iframe found - it's rendering correctly
              // #region agent log
              fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:195',message:'Iframe found in DOM',data:{iframeSrc:iframe.src},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
              // #endregion
              // The load event will handle clearing the loading state
            } else if (attempt < maxAttempts && this.isLoading()) {
              // Iframe not found yet, try again
              checkIframe(attempt + 1, maxAttempts);
            } else if (!iframe && this.isLoading()) {
              // Iframe still not found after all attempts
              // #region agent log
              fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:202',message:'Iframe not found after all attempts',data:{isOpen:this.isOpen(),isLoading:this.isLoading(),hasError:this.hasError()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
              // #endregion
              // Don't show error immediately - wait for load event or timeout
            }
          }, attempt * 100); // Staggered checks: 100ms, 200ms, 300ms, etc.
        };
        
        // Start checking for iframe
        checkIframe(1, 10); // Check up to 10 times (1 second total)
      }
    } catch (error) {
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:149',message:'Error in openModal',data:{error:String(error)},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
      // #endregion
      console.error('Error opening modal:', error);
    }
  }

  /**
   * Close modal
   */
  closeModal(): void {
    // Clear loading timeout
    if (this.loadingTimeout) {
      clearTimeout(this.loadingTimeout);
      this.loadingTimeout = undefined;
    }
    
    this.isOpen.set(false);
    this.isSubmitted.set(false);
    this.isLoading.set(true); // Reset for next open
    this.hasError.set(false);
    
    // Restore body scroll
    if (typeof document !== 'undefined') {
      document.body.style.overflow = '';
    }
  }

  /**
   * Handle form submission
   */
  handleFormSubmit(): void {
    // Track form submission
    this.analyticsService.trackConversion('waiting_list_submitted', {
      language: this.currentLang(),
    });
    this.isSubmitted.set(true);
    this.isLoading.set(false);
  }

  /**
   * Handle iframe load
   */
  onIframeLoad(): void {
    // Clear loading timeout if it exists
    if (this.loadingTimeout) {
      clearTimeout(this.loadingTimeout);
      this.loadingTimeout = undefined;
    }
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:275',message:'Iframe load event fired',data:{isLoading:this.isLoading(),hasError:this.hasError(),isOpen:this.isOpen()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
    // #endregion
    
    // Only clear loading if modal is still open and not submitted
    if (this.isOpen() && !this.isSubmitted()) {
      this.isLoading.set(false);
      this.hasError.set(false);
      
      // #region agent log
      fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:283',message:'Loading state cleared after iframe load',data:{isLoading:this.isLoading(),hasError:this.hasError()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
      // #endregion
    }
  }

  /**
   * Handle iframe error
   */
  onIframeError(): void {
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:200',message:'Iframe error event fired',data:{isLoading:this.isLoading()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
    // #endregion
    
    // Clear loading timeout
    if (this.loadingTimeout) {
      clearTimeout(this.loadingTimeout);
      this.loadingTimeout = undefined;
    }
    
    this.isLoading.set(false);
    this.hasError.set(true);
    
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'zoho-form-modal.ts:212',message:'Error state set',data:{isLoading:this.isLoading(),hasError:this.hasError()},timestamp:Date.now(),sessionId:'debug-session',runId:'run3',hypothesisId:'H'})}).catch(()=>{});
    // #endregion
  }

  /**
   * Get form title based on language
   */
  getFormTitle(): string {
    const lang = this.currentLang();
    return lang === 'ar'
      ? 'نموذج قائمة الانتظار CapNest'
      : 'CapNest Waiting List Form';
  }

  /**
   * Handle escape key to close modal
   */
  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && this.isOpen()) {
      this.closeModal();
    }
  }
}
