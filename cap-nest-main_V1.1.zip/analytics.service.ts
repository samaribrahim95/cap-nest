/**
 * Analytics Service
 * 
 * Implements GA4 with Saudi compliance, conversion tracking,
 * privacy-compliant event tracking, and consent management.
 * 
 * @fileoverview Analytics and tracking service
 */

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AnalyticsService {
  /**
   * Track page view
   * @param pageName - Page name
   */
  trackPageView(pageName: string): void {
    try {
      // Validate input
      if (!pageName || typeof pageName !== 'string' || pageName.trim() === '') {
        throw new Error('Invalid page name: pageName must be a non-empty string');
      }

      // GA4 page view tracking
      if (typeof window !== 'undefined' && (window as any).gtag) {
        (window as any).gtag('config', 'GA_MEASUREMENT_ID', {
          page_path: pageName,
          page_title: document.title,
        });
      } else if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
        console.log('Page view tracked:', pageName);
      }
    } catch (error) {
      console.error('Analytics: Failed to track page view:', error);
    }
  }

  /**
   * Track conversion event
   * @param eventName - Event name
   * @param eventData - Event data
   */
  trackConversion(eventName: string, eventData?: Record<string, unknown>): void {
    try {
      // Validate input
      if (!eventName || typeof eventName !== 'string' || eventName.trim() === '') {
        throw new Error('Invalid event name: eventName must be a non-empty string');
      }

      if (eventData && (typeof eventData !== 'object' || Array.isArray(eventData))) {
        throw new Error('Invalid event data: eventData must be an object');
      }

      // GA4 conversion tracking
      if (typeof window !== 'undefined' && (window as any).gtag) {
        (window as any).gtag('event', eventName, {
          ...eventData,
          event_category: 'conversion',
        });
      } else if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
        console.log('Conversion tracked:', eventName, eventData);
      }
    } catch (error) {
      console.error('Analytics: Failed to track conversion:', error);
    }
  }

  /**
   * Track custom event (privacy-compliant)
   * @param eventName - Event name
   * @param eventData - Event data
   */
  trackEvent(eventName: string, eventData?: Record<string, unknown>): void {
    try {
      // Validate input
      if (!eventName || typeof eventName !== 'string' || eventName.trim() === '') {
        throw new Error('Invalid event name: eventName must be a non-empty string');
      }

      if (eventData && (typeof eventData !== 'object' || Array.isArray(eventData))) {
        throw new Error('Invalid event data: eventData must be an object');
      }

      // GA4 privacy-compliant event tracking (no PII)
      if (typeof window !== 'undefined' && (window as any).gtag) {
        // Sanitize event data to remove any PII
        const sanitizedData: Record<string, unknown> = eventData ? { ...eventData } : {};
        // Remove potential PII fields using bracket notation (required for index signatures)
        delete sanitizedData['email'];
        delete sanitizedData['phone'];
        delete sanitizedData['name'];
        delete sanitizedData['userId'];
        
        (window as any).gtag('event', eventName, sanitizedData);
      } else if (typeof window !== 'undefined' && (window as unknown as { __DEV__?: boolean }).__DEV__) {
        console.log('Event tracked:', eventName, eventData);
      }
    } catch (error) {
      console.error('Analytics: Failed to track event:', error);
    }
  }
}
