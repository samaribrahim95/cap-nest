/**
 * Test Runner Utility for CapNest Landing Page
 * 
 * Comprehensive testing utility that can be injected into components
 * for runtime testing and logging.
 * 
 * @fileoverview Test runner with logging integration
 */

const LOG_ENDPOINT = 'http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62';

export interface TestResult {
  category: string;
  testName: string;
  status: 'PASS' | 'FAIL' | 'WARNING' | 'SKIP';
  details?: Record<string, unknown>;
  timestamp: number;
}

/**
 * Log test result to debug endpoint
 */
export function logTestResult(
  sessionId: string,
  runId: string,
  category: string,
  testName: string,
  status: 'PASS' | 'FAIL' | 'WARNING' | 'SKIP',
  details?: Record<string, unknown>
): void {
  const logEntry = {
    sessionId,
    runId,
    testCategory: category,
    testName,
    status,
    details: details || {},
    timestamp: Date.now(),
    location: 'test-runner.ts',
    message: `Test: ${category} - ${testName}`,
  };

  // Send via HTTP (non-blocking)
  fetch(LOG_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(logEntry),
  }).catch(() => {
    // Silently fail if logging server unavailable
    console.warn('Test logging failed:', logEntry);
  });
}

/**
 * Run UI/Visual Tests
 */
export function runUITests(sessionId: string, runId: string): TestResult[] {
  const results: TestResult[] = [];

  // Test 1: Check main components exist
  const navbar = document.querySelector('app-navbar');
  const hero = document.querySelector('app-hero-section');
  const stats = document.querySelector('app-stats-section');
  const footer = document.querySelector('app-footer');

  const test1: TestResult = {
    category: 'UI',
    testName: 'Main components exist',
    status: (navbar && hero && stats && footer) ? 'PASS' : 'FAIL',
    details: {
      navbar: !!navbar,
      hero: !!hero,
      stats: !!stats,
      footer: !!footer,
    },
    timestamp: Date.now(),
  };
  results.push(test1);
  logTestResult(sessionId, runId, test1.category, test1.testName, test1.status, test1.details);

  // Test 2: SGDS color check
  const styles = getComputedStyle(document.documentElement);
  const primaryColor = styles.getPropertyValue('--color-sgds-green');
  const test2: TestResult = {
    category: 'UI',
    testName: 'SGDS color defined',
    status: primaryColor ? 'PASS' : 'WARNING',
    details: { color: primaryColor },
    timestamp: Date.now(),
  };
  results.push(test2);
  logTestResult(sessionId, runId, test2.category, test2.testName, test2.status, test2.details);

  // Test 3: RTL direction
  const htmlDir = document.documentElement.dir;
  const htmlLang = document.documentElement.lang;
  const test3: TestResult = {
    category: 'UI',
    testName: 'RTL direction set',
    status: htmlDir === 'rtl' ? 'PASS' : 'WARNING',
    details: { dir: htmlDir, lang: htmlLang },
    timestamp: Date.now(),
  };
  results.push(test3);
  logTestResult(sessionId, runId, test3.category, test3.testName, test3.status, test3.details);

  return results;
}

/**
 * Run Functional/QA Tests
 */
export function runFunctionalTests(sessionId: string, runId: string): TestResult[] {
  const results: TestResult[] = [];

  // Test 1: Navigation links
  const navLinks = document.querySelectorAll('nav a[href]');
  const test1: TestResult = {
    category: 'QA',
    testName: 'Navigation links exist',
    status: navLinks.length > 0 ? 'PASS' : 'FAIL',
    details: { count: navLinks.length },
    timestamp: Date.now(),
  };
  results.push(test1);
  logTestResult(sessionId, runId, test1.category, test1.testName, test1.status, test1.details);

  // Test 2: Language toggle
  const langToggle = document.querySelector('button[aria-label*="Switch"], button[aria-label*="التبديل"]');
  const test2: TestResult = {
    category: 'QA',
    testName: 'Language toggle exists',
    status: langToggle ? 'PASS' : 'FAIL',
    timestamp: Date.now(),
  };
  results.push(test2);
  logTestResult(sessionId, runId, test2.category, test2.testName, test2.status);

  // Test 3: Zoho form
  const zohoForm = document.querySelector('app-zoho-form-wrapper');
  const test3: TestResult = {
    category: 'QA',
    testName: 'Zoho form wrapper exists',
    status: zohoForm ? 'PASS' : 'FAIL',
    timestamp: Date.now(),
  };
  results.push(test3);
  logTestResult(sessionId, runId, test3.category, test3.testName, test3.status);

  // Test 4: External links security
  const externalLinks = document.querySelectorAll('a[target="_blank"]');
  let secureLinks = 0;
  externalLinks.forEach(link => {
    if (link.getAttribute('rel')?.includes('noopener')) secureLinks++;
  });
  const test4: TestResult = {
    category: 'QA',
    testName: 'External links security',
    status: externalLinks.length === 0 || externalLinks.length === secureLinks ? 'PASS' : 'FAIL',
    details: { total: externalLinks.length, secure: secureLinks },
    timestamp: Date.now(),
  };
  results.push(test4);
  logTestResult(sessionId, runId, test4.category, test4.testName, test4.status, test4.details);

  return results;
}

/**
 * Run Accessibility Tests
 */
export function runAccessibilityTests(sessionId: string, runId: string): TestResult[] {
  const results: TestResult[] = [];

  // Test 1: Touch target sizes
  const buttons = document.querySelectorAll('button, a.btn');
  let largeEnough = 0;
  buttons.forEach(btn => {
    const rect = btn.getBoundingClientRect();
    if (rect.width >= 44 && rect.height >= 44) largeEnough++;
  });
  const test1: TestResult = {
    category: 'A11y',
    testName: 'Touch target sizes (44x44px)',
    status: buttons.length === largeEnough ? 'PASS' : 'WARNING',
    details: { total: buttons.length, largeEnough },
    timestamp: Date.now(),
  };
  results.push(test1);
  logTestResult(sessionId, runId, test1.category, test1.testName, test1.status, test1.details);

  // Test 2: Semantic HTML
  const hasHeader = !!document.querySelector('header, [role="banner"]');
  const hasNav = !!document.querySelector('nav, [role="navigation"]');
  const hasFooter = !!document.querySelector('footer, [role="contentinfo"]');
  const test2: TestResult = {
    category: 'A11y',
    testName: 'Semantic HTML structure',
    status: (hasHeader && hasNav && hasFooter) ? 'PASS' : 'WARNING',
    details: { header: hasHeader, nav: hasNav, footer: hasFooter },
    timestamp: Date.now(),
  };
  results.push(test2);
  logTestResult(sessionId, runId, test2.category, test2.testName, test2.status, test2.details);

  return results;
}

/**
 * Run Performance Tests
 */
export function runPerformanceTests(sessionId: string, runId: string): TestResult[] {
  const results: TestResult[] = [];

  // Test 1: Page load time
  if (performance.timing) {
    const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
    const test1: TestResult = {
      category: 'Performance',
      testName: 'Page load time',
      status: loadTime < 3000 ? 'PASS' : 'WARNING',
      details: { loadTime },
      timestamp: Date.now(),
    };
    results.push(test1);
    logTestResult(sessionId, runId, test1.category, test1.testName, test1.status, test1.details);
  }

  // Test 2: Lazy loading images
  const lazyImages = document.querySelectorAll('img[loading="lazy"]');
  const test2: TestResult = {
    category: 'Performance',
    testName: 'Lazy loading images',
    status: lazyImages.length > 0 ? 'PASS' : 'WARNING',
    details: { count: lazyImages.length },
    timestamp: Date.now(),
  };
  results.push(test2);
  logTestResult(sessionId, runId, test2.category, test2.testName, test2.status, test2.details);

  return results;
}

/**
 * Run all tests
 */
export function runAllTests(sessionId = 'test-session', runId = 'run1'): TestResult[] {
  const allResults: TestResult[] = [];

  console.log('=== Starting Comprehensive Test Suite ===');

  allResults.push(...runUITests(sessionId, runId));
  allResults.push(...runFunctionalTests(sessionId, runId));
  allResults.push(...runAccessibilityTests(sessionId, runId));
  allResults.push(...runPerformanceTests(sessionId, runId));

  console.log('=== Test Suite Complete ===');
  console.log(`Total tests: ${allResults.length}`);
  console.log(`Passed: ${allResults.filter(r => r.status === 'PASS').length}`);
  console.log(`Failed: ${allResults.filter(r => r.status === 'FAIL').length}`);
  console.log(`Warnings: ${allResults.filter(r => r.status === 'WARNING').length}`);

  return allResults;
}

// Make available globally for console access
if (typeof window !== 'undefined') {
  (window as unknown as { runAllTests: typeof runAllTests }).runAllTests = runAllTests;
}
