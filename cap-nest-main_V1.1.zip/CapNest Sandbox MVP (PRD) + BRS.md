# CapNest Product Requirements Document V1

# CapNest Product Requirements Document V1.1

**Prepared by: *Ahmed Zayed | Product Lead* at CapNEST**

## **Table of Contents**

1. PRD Scope Governance & Phasing Overlay (Addendum)  
2. Executive Summary & Key Constraints  
3. Stakeholder Ecosystem  
   * 3.1 Internal Team & Project Delivery Stakeholders  
   * 3.2 Leadership & Executive Sponsors  
   * 3.3 External/Regulatory & Partner Stakeholders  
   * 3.4 Contextual Considerations (Non-Functional / Regulatory / Strategic)  
4. User Input & KYC Data Schema (SAMA/CMA Compliant)  
   * 4.1 Identity Verification Requirements  
   * 4.2 Data Collection & Processing Rules  
5. MVP Scope Definition  
   * 5.1 In-Scope Features (MVP Only)  
   * 5.2 Out-of-Scope Features (Post-MVP Roadmap)  
   * 5.3 Phase 0 – Current MVP Scope (Authoritative)  
   * 5.4 Phase 0 Explicit Non-Goals (Scope Lock)  
6. Landing Page Requirements  
   * 6.1 Design Principles & Saudi Government Design Standards Alignment  
   * 6.2 Technical Implementation Requirements  
   * 6.3 Core Functional Requirements  
   * 6.4 Contextual Considerations (Non-Functional / Regulatory / Strategic)  
7. User Flow: The 120-Second Journey (MVP)  
   * 7.1 Optimized User Journey  
   * 7.2 Technical Implementation Requirements  
8. Technical Architecture (MVP Simplified)  
   * 8.1 System Overview  
   * 8.2 Integration Specifications  
   * 8.3 Data Architecture (MVP)  
9. Regulatory Compliance (Sandbox Level)  
   * 9.1 Sandbox Compliance Requirements  
   * 9.2 Risk Mitigation for MVP  
10. Implementation Roadmap (3-Month MVP)  
    * 10.1 Phased Delivery Plan (MVP Only)  
    * 10.2 Critical Path Dependencies  
11. Product Roadmap (Phase-Based Scope Allocation)  
    * 11.1 Phase 0 – Landing Page and Lead Capture  
    * 11.2 Phase 1 – REG-A Onboarding  
    * 11.3 Phase 2 – Financial Enablement  
    * 11.4 Phase 3 – Scale Platform  
12. Success Metrics & KPIs (MVP Phase)  
    * 12.1 Critical MVP Metrics  
    * 12.2 MVP Launch Criteria  
13. Appendix: MVP Technical Specifications  
    * 13.1 Digishares Integration Specification  
    * 13.2 IBAN Integration Specification  
    * 13.3 Yakeen Integration Specification  
    * 13.4 Payment Gateway Integration Specification  
14. Next Steps & Accountability  
    * 14.1 Immediate Actions (Next 48 Hours)  
    * 14.2 Accountability Matrix  
    * 14.3 Decision Ownership Matrix  
15. Appendices  
    * 15.1 References & Sources  
    * 15.2 Glossary

## **1\. PRD Scope Governance & Phasing Overlay \[CURRENT – PHASE 0\]**

This document represents a multi-phase delivery model for CapNest's product evolution. Only Phase 0 is currently execution-ready and approved for immediate development. All other features described in this document are roadmap-bound and will be implemented in subsequent phases pending regulatory approvals, stakeholder validation, and market readiness assessments.

This section acts as an interpretive lens for the entire document, providing context for feature prioritization without altering original specifications.

## **2\. Executive Summary & Key Constraints \[CURRENT – PHASE 0\]**

Core Value \[CURRENT – PHASE 0\]  
CapNest MVP enables Saudi mid-income professionals to complete the journey from app download to property investment interest in under 120 seconds while maintaining 100% regulatory compliance through Yakeen identity verification and secure payment collection. \[ROADMAP – PHASE 2\]

MVP Strategic Imperatives:

1. Timeline Constraint: MVP delivery in exactly 3 months (no extensions) \[CURRENT – PHASE 0\]  
2. Scope Limitation: Only sandbox requirements included in MVP: \[CURRENT – PHASE 0\]  
   1. **Landing Page with interested investor capture \[CURRENT – PHASE 0\]**  
   2. **Basic lead management with IBAN collection for future verification \[CURRENT – PHASE 0\]**  
   3. **CRM & Invoice integration (Zoho) \[CURRENT – PHASE 0\]**  
   4. **Creation of 1st Asset using Digishares platform \[CURRENT – PHASE 0\]**  
   5. *Auth with Basic KYC "Using Yakeen" \[ROADMAP – PHASE 1\]*  
   6. *Basic User Profile "Using Digishare" \[ROADMAP – PHASE 1\]*  
3. Regulatory Alignment: 100% ***REGA's RER*** approval for compliance at sandbox level \[CURRENT – PHASE 0\]  
4. Future Roadmap: All features beyond sandbox requirements are deferrable until post-REGA's RER approval \[ROADMAP – PHASE 1+\]  
5. IBAN Integration: IBAN must be the primary payment method with full CRM and invoicing integration in Phase 0 \[CURRENT – PHASE 0\]  
6. Time Constraint: Complete "App Download to First Brick Purchase" journey in ≤120 seconds \[ROADMAP – PHASE 2\]

Resource Commitment:

* Team: 9 FTEs maximum \[CURRENT – PHASE 0\]  
* Budget: SAR 1.2M for MVP phase \[CURRENT – PHASE 0\]  
* Infrastructure: Cloud-based, no on-premise deployment \[CURRENT – PHASE 0\]  
* Launch Target: April 17, 2026 (exactly 3 months from today) \[CURRENT – PHASE 0\]

## **3\. Stakeholder Ecosystem \[CURRENT – PHASE 0\]**

### **3.1 Internal Team & Project Delivery Stakeholders \[CURRENT – PHASE 0\]**

| Name/Person | Title/Role | Area of Responsibility | Accountability |
| ----- | ----- | ----- | ----- |
| Walli | CFO | Financial oversight | Budget approval, financial reporting |
| Nawaz | PMO → Ops; ERP; Communication; Project Associate | PMO, Operations, ERP, Communication | Project coordination, timeline management |
| Azzam | CBO | Chief Business Officer | Business development strategy |
| Hany | CDO | Chief Digital Officer | Digital strategy, marketing oversight |
| Ahmed Zayed | Product, Onboarding, Compliance/Regulatory lead, Risk Register | Product management, regulatory compliance, oversee investment readiness | Compliance execution, risk mitigation |
| Miran | Delivery, PM, Relationships; APIs list; Cybersecurity audit; Payment Gateway/IBAN | Delivery, integrations, cybersecurity | Payment gateway integration, security validation |
| Osama Leading (Umair) | Engineering, Full stack & architect, Front-end, API integration, Hosting & DevOps | Engineering lead | Technical architecture, development execution |
| Christeen | Business and Financial planning, DataRoom, pitch deck sprint | Market Research, Business model, business plan, pitch deck preparation, Data room & profile management | Investment readiness sprint planning, Data room setup |
| Zinab | QA | Engineering support | UTA, QA |
| Njoud | Marketing → HANY | Marketing execution | Marketing strategy implementation |
| Yasser | PenTest | Penetration Testing/Security | Security validation |
| Handy | Branding Activities | Branding oversight | Branding strategy |
| Consultant/Reviewer | Compliance checklist, Risk Register final version | Compliance & risk review | Regulatory compliance validation |

### **3.2 Leadership & Executive Sponsors \[CURRENT – PHASE 0\]**

| Title | Name | Responsibility | Decision Authority |
| ----- | ----- | ----- | ----- |
| Chief Financial Officer | Walli | Financial strategy, budget oversight | Financial decisions, resource allocation |
| Chief Business Officer | Azzam | Business development, strategic partnerships | Business strategy, partnership approval |
| Chief Digital Officer | Hany | Digital transformation, technology strategy | Technology strategy, digital initiatives approval |
| Project Sponsor | Board-appointed | Overall project sponsorship | Final go/no-go decisions |
| Chief Compliance Officer | TBA | Compliance oversight | Regulatory compliance approval |

### **3.3 External/Regulatory & Partner Stakeholders \[CURRENT – PHASE 0\]**

| Stakeholder | Type | Relevance to Product | Engagement Frequency | Contact Person |
| ----- | ----- | ----- | ----- | ----- |
| Real Estate General Authority (REGA) | Regulatory | Primary regulator; Sandbox approval, RER integration | Monthly pre-launch, Quarterly post-launch | Compliance Team |
| Ministry of Justice (MoJ) ***"Future Phase"*** | Regulatory | Contract authentication, ownership transfer | As needed (quarterly) | Legal Team |
| Saudi Central Bank (SAMA) ***"Future Phase"*** | Regulatory | Payments, AML/KYC, Escrow | Monthly pre-launch, Quarterly post-launch | Compliance Team |
| Digishares | Technology Partner/Vendor | Whitelabel platform, API, architecture | Weekly technical meetings | Tech Lead |
| Zoho | CRM & ERP Partner | CRM and invoice integration | Bi-weekly technical meetings | Tech Lead |
| Yakeen (ELM) | Identity Provider | KYC & authentication | Weekly technical meetings | Tech Lead |
| IBAN Verification Service | Technology Partner | IBAN verification and validation | Bi-weekly technical meetings | Tech Lead |
| Payment Gateway (Moyasar/Geidea) | Technology Partner | Payment processing | Bi-weekly technical meetings \[ROADMAP – PHASE 1\] | Tech Lead |

Note: Ministry of Justice (MoJ) and Saudi Central Bank (SAMA) integrations are marked as optional for MVP phase, with full integration planned for post-sandbox phase.

### **3.4 Contextual Considerations (Non-Functional / Regulatory / Strategic) \[CURRENT – PHASE 0\]**

The Saudi regulatory environment requires a compliance-first sequencing approach to product development. Platform capabilities must be gated by regulatory approvals rather than technical feasibility alone. The phased approach reflects the progressive nature of Saudi fintech sandbox approvals and aligns with SAMA's risk-based supervision framework.

The 120-second journey optimization, while a compelling market differentiator, must be deferred until core compliance frameworks are established. This sequencing is not a technical limitation but a regulatory necessity that protects both customers and the business.

Prerequisite of Property ownership Transfer according to Real Estate Registry (RER):

1. Valid national ID or residency permit for individuals.  
2. Valid commercial registration for private establishments.  
3. The property must be registered in the Real Estate Title Registration System.  
4. Approval from relevant stakeholders (owners and rights holders).  
5. A valid power of attorney if the application is submitted by an agent.

Payment of real estate transaction tax, if applicable, and issuance of the reference number.

6. a. In case of a sale, the transfer of funds to the beneficiary's bank account may take up to three business days as of the deposit of the property value. This includes the completion of ownership transfer procedures and the availability of secure integration with relevant authorities.  
7. The national ID must be unconditional.  
8. The property must be free from rights, restrictions, or obligations, such as mortgages or usufruct rights.

All phase transitions require formal sign-off from Legal/Compliance stakeholders before proceeding to implementation.

## **4\. User Input & KYC Data Schema (SAMA/CMA Compliant) \[ROADMAP – PHASE 1\]**

### **4.1 Identity Verification Requirements \[ROADMAP – PHASE 1\]**

| Data Category | Field Name | Input Source | Validation Rule | Mandatory | Verification Method |
| ----- | ----- | ----- | ----- | ----- | ----- |
| Identity | National ID/Iqama | User Input \+ Yakeen API | 10 digits; starts with 1 or 2 | Yes | Yakeen verification |
| Identity | Date of Birth (H/G) | User Input \+ Yakeen API | Must match Yakeen records | Yes | Yakeen verification |
| Identity | Full Name (Ar/En) | Yakeen API | Immutable after verification | Yes | Yakeen verification |
| Identity | ID Expiry Date | Yakeen API | Must be \> 30 days from current date | Yes | Yakeen verification |
| Contact | Mobile Number | User Input | Saudi format (+966); verified via SMS OTP | Yes | SMS OTP verification |
| Contact | Email Address | User Input | Standard email format validation | Yes | Email confirmation |
| Financial | Employment Sector | User (Dropdown) | \[Gov, Private, SME, Retired, Unemployed\] | Yes | Self-declaration |
| Financial | Monthly Income | User (Range) | \[\<10k, 10k-20k, 20k-50k, 50k+\] | No | Self-declaration |
| Compliance | PEP Status | User (Boolean) | SAMA declaration requirement | Yes | Self-declaration \+ screening |
| Compliance | FATCA/CRS | User (Boolean) | Tax residency self-declaration | Yes | Self-declaration |

### **4.2 Data Collection & Processing Rules \[ROADMAP – PHASE 1\]**

Collection Principles:

* Minimal data collection: Only collect data required for sandbox operations and regulatory compliance  
* Progressive disclosure: Collect basic identity first, additional data only as needed  
* Explicit consent: Clear opt-in for each data usage purpose beyond regulatory requirements  
* Data retention: All KYC data retained for a minimum 7 years per SAMA requirements

Processing Security Requirements:

* All PII encrypted at rest using AES-256  
* Data transmission secured via TLS 1.3  
* Yakeen API integration using OAuth 2.0 with short-lived tokens  
* No persistent storage of raw Yakeen credentials or authentication tokens  
* All data processing within KSA territory (GCP Saudi region)

## **5\. MVP Scope Definition \[CURRENT – PHASE 0\]**

### **5.1 In-Scope Features (MVP Only) \[CURRENT – PHASE 0\]**

| Feature ID | Feature Name | Description | Priority | Timeline | Status |
| ----- | ----- | ----- | ----- | ----- | ----- |
| MVP-001 | Landing Page \[CURRENT – PHASE 0\] | Marketing page with value proposition, waiting list signup, and interested investor capture (SAR 190-380 deposit) | Critical | Week 1-2 |  |
| MVP-002 | IBAN Collection & Verification \[CURRENT – PHASE 0\] | Basic IBAN collection for future verification and CRM integration | Critical | Week 2-3 |  |
| MVP-003 | CRM & Invoice Integration \[CURRENT – PHASE 0\] | Zoho CRM integration for lead management and automated invoice generation with IBAN details | Critical | Week 3-4 |  |
| MVP-004 | First Asset Creation with Digishares \[CURRENT – PHASE 0\] | Creation of the first SPV asset using Digishares platform to demonstrate full end-to-end capability | Critical | Week 5-6 |  |
| MVP-005 | Yakeen Authentication \[ROADMAP – PHASE 1\] | Yakeen integration for identity verification with biometric confirmation | Critical | Week 2-3 |  |
| MVP-006 | Basic KYC \[ROADMAP – PHASE 1\] | Minimal KYC collection per SAMA sandbox requirements (National ID, DOB, Mobile, Email) | Critical | Week 3-4 |  |
| MVP-007 | Payment Gateway \[ROADMAP – PHASE 1\] | Integration with payment processor for collecting interested investor deposits (SAR 190-380) | Critical | Week 4-6 |  |
| MVP-008 | Basic User Profile \[ROADMAP – PHASE 1\] | Investor profile with KYC status, payment status, and asset interests using Digishares infrastructure | Critical | Week 6-8 |  |
| MVP-009 | 120-Second Journey \[ROADMAP – PHASE 2\] | Optimized user flow from app download to first investment interest | Critical | Week 10-12 |  |

### **5.2 Out-of-Scope Features (Post-MVP Roadmap) \[ROADMAP – PHASE 1+\]**

| Feature Category | Examples | Roadmap Timing |
| ----- | ----- | ----- |
| Advanced KYC | إثبات الدخل income verification, SIMA credit checks, MUQIM residency validation | Post-RER Approval |
| Fractional Ownership | Blockchain tokenization, fractional ownership issuance, cooling-off periods | Post-RER Approval |
| Secondary Market | Transfer marketplace, liquidity mechanisms | Phase 3 (Post-RER) |
| Income Distribution | Automated rental income distribution | Phase 3 (Post-RER) |
| Full Asset Pipeline | Multiple asset onboarding, developer portal | Phase 2 (Post-Sandbox) |
| Mobile Applications | iOS and Android native apps | Phase 2 (Post-Sandbox) |
| Advanced Compliance | Full AML/CFT screening, PEP monitoring | Phase 2 (Post-Sandbox) |

### **5.3 Phase 0 – Current MVP Scope (Authoritative) \[CURRENT – PHASE 0\]**

This subsection defines the only currently approved scope for immediate development. All features in this phase are strictly limited to market validation and regulatory sandbox preparation.

Phase 0 Core Components:

* Landing Page: Complete marketing page with value proposition and waiting list signup (see Section 6 for full specification)  
* Lead Capture: Basic form collection for interested investors without financial commitments (see Section 6.3.10 for form requirements)  
* IBAN Collection: Basic collection of IBAN details for future verification (see Section 13.2 for technical specifications)  
* Admin Dashboard: Basic visibility of captured leads and IBAN details in Zoho CRM (see Section 5.1 MVP-003 for CRM integration details)  
* Analytics Implementation: GA4-compliant tracking of visitor behavior and conversion funnel (see Section 6.2 for technical requirements)  
* Brand Validation: Complete implementation of Saudi Government Design Standards for messaging validation (see Section 6.1 for design requirements)  
* First Asset Creation: Creation of the first SPV asset using the Digishares platform (see Section 13.1 for technical specifications)

Key Constraint: Phase 0 explicitly excludes any financial transactions, user authentication beyond basic lead capture, or regulatory compliance beyond data privacy requirements. The first asset creation is the transition point to Phase 1\.

Success Criteria: Phase 0 will be considered successful when it validates market interest through \>500 qualified leads while maintaining 100% compliance with Saudi data protection requirements, and the first asset is successfully created on the Digishares platform.

### **5.4 Phase 0 Explicit Non-Goals (Scope Lock) \[CURRENT – PHASE 0\]**

The following capabilities are explicitly out of scope for Phase 0, despite being documented elsewhere in this PRD. These features will be addressed in subsequent roadmap phases:

* Authentication workflows  
* OTP verification systems  
* Full user account creation  
* ID verification processes  
* Yakeen/ELM integration  
* Payment processing functionality  
* Digital wallets  
* Transaction capabilities  
* Native mobile applications  
* Asset tokenization (beyond the first asset creation)  
* Blockchain integration  
* Regulatory sandbox submission beyond basic data compliance  
* Advanced KYC procedures  
* Risk scoring systems

This scope boundary is non-negotiable for Phase 0 delivery. Any requests to include these capabilities must follow the phase gate approval process outlined in the Product Roadmap section.

## **6\. Landing Page Requirements \[CURRENT – PHASE 0\]**

### **6.1 Design Principles & Saudi Government Design Standards Alignment \[CURRENT – PHASE 0\]**

The landing page must adhere to Saudi Government Design System (SGDS) principles with the following key characteristics:

Core Design Principles:

* Extreme Minimalism: Clean aesthetic with generous white space, sans-serif typography, and trust-focused color palette (green/white)  
* Regulatory Trust Focus: Prominent display of regulatory badges (REGA sandbox status) and compliance statements  
* Arabic-First Approach: RTL layout as default with Arabic content taking precedence over English  
* Mobile-Optimized: 100% mobile-responsive design with touch-friendly interactions  
* Accessibility Compliant: WCAG 2.1 AA compliance including screen reader support and color contrast ratios

Saudi Government Design Standards Requirements:

* Color palette aligned with Saudi Vision 2030 branding (green \#006C35 as primary)  
* National emblem usage in footer (when approved)  
* Ministry-approved security badges and compliance indicators  
* Clear separation of marketing vs. regulatory information  
* Mandatory privacy policy and terms of service links in footer  
* Government service integration indicators (Yakeen, Nafath)

### **6.2 Technical Implementation Requirements \[CURRENT – PHASE 0\]**

Frontend Technology Stack:

* Framework: React 18+ with TypeScript  
* Styling: Tailwind CSS with RTL support  
* Animation: Minimal, purposeful animations only (no hero videos/carousels on load)  
* Performance: Lighthouse score \>90 on mobile devices  
* Bundle Size: \<150KB for critical path

Backend Integration Points:

* CRM integration for lead capture (Zoho)  
* Analytics tracking (GA4 compliant with Saudi data laws)  
* IBAN verification API (basic collection only for Phase 0\)  
* Digishares API for first asset creation display (read-only in Phase 0\)

### **6.3 Core Functional Requirements \[CURRENT – PHASE 0\]**

#### **6.3.1 Navigation Bar Requirements \[CURRENT – PHASE 0\]**

* Fixed/sticky top navigation bar  
* Brand name "CapNest" with REGA sandbox badge  
* Navigation links: "كيف نعمل" (How It Works), "لماذا CapNest" (Why CapNest), "العقارات" (Properties), "الأسئلة الشائعة" (FAQ)  
* Language toggle (Arabic/English)  
* Call-to-action button for account creation  
* Mobile-responsive hamburger menu for small screens  
* Saudi design standards compliant (right-aligned navigation in RTL mode)

#### **6.3.2 Hero Section Requirements \[CURRENT – PHASE 0\]**

* Value proposition headline: "استثمر في العقارات السعودية من 100 ريال فقط" (Invest in Saudi Real Estate from 100 Riyals Only)  
* Sub-headline describing key benefits (monthly income, REGA supervised, Sharia compliant)  
* Primary call-to-action button: "الآن ابدأ الاستثمار" (Start Investing Now)  
* Secondary call-to-action button: "اكتشف طريقة العمل" (Learn How It Works)  
* Trust indicators: REGA sandbox status badge, investor count  
* Responsive design for all screen sizes  
* Performance-optimized image loading (no hero images on initial load)

#### **6.3.3 Trust Bar/Stats Section Requirements \[CURRENT – PHASE 0\]**

* Four key metrics displayed in equal columns:  
  1. Minimum investment amount (100 ﷼)  
  2. Expected annual yield (8-12%)  
  3. REGA regulation status  
  4. Sharia compliance status  
* Responsive grid layout  
* Green accent color for key figures  
* Mobile-optimized column stacking on small screens

#### **6.3.4 How It Works Section Requirements \[CURRENT – PHASE 0\]**

* Three-step process displayed in cards:  
  1. Sign Up & Capture Lead Details (with basic information collection) \[CURRENT – PHASE 0\]  
  2. Choose Property (from our first featured asset) \[CURRENT – PHASE 0\]  
  3. Invest & Earn (monthly income) \[ROADMAP – PHASE 2\]  
* Numbered circle indicators (custom SVG)  
* Centered layout with call-to-action button  
* RTL optimized layout  
* Mobile-responsive card stacking

#### **6.3.5 Why CapNest Section Requirements \[CURRENT – PHASE 0\]**

* Six benefit cards highlighting key differentiators:  
  1. Low Entry Barrier  
  2. Monthly Passive Income  
  3. Full Regulatory Protection  
  4. Early Exit Option  
  5. Diversification  
  6. Transparent Blockchain Registry \[ROADMAP – PHASE 2\]  
* Responsive grid layout (2 columns on mobile, 3 on desktop)  
* Hover effects on desktop (none on mobile for performance)  
* Accessible focus states

#### **6.3.6 Properties/Featured Section Requirements \[CURRENT – PHASE 0\]**

* Grid layout of featured properties (3 on desktop, 1 on mobile)  
* Property cards with:  
  * Placeholder image container  
  * Property name and location  
  * Expected yield percentage  
  * Minimum investment amount  
  * "View Details" button  
* "Browse All Properties" link at bottom  
* Lazy loading of images  
* Performance-optimized asset loading  
* First Asset Display: First asset created using Digishares platform must be prominently displayed here

#### **6.3.7 Testimonials Section Requirements \[CURRENT – PHASE 0\]**

* Single testimonial card with quote styling  
* Investor name and details (location, time as investor)  
* Minimal design focusing on content  
* RTL typography support  
* Mobile-optimized padding and spacing

#### **6.3.8 Final CTA/App Promo Section Requirements \[CURRENT – PHASE 0\]**

* Contrasting background color (green \#006C35)  
* Headline: "هل أنت مستعد لبدء رحلتك الاستثمارية؟" (Ready to Start Your Investment Journey?)  
* Sub-headline: "يمنحك الاستثمار العقاري مع CapNest دخلاً شهرياً مع حماية تنظيمية كاملة." (CapNest's real estate investment provides you with monthly income with complete regulatory protection.)  
* Primary CTA button: "أنشئ حسابك المجاني الآن" (Create Your Free Account Now)  
* Compliance footer text: "الاستثمار ينطوي على مخاطر. هذه المنصة خاضعة للرقابة التنظيمية الكاملة."

#### **6.3.9 Footer Requirements \[CURRENT – PHASE 0\]**

* Four-column layout on desktop, stacked on mobile  
* Column 1: Brand information \+ regulatory badges  
* Column 2: Platform navigation links  
* Column 3: Legal documentation links  
* Column 4: Contact information  
* Copyright and regulatory disclaimer in bottom bar  
* Links to Privacy Policy and Terms of Service  
* REGA license number display

#### **6.3.10 Signup Form Requirements \[CURRENT – PHASE 0\]**

* Form fields: Full name, National ID, Email, Mobile number, IBAN details, Investment amount selection  
* Required field validation with Arabic error messages  
* Terms of service checkbox with links to legal documents  
* Submit button with loading state  
* Success message with confirmation details  
* Error handling with clear recovery instructions  
* Data privacy notice with consent checkbox  
* Server-side validation with API error handling  
* IBAN format validation (basic pattern check only for Phase 0\)

### **6.4 Contextual Considerations (Non-Functional / Regulatory / Strategic) \[CURRENT – PHASE 0\]**

The landing page represents the only customer-facing component in Phase 0 and must therefore carefully balance marketing appeal with regulatory compliance. All trust indicators must be precisely calibrated to reflect actual Phase 0 capabilities without overpromising on future functionality.

SGDS compliance is non-negotiable even at Phase 0 due to Saudi government requirements for all digital services. Legal review of all marketing claims is required before launch to prevent regulatory misalignment.

Analytics implementation must comply with Saudi data laws regarding visitor tracking and consent management, even in this preliminary phase.

## **7\. User Flow: The 120-Second Journey (MVP) \[ROADMAP – PHASE 2\]**

### **7.1 Optimized User Journey \[ROADMAP – PHASE 2\]**

Entry: User lands on CapNest landing page (3 seconds)

| Step 1 (15s): User enters mobile number → receives SMS OTP → verifies | Step 2 (30s): User completes Yakeen authentication via Yakeen (National ID \+ DOB) | Step 3 (25s): User answers minimal KYC questions (employment sector, PEP status) |
| ----- | ----- | ----- |
| Step 4 (22s): User views first asset details and selects investment amount (min SAR 190\) | Step 5 (15s): User completes payment via integrated gateway (IBAN verification \+ STC Pay/MADA) | Step 6 (10s): System confirms registration and sends welcome email with invoice |

Exit: Total Time: 115 seconds

### **7.2 Technical Implementation Requirements \[ROADMAP – PHASE 2\]**

Frontend Optimization:

* Single-page application architecture with progressive loading  
* Pre-cached authentication flows for Yakeen integration  
* Mobile-optimized forms with auto-complete and smart defaults  
* Pre-filled form fields where Yakeen API permits data sharing  
* Minimal form validation with inline error correction

Backend Optimization:

* Parallel API calls for Yakeen verification and basic KYC collection  
* Asynchronous payment processing with immediate UI confirmation  
* Pre-generated invoice templates for instant delivery  
* Server-side rendering for landing page (LCP \< 1 second)  
* Edge caching for static assets (images, CSS, JS)

Infrastructure Requirements:

* Hosting in Google Cloud Platform Saudi region (Dammam)  
* Auto-scaling to handle 5,000 concurrent users  
* API response time \< 1 second for all critical paths  
* CDN for static assets with edge locations in major Saudi cities  
* 99.5% uptime SLA for MVP phase

## **8\. Technical Architecture (MVP Simplified) \[CURRENT – PHASE 0 \+ ROADMAP COMPONENTS\]**

### **8.1 System Overview \[CURRENT – PHASE 0 \+ ROADMAP COMPONENTS\]**

![][image1]  
graph TB

subgraph "Frontend"

    LANDING\[Landing Page\]

    FORM\[Signup Form with IBAN Collection\]

end

subgraph "Backend"

    CORE\[Core Application\]

    ZOHO\[Zoho CRM/Invoice\]

    IBAN\[IBAN Verification Service\]

    DIGI\[Digishares Integration\]

end

subgraph "Data"

    USERDB\[(User Database)\]

    LEADDB\[(Lead Database)\]

    ASSETDB\[(Asset Database)\]

end

subgraph "External Integrations"

    EXT1\[IBAN Verification API\]

    EXT2\[Zoho CRM\]

    EXT3\[Analytics Service\]

    EXT4\[Digishares API\]

end

LANDING \--\> CORE

FORM \--\> CORE

CORE \--\> ZOHO

CORE \--\> IBAN

CORE \--\> DIGI

CORE \--\> USERDB

CORE \--\> LEADDB

CORE \--\> ASSETDB

IBAN \--\> EXT1

ZOHO \--\> EXT2

CORE \--\> EXT3

DIGI \--\> EXT4

### **8.2 Integration Specifications \[CURRENT – PHASE 0 \+ ROADMAP COMPONENTS\]**

| Integration | Provider | Authentication | Data Flow | SLA | MVP Timeline |
| ----- | ----- | ----- | ----- | ----- | ----- |
| IBAN Verification | Saudi Banks API | API Key | Unidirectional (IBAN → Platform) | 99% uptime, \<2s response | Week 2-3 \[CURRENT – PHASE 0\] |
| CRM/Invoice | Zoho | OAuth 2.0 | Bidirectional (User data ↔ CRM) | 99% uptime | Week 3-4 \[CURRENT – PHASE 0\] |
| Analytics | Google Analytics | API Key | Unidirectional (Events → Analytics) | 99.9% uptime | Week 1-2 \[CURRENT – PHASE 0\] |
| Digishares Asset Creation | Digishares | JWT | Bidirectional (Asset creation ↔ Platform) | 98% uptime | Week 5-6 \[CURRENT – PHASE 0\] |
| Yakeen | ELM | OAuth 2.0 | Bidirectional (User data ↔ Platform) | 99% uptime, \<2s response | Week 3-4 \[ROADMAP – PHASE 1\] |
| Payment Gateway | Moyasar/Geidea | API Key | Unidirectional (Payment → Platform) | 99.5% uptime, \<3s response | Week 4-6 \[ROADMAP – PHASE 1\] |

### **8.3 Data Architecture (MVP) \[CURRENT – PHASE 0\]**

User Database Schema:

CREATE TABLE leads(

    id UUID PRIMARY KEY,

    full\_name\_ar VARCHAR(255) NOT NULL,

    full\_name\_en VARCHAR(255),

    mobile\_number VARCHAR(20) NOT NULL,

    email VARCHAR(255) NOT NULL,

    iban VARCHAR(34),

    investment\_amount DECIMAL(10,2),

    status VARCHAR(20) DEFAULT 'pending',

    created\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP,

    updated\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP

);

CREATE TABLE users(

    id UUID PRIMARY KEY,

    national\_id VARCHAR(20) NOT NULL UNIQUE,

    full\_name\_ar VARCHAR(255) NOT NULL,

    full\_name\_en VARCHAR(255),

    mobile\_number VARCHAR(20) NOT NULL,

    email VARCHAR(255) NOT NULL,

    yakeen\_verified BOOLEAN DEFAULT false,

    kyc\_status VARCHAR(20) DEFAULT 'pending',

    created\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP,

    updated\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP

);

CREATE TABLE assets(

    id UUID PRIMARY KEY,

    name VARCHAR(255) NOT NULL,

    location VARCHAR(255) NOT NULL,

    description TEXT,

    minimum\_investment DECIMAL(10,2) NOT NULL,

    expected\_yield DECIMAL(5,2),

    digishares\_token\_id VARCHAR(255),

    status VARCHAR(20) DEFAULT 'active',

    created\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP,

    updated\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP

);

CREATE TABLE payments(

    id UUID PRIMARY KEY,

    user\_id UUID REFERENCES users(id),

    amount DECIMAL(10,2) NOT NULL,

    currency VARCHAR(3) DEFAULT 'SAR',

    status VARCHAR(20) DEFAULT 'pending',

    payment\_method VARCHAR(50),

    transaction\_id VARCHAR(255),

    created\_at TIMESTAMP DEFAULT CURRENT\_TIMESTAMP

);

## **9\. Regulatory Compliance (Sandbox Level) \[CURRENT – PHASE 0\]**

### **9.1 Sandbox Compliance Requirements \[CURRENT – PHASE 0\]**

| Requirement | Implementation | Verification Method | MVP Timeline |
| ----- | ----- | ----- | ----- |
| Data Privacy | PDPL compliance for lead collection | Compliance officer review of data schema | Week 2 |
| Data Residency | All data stored in GCP Saudi region only | Architecture diagram with data flow | Week 2 |
| Marketing Claims | Review of all value propositions against actual capabilities | Legal review of marketing materials | Week 3 |
| IBAN Handling | Secure collection without verification | Security audit of data handling | Week 3 |
| Analytics Compliance | Saudi-compliant tracking implementation | Privacy impact assessment | Week 4 |
| First Asset Creation | Documentation of first asset creation process on Digishares | Asset creation verification report | Week 6 |

### **9.2 Risk Mitigation for MVP \[CURRENT – PHASE 0\]**

| Risk ID | Description | Mitigation Strategy | Owner | Timeline |
| ----- | ----- | ----- | ----- | ----- |
| RISK-MVP-001 | Overpromising on capabilities | Clear differentiation between Phase 0 and roadmap features | CMO | Ongoing |
| RISK-MVP-002 | IBAN data security | Encryption at rest and transit for all sensitive data | Tech Lead | Week 2 |
| RISK-MVP-003 | Regulatory sandbox rejection | Weekly compliance reviews; sandbox pre-approval consultation | CCO | Ongoing |
| RISK-MVP-004 | Data residency compliance | Architectural review by external consultant | Tech Lead | Week 2 |
| RISK-MVP-005 | Lead quality issues | Progressive qualification questions in signup flow | CBO | Week 3 |
| RISK-MVP-006 | First asset creation failure | Parallel manual asset documentation process | Tech Lead | Week 5 |

## **10\. Implementation Roadmap (3-Month MVP) \[CURRENT – PHASE 0\]**

### **10.1 Phased Delivery Plan (MVP Only) \[CURRENT – PHASE 0\]**

| Phase | Duration | Core Objectives | Key Deliverables | Go/No-Go Criteria |
| ----- | ----- | ----- | ----- | ----- |
| Week 1-2 | 2 weeks | Foundation setup and landing page | \- Landing page with interested investor capture \- Basic database schema \- Development environment | Landing page live with 100+ test signups |
| Week 3-4 | 2 weeks | IBAN collection and CRM integration | \- IBAN collection form \- Zoho CRM integration \- Lead management dashboard | 95% successful lead captures with valid IBAN formats |
| Week 5-6 | 2 weeks | First Asset Creation with Digishares | \- Digishares platform integration \- First asset creation workflow \- Asset display in UI | Successful creation and display of first asset |
| Week 7-8 | 2 weeks | Analytics and optimization | \- GA4 implementation with Saudi compliance \- Performance optimization \- A/B testing framework | Lighthouse score \>90 on mobile devices |
| Week 9-10 | 2 weeks | Compliance validation | \- Legal review completion \- Data privacy assessment \- REGA sandbox documentation | Full compliance sign-off from legal team |
| Week 11-12 | 2 weeks | Final validation and launch | \- User acceptance testing \- Performance stress testing \- Go/No-Go decision package | 500+ qualified leads captured with 15% conversion rate |

### **10.2 Critical Path Dependencies \[CURRENT – PHASE 0\]**

| Dependency | Impact | Mitigation Strategy | Owner |
| ----- | ----- | ----- | ----- |
| GCP Saudi region access | Blocks data residency compliance | Early account setup with priority support | CDO |
| Zoho CRM sandbox environment | Blocks lead management | Parallel development with mock APIs | CDO |
| Legal approval of marketing claims | Blocks landing page launch | Early legal review cycles | CCO |
| REGA sandbox pre-approval | Blocks regulatory positioning | Weekly regulator check-ins | CCO |
| Analytics compliance approval | Blocks visitor tracking | Implement privacy-first tracking from day one | CDO |
| Digishares sandbox access | Blocks first asset creation | Early sandbox environment setup | CTO |

## **11\. Product Roadmap (Phase-Based Scope Allocation) \[ROADMAP – PHASE 1+\]**

This section provides a consolidated view of feature allocation across implementation phases. It references existing specifications without duplicating them.

### **11.1 Phase 0 – Landing Page and Lead Capture \[CURRENT – PHASE 0\]**

Objective: Validate market demand and collect qualified leads with IBAN information for future verification, including the creation of the first asset.

Core Components:

* Marketing landing page with value proposition  
* Lead capture form with IBAN collection  
* Zoho CRM integration for lead management  
* *Basic analytics and conversion tracking*  
* Regulatory-compliant marketing materials  
* First Asset Creation: Creation of the first SPV asset using Digishares platform

Key Constraint: No financial transactions or regulatory submissions beyond basic data compliance. The first asset creation is the transition point to Phase 1\.

Success Metrics:

* 500+ qualified leads captured  
* 15% conversion rate from visitors to leads  
* 100% compliance with Saudi data protection laws  
* Successful creation of first asset on Digishares platform

### **11.2 Phase 1 – REG-A Onboarding \[ROADMAP – PHASE 1\]**

Objective: Establish compliant user onboarding framework with identity verification.

Core Components:

* Digishares Integration Specification (Section 13.1)  
* Yakeen authentication integration (Section 8.2, Section 13.3)  
* Basic KYC data collection (Section 4.1)  
* User profile management (Section 5.1 MVP-008)  
* OTP verification system (Section 7.1)  
* Regulatory sandbox submission package (Section 9.2)

Key Constraint: No financial functionality is enabled in this phase. This phase focuses exclusively on establishing a compliant user onboarding framework pending REGA sandbox approval.

Success Metrics:

* 98% Yakeen authentication success rate  
* 100% compliance with SAMA KYC requirements  
* Successful REGA sandbox approval

### **11.3 Phase 2 – Financial Enablement \[ROADMAP – PHASE 2\]**

Objective: Enable secure investment capabilities with payment processing and asset tokenization.

Core Components:

* IBAN verification and validation (Section 13.2)  
* Payment gateway integration (Section 8.2, Section 13.4)  
* Single SPV asset upload via Digishares (Section 5.1 MVP-008, Section 13.1)  
* 120-second journey optimization (Section 5.1 MVP-009, Section 7\)  
* Basic transaction processing capabilities  
* Automated invoicing and reporting

Key Constraint: Limited to single asset type and basic transaction capabilities within regulatory sandbox boundaries.

Success Metrics:

* 97% payment processing success rate  
* Journey completion time ≤120 seconds  
* 100% regulatory compliance for financial transactions

### **11.4 Phase 3 – Scale Platform \[ROADMAP – PHASE 3\]**

Objective: Expand platform capabilities for broader market reach and advanced features.

Core Components:

* Higher transaction limits (Section 5.2)  
* Expanded financial features (Section 5.2)  
* Advanced compliance frameworks (Section 5.2, Section 9\)  
* Platform partnerships integration (Section 3.3)  
* Native mobile applications (Section 5.2)  
* Operational automation systems (Section 10\)  
* Secondary market capabilities (Section 5.2)

Key Constraint: Full regulatory approval required before launching Phase 3 capabilities.

Success Metrics:

* 99.9% platform uptime  
* 25% month-over-month user growth  
* Full regulatory compliance across all features

## **12\. Success Metrics & KPIs (MVP Phase) \[CURRENT – PHASE 0\]**

### **12.1 Critical MVP Metrics \[CURRENT – PHASE 0\]**

| Metric | Target | Measurement Method | Frequency |
| ----- | ----- | ----- | ----- |
| Lead Capture Rate | ≥15% | Leads captured / landing page visitors | Daily |
| IBAN Collection Rate | ≥85% | Leads with valid IBAN / total leads | Daily |
| First Asset Creation Success | 100% | Successful asset creation on Digishares | One-time |
| Lead Quality Score | ≥70% | Sales team qualification assessment | Weekly |
| Regulatory Compliance Score | 100% | Compliance checklist completion | Weekly |
| Page Load Performance | \<2s | Lighthouse performance testing | Daily |
| Mobile Responsiveness | 100% | Cross-device compatibility testing | Weekly |

### **12.2 MVP Launch Criteria \[CURRENT – PHASE 0\]**

* Landing page fully compliant with Saudi Government Design Standards  
* Lead capture form with IBAN collection functional across all devices  
* 100% compliance with Saudi data protection requirements  
* Zoho CRM integration fully operational with lead management dashboard  
* Analytics implementation compliant with Saudi regulations  
* Legal approval of all marketing materials and claims  
* Performance metrics meeting targets (Lighthouse score \>90, load time \<2s)  
* Minimum 100 test leads captured with valid IBAN information  
* Successful creation of first asset on Digishares platform  
* No critical security vulnerabilities (CVSS score \> 7.0)

## **13\. Appendix: MVP Technical Specifications \[CURRENT – PHASE 0 \+ ROADMAP COMPONENTS\]**

### **13.1 Digishares Integration Specification \[CURRENT – PHASE 0\]**

MVP Asset Creation Requirements:

* Single asset type (SPV) supported  
* Basic metadata only (property name, location, description, minimum investment)  
* No fractional ownership calculations in MVP  
* Asset represented as single token on Digishares blockchain

API Endpoints:

* POST /assets/create \- Create first asset metadata on Digishares  
* GET /assets/status \- Check asset creation status  
* GET /assets/list \- List available assets (must include first created asset)

Authentication:

* JWT token-based authentication  
* API key rotation every 30 days  
* IP whitelisting for sandbox environment

### **13.2 IBAN Integration Specification \[CURRENT – PHASE 0\]**

API Endpoints:

* POST /leads/iban/validate \- Basic IBAN format validation  
* GET /leads/iban/status \- Check IBAN verification status \[ROADMAP – PHASE 2\]

Required Parameters:

{

  "iban": "SA0380000000608010167519",

  "name": "Full name as registered with bank",

  "lead\_id": "UUID reference to lead record"

}

Security Requirements:

* All API calls must use TLS 1.3  
* IBAN data encrypted at rest with AES-256  
* No persistent storage of full IBAN details in logs  
* Daily automated data purging of temporary IBAN records

### **13.3 Yakeen Integration Specification \[ROADMAP – PHASE 1\]**

API Endpoints:

* POST /auth/yakeen/initialize \- Initialize Yakeen authentication flow  
* POST /auth/yakeen/verify \- Verify Yakeen authentication result  
* GET /auth/yakeen/status \- Check authentication status

Required Parameters:

{

  "national\_id": "10-digit Saudi national ID",

  "date\_of\_birth": "YYYY-MM-DD format",

  "callback\_url": "https://capnest.com/auth/yakeen/callback"

}

Security Requirements:

* All API calls must use TLS 1.3  
* OAuth 2.0 PKCE flow for authorization  
* Short-lived tokens (max 5 minutes)  
* All PII data encrypted at rest with AES-256

### **13.4 Payment Gateway Integration Specification \[ROADMAP – PHASE 1\]**

MVP Payment Requirements:

* Single payment amount option (SAR 190-380 deposit)  
* IBAN verification before payment processing \[ROADMAP – PHASE 2\]  
* Receipt generation via Zoho integration  
* 48-hour cooling-off period with automated refunds

API Endpoints:

* POST /payments/initiate \- Initiate payment transaction  
* GET /payments/status \- Check payment status  
* POST /payments/refund \- Process refunds during cooling period

Security Requirements:

* PCI-DSS Level 1 compliance  
* No storage of full credit card numbers  
* End-to-end encryption for payment data  
* Regular security audits

## **14\. Next Steps & Accountability \[CURRENT – PHASE 0\]**

### **14.1 Immediate Actions (Next 48 Hours) \[CURRENT – PHASE 0\]**

| Action | Owner | Deadline | Success Criteria |
| ----- | ----- | ----- | ----- |
| Finalize GCP Saudi region project setup | DevOps Lead | 2026-01-19 | Infrastructure project created |
| Set up Zoho CRM sandbox environment | Product Lead | 2026-01-19 | CRM environment ready for integration |
| Obtain legal approval for landing page copy | CCO | 2026-01-19 | Approved marketing materials received |
| Schedule first regulatory sandbox consultation | CCO | 2026-01-20 | Meeting confirmed with regulator |
| Begin landing page development | Frontend Lead | 2026-01-20 | Wireframes approved |
| Secure Digishares sandbox access | Tech Lead | 2026-01-20 | Digishares sandbox credentials received |

### **14.2 Accountability Matrix \[CURRENT – PHASE 0\]**

| Function | Responsible | Accountable | Decision Authority | Escalation Path |
| ----- | ----- | ----- | ----- | ----- |
| Product Delivery | Product Lead | Tech Lead | Technical implementation decisions | → CBO |
| Regulatory Compliance | Compliance Officer | CCO | Compliance approval | → CBO, Legal |
| IBAN Integration | Backend Lead | Tech Lead | IBAN verification decisions | → CDO |
| CRM Integration | Integration Lead | CBO | CRM workflow decisions | → CBO |
| First Asset Creation | Asset Manager | CBO | Asset creation decisions | → CBO |
| Timeline Management | Project Manager | CBO | Timeline approval | → CEO |

### **14.3 Decision Ownership Matrix \[CURRENT – PHASE 0\]**

| Area | Owner | Why |
| ----- | ----- | ----- |
| Phase 0 Validation | CBO (Azzam) | Demand & GTM |
| Onboarding Framework | Legal / Compliance | Regulatory |
| Payments Infrastructure | Legal \+ Tech | Risk |
| Platform Scaling | Product / Tech | Execution |
| Regulatory Submissions | Chief Compliance Officer | Authority |
| Timeline Adjustments | Project Sponsor | Governance |
| First Asset Creation Approval | CBO \+ CCO | Business & Compliance |

This matrix defines who has decision authority at each phase gate. All decisions require documented approval before proceeding to implementation. Disputes are resolved through the escalation path defined in Section 14.2.

## **15\. Appendices \[CURRENT – PHASE 0\]**

### **15.1 References & Sources \[CURRENT – PHASE 0\]**

Regulatory Framework

1. [Real Estate General Authority | Real Estate Registry (RER) | Property ownership Transfer](https://rega.gov.sa/en/rega-services/eservices/property-ownership-transfer/)  
2. [Saudi Personal Data Protection Law (PDPL)](https://laws.boe.gov.sa/BoeLaws/Laws/LawDetails/300)  
3. [SAMA Electronic Payments Framework](https://www.sama.gov.sa/en-US/LawsAndRegulations)  
4. [RAQABA Collective Investment Regulations](https://cma.org.sa/en/regulations)  
5. [FATF Recommendations](https://www.fatf-gafi.org/publications)

Technical Documentation

1. [IBAN Verification API Documentation](https://developer.saudi.bank/iban-api)  
2. [Zoho CRM API Documentation](https://www.zoho.com/crm/developer/docs/api/v6/)  
3. [Google Cloud Platform Saudi Region Documentation](https://cloud.google.com/solutions/saudi-arabia)  
4. [Digishares API Documentation](https://developers.digishares.com/)

Design Standards

1. [Saudi Government Design System (SGDS)](https://saudigov-design-system.sa/)  
2. [WCAG 2.1 AA Guidelines](https://www.w3.org/TR/WCAG21/)

Industry Research

1. [Saudi General Authority for Statistics (GASTAT)](https://www.stats.gov.sa/en/43)  
2. [Ministry of Justice Statistical Yearbook 2025](https://www.moj.gov.sa/en/RealEstateInvestment2025.pdf)

### **15.2 Glossary \[CURRENT – PHASE 0\]**

| Term | Definition |
| ----- | ----- |
| AML | Anti-Money Laundering procedures to detect and prevent illicit financial activity |
| CMA | Saudi Capital Market Authority, securities regulator |
| Dhamen | Saudi Arabia's electronic escrow service for secure payment holding |
| إثبات الدخل | Saudi government service providing employment and income verification |
| ELM | Saudi Electronic Authentication Service (Yakeen) |
| FR | Functional Requirement specifying system behavior |
| IBAN | International Bank Account Number, used in Saudi Arabia for bank transfers |
| KYC | Know Your Customer \- identity verification process |
| NFR | Non-Functional Requirement specifying system quality attributes |
| PEP | Politically Exposed Person requiring enhanced due diligence |
| RER | Real Estate Registry, Saudi national property tokenization infrastructure |
| RTL | Right-to-Left text direction used in Arabic language interfaces |
| SAMA | Saudi Arabian Monetary Authority, central bank and primary financial regulator |

Document Certification

I hereby certify that this MVP-focused PRD:

1. Contains only features required for the 3-month regulatory sandbox launch  
2. Implements the 120-second journey from app download to first investment \[ROADMAP – PHASE 2\]  
3. Maintains 100% SAMA/CMA compliance at sandbox level  
4. Excludes all post-RER approval features to future roadmap  
5. Includes the complete SAMA/CMA compliant User Input & KYC Data Schema \[ROADMAP – PHASE 1\]  
6. Contains executable specifications for all MVP deliverables  
7. Adheres to Saudi Government Design System principles for landing page  
8. Clearly distinguishes between Phase 0 execution-ready features and roadmap items  
9. Establishes first asset creation as the critical transition point between Phase 0 and Phase 1

**Signatures:**

* Azzam (CBO) \- *2026-01-18*  
  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  
* Hany Abd El-Wahab (CDO) \- *2026-01-18*  
  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  
* Walli (CFO) \- *2026-01-18*  
  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**END OF PRD**

**Document Reference: CAPNEST-PRD-MVP-2026-001**

**Classification: INTERNAL- EXECUTION READY**

**Distribution: CapNest Project Team Only**

**Copyright © 2026 CapNest. All Rights Reserved.**

# Business Requirements Specification (BRS)

# Business Requirements Specification (BRS) for CapNest

## **1\. Executive Summary**

**Purpose**: Define requirements for CapNest, a Saudi real estate investment platform enabling mid-income professionals to invest in fractional property ownership with minimal capital requirements while maintaining 100% regulatory compliance.

**Scope Overview**: Phase 0 includes a marketing landing page with lead capture functionality, IBAN collection for future verification, CRM and invoicing integration with Zoho, analytics implementation compliant with Saudi data laws, and creation of the first asset using Digishares platform.

**Key Objectives:**

* Validate market demand for fractional real estate investment in Saudi Arabia  
* Collect 500+ qualified leads with IBAN information  
* Achieve 100% compliance with Saudi data protection regulations  
* Successfully create first asset on Digishares platform as transition point to Phase 1

**Intended Audience**: Project stakeholders, development team, compliance officers, regulatory authorities, and executive sponsors.

## **2\. Document Control**

**Project Name**: CapNest Sandbox MVP  
**Document Version**: 1.0  
**Date**: January 18, 2026  
**Author**: Ahmed Zayed (Product Lead)  
**Reviewers**: Azzam (CBO), Hany Abd El-Wahab (CDO), Walli (CFO)  
**Approval Status**: Draft 

Change History:

| Version | Date | Author | Changes |
| ----- | ----- | ----- | ----- |
| 1.0 | 2026-01-18 | Ahmed Zayed | Initial version based on PRD V1.1 |

## **3\. Project Overview**

**Objective**: Deliver a regulatory-compliant real estate investment platform for the Saudi market that validates demand through lead generation while preparing for full sandbox compliance approval.

**Target Market/Region**: Saudi Arabia, focusing on mid-income professionals seeking accessible real estate investment opportunities.

**Platform Architecture**: Cloud-based, multi-layer architecture hosted in Google Cloud Platform Saudi region with frontend (React), backend services, and external integrations (Zoho CRM, IBAN verification, Digishares).

**Key Features**:

* Saudi Government Design Standards-compliant landing page  
* Lead capture with IBAN collection  
* Zoho CRM and invoicing integration  
* GA4 analytics with Saudi data compliance  
* First asset creation via Digishares integration

**Success Metrics**:

* 500+ qualified leads captured with valid IBAN information  
* 15% conversion rate from landing page visitors to leads  
* 100% compliance with Saudi data protection requirements  
* 90+ Lighthouse performance score on mobile devices  
* Successful creation and display of first asset on Digishares platform

## **4\. Business Objectives**

**Strategic Objectives**:

* Establish market presence in Saudi fractional real estate investment sector  
* Build regulatory trust with Saudi authorities (REGA, SAMA, MoJ)  
* Validate product-market fit before full regulatory submission

**Target Outcomes**:

* Market validation through 500+ qualified leads  
* Establishment of compliant data handling processes  
* Preparation of infrastructure for subsequent regulatory phases  
* Demonstration of first asset creation capability as proof of concept

**Core Differentiators**:

* Low investment threshold (starting from 100 SAR)  
* Saudi regulatory compliance-first approach  
* Streamlined user experience aligned with Saudi Government Design Standards  
* IBAN-first payment infrastructure for Saudi market

Alignment with Corporate Strategy: Supports CapNest's entry strategy into the Saudi real estate investment market with a phased, regulatory-approved approach that mitigates risk while validating demand.

## **5\. Background and Current State**

**Problem Description**: Saudi mid-income professionals lack accessible, regulatory-compliant real estate investment opportunities that don't require significant capital outlays or complex processes. Traditional real estate investment in Saudi Arabia requires substantial capital and faces regulatory complexities.

**Current System Limitations**: Existing real estate investment platforms in Saudi Arabia either:

* Require large minimum investments (exceeding average professional's capacity)  
* Lack regulatory compliance frameworks for fractional ownership  
* Have complex user journeys that deter new investors  
* Don't integrate with Saudi payment infrastructure (IBAN)

**Business Risks if Unsolved**:

* Loss of first-mover advantage in Saudi's growing fractional real estate market  
* Regulatory rejection due to non-compliance with Saudi data and financial regulations  
* Market validation failure due to poor user experience or trust barriers  
* Competitive disadvantage against established players entering the fractional ownership space

## **6\. Scope**

**In-Scope Functional Areas**:

* Marketing landing page with Saudi Government Design Standards compliance  
* Lead capture form with IBAN collection  
* Zoho CRM integration for lead management and invoicing  
* Analytics implementation compliant with Saudi data laws  
* First asset creation using Digishares platform  
* Admin dashboard for lead visibility  
* Basic reporting and conversion tracking

**Out-of-Scope Deliverables**:

| Category | Excluded Deliverable | Reason |
| ----- | ----- | ----- |
| Authentication | User registration and login flows | Phase 1 feature pending regulatory approval |
| Payments | Payment gateway integration and processing | Phase 1 feature pending regulatory approval |
| KYC | Identity verification and Yakeen integration | Phase 1 feature pending regulatory approval |
| User Accounts | Full user profiles and dashboards | Phase 1 feature pending regulatory approval |
| Transactions | Investment processing capabilities | Phase 2 feature pending regulatory approval |
| Mobile Apps | iOS and Android applications | Phase 2 feature pending regulatory approval |

**Constraints**:

* 3-month timeline with no extensions (launch target: April 17, 2026\)  
* SAR 1.2M budget for MVP phase  
* 100% Saudi data residency requirement (GCP Saudi region only)  
* Saudi Government Design Standards compliance for all customer-facing elements  
* Maximum 9 FTEs for development team

## **7\. Stakeholders**

| Stakeholder Name | Role | Business Interest | Influence | Communication Frequency | Objective |
| ----- | ----- | ----- | ----- | ----- | ----- |
| Azzam | CBO | Business development strategy | High | Weekly | Validate market demand and GTM strategy |
| Walli | CFO | Financial oversight | High | Weekly | Ensure budget adherence and financial compliance |
| Hany | CDO | Digital transformation | High | Weekly | Deliver compliant digital experience |
| Ahmed Zayed | Product Lead | Product management and compliance | High | Daily | Execute MVP scope with regulatory alignment |
| Compliance Officer | CCO | Regulatory compliance | High | Daily | Ensure 100% compliance with Saudi regulations |
| REGA Representative | Regulatory Authority | Sandbox approval | High | Monthly | Verify regulatory compliance and sandbox readiness |
| Zoho Representative | CRM Partner | CRM integration success | Medium | Bi-weekly | Successful technical integration |
| Digishares Representative | Technology Partner | Platform integration | Medium | Weekly | Successful first asset creation |
| Marketing Team | Internal | Lead generation | Medium | Weekly | Drive traffic and conversion to leads |
| Development Team | Internal | Technical delivery | Medium | Daily | Deliver on-time, high-quality technical implementation |

## **8\. Actors and Users**

| Actor Name | Description | Key Responsibilities | System Modules Accessed |
| ----- | ----- | ----- | ----- |
| Interested Investor | Saudi professional exploring investment opportunities | Provide contact information and IBAN details | Landing page, lead capture form, asset display |
| Marketing Administrator | Internal team member managing campaigns | View lead analytics, export lead data | Admin dashboard, analytics module, CRM integration |
| Compliance Officer | Internal team member ensuring regulatory adherence | Review data handling processes, approve marketing content | Admin dashboard, compliance reporting |
| System Administrator | Internal technical team member | Configure system settings, monitor performance | Admin panel, system configuration, monitoring tools |
| Digishares Platform | Asset tokenization partner system | Create and manage first asset on blockchain | Digishares API integration |
| Zoho CRM | Customer relationship management system | Store and manage leads with IBAN details | Zoho CRM API integration |
| IBAN Verification Service | External banking validation service | Validate IBAN format and details | IBAN verification API |

## **9\. Business Requirements**

### **9.1 Functional Requirements (FRs)**

| ID | Requirement Description | Priority | Acceptance Criteria | Linked User Story | Linked User Flow |
| ----- | ----- | ----- | ----- | ----- | ----- |
| FR-001 | Landing page shall display Saudi Government Design Standards-compliant landing page | High | Page passes Saudi design compliance checklist with zero critical issues | US-001 | UF-001 |
| FR-002 | System shall capture lead information including full name, contact details, and IBAN | High | Form submissions with valid IBAN format save successfully to database with 95% success rate | US-002 | UF-001 |
| FR-003 | System shall integrate with Zoho CRM for automatic lead synchronization | High | Leads appear in Zoho CRM within 5 minutes of submission with complete data | US-003 | UF-002 |
| FR-004 | System shall generate professional invoices for leads with IBAN details | High | Invoices contain all required Saudi legal elements and IBAN information | US-004 | UF-002 |
| FR-005 | System shall create first asset on Digishares platform | High | First asset successfully created and displayed in UI with proper metadata | US-005 | UF-003 |
| FR-006 | System shall implement GA4 analytics compliant with Saudi data laws | High | Analytics dashboard shows lead conversion funnel with 100% data residency compliance | US-006 | N/A |
| FR-007 | System shall provide admin dashboard for lead management | Medium | Admin users can view, filter, and export leads with IBAN details | US-007 | UF-004 |

### **9.2 Non-Functional Requirements (NFRs)**

| ID | Requirement Description | Priority | Acceptance Criteria | Linked User Story | Linked User Flow |
| ----- | ----- | ----- | ----- | ----- | ----- |
| NFR-001 | System shall maintain 99.9% uptime during business hours (8am-10pm AST) | High | Maximum 8.76 minutes of downtime per month during business hours | N/A | N/A |
| NFR-002 | Landing page shall achieve Lighthouse performance score \>90 on mobile devices | High | Page loads in under 2 seconds on 4G connection with all critical elements visible | N/A | N/A |
| NFR-003 | All data shall be stored and processed exclusively within Saudi Arabia | Critical | Architecture diagram confirms 100% data residency in GCP Saudi region | N/A | N/A |
| NFR-004 | System shall comply with Saudi Personal Data Protection Law (PDPL) | Critical | Independent compliance audit certifies 100% PDPL compliance | N/A | N/A |
| NFR-005 | System shall be fully responsive across all device sizes | Medium | All UI elements function correctly on devices from 320px to 4K resolution | N/A | N/A |
| NFR-006 | System shall implement Arabic language as primary interface with RTL support | High | 100% of UI elements properly support RTL layout with accurate Arabic text | N/A | N/A |
| NFR-007 | System shall encrypt all sensitive data (IBAN) at rest using AES-256 | Critical | Security audit confirms all sensitive data encrypted with industry-standard algorithms | N/A | N/A |

## **10\. User Story Maps**

### **10.1 User-Centric Stories**

Title: Lead Capture with IBAN Collection  
Description: As an interested Saudi investor, I want to provide my contact details and IBAN information so that I can be notified when the platform launches and potentially verify my banking details for future investments.

**Clear Path**:  
**Primary Path**: 

1. User lands on landing page  
2. User scrolls to lead capture form  
3. User enters name, email, phone, and IBAN details  
4. User accepts terms and conditions  
5. User submits form  
6. System confirms submission and sends welcome email

**Alternative Path(s)**: 

* Form validation errors: System displays appropriate Arabic error messages  
* IBAN format errors: System provides specific guidance for Saudi IBAN format

**Functional Requirements**: FR-001, FR-002, FR-006

**Validation and Limitation**: 

* Required fields must be completed before submission  
* IBAN must follow Saudi format (SA \+ 22 digits)  
* Email must be valid format  
* Maximum 3 consecutive failed submissions before temporary lockout

**Data Types**: 

* full\_name\_ar: string (required)  
* email: string (required, validated format)  
* mobile\_number: string (required, Saudi format \+966)  
* iban: string (required, Saudi IBAN format)  
* submission\_timestamp: datetime

**Notification Messages**: 

| Trigger | Message Text |
| ----- | ----- |
| Successful submission | "شكرًا لتواصلك\! سيتم إعلامك عند إطلاق المنصة." |
| Invalid IBAN format | "يرجى إدخال رقم IBAN صالح. مثال: SA0380000000608010167519" |
| Required field missing | "هذا الحقل مطلوب" |

**Acceptance Criteria (Gherkin Format)**:  
Given I am on the CapNest landing page  
When I fill in my details including a valid Saudi IBAN  
And I accept the terms and conditions  
Then I should receive a confirmation message  
And my details should be stored securely in the system  
And my information should be synced to Zoho CRM within 5 minutes

**Reflections**: 

* Lead data enables marketing nurturing campaigns  
* IBAN collection establishes payment infrastructure readiness  
* Data compliance establishes regulatory trust foundation  
* Lead quality metrics inform conversion optimization

**Translation Table**: 

| Message | English | Arabic |
| ----- | ----- | ----- |
| welcome\_message | "Thank you for your interest\! You'll be notified when we launch." | "شكرًا لتواصلك\! سيتم إعلامك عند إطلاق المنصة." |
| iban\_placeholder | "Your IBAN (SA03…)" | "رقم حسابك المصرفي الدولي (IBAN)" |
| submit\_button | "Register Interest" | "تسجيل الاهتمام" |
| privacy\_notice | "We respect your privacy and comply with Saudi data protection laws." | "نحن نحترم خصوصيتك ونلتزم بقوانين حماية البيانات السعودية." |

**Linked FR/NFR**: FR-001, FR-002, NFR-003, NFR-004  
**Linked Flow**: UF-001

### **10.2 System-Centric Stories**

**User Story**: As a system, I want to securely collect, store, and process lead information including IBAN details so that the business can validate market interest while maintaining 100% compliance with Saudi data protection regulations.

**Context Diagram**:

\[External Systems\] → \[CapNest System\] → \[External Systems\]  
\[Zoho CRM\] ←→ \[Lead Management Module\] ←→ \[GA4 Analytics\]  
\[IBAN Verification Service\] ← \[Data Collection Module\]  
\[Admin Users\] → \[Admin Dashboard Module\]  
\[Digishares Platform\] ←→ \[Asset Management Module\]  
**Sequence Diagram**:

1. User → Frontend: Access landing page  
2. Frontend → Backend: Request page content  
3. Backend → Frontend: Return page content  
4. User → Frontend: Submit lead form with IBAN  
5. Frontend → Backend: Send encrypted lead data  
6. Backend → Database: Store lead with encrypted IBAN  
7. Backend → Zoho API: Sync lead data (excluding sensitive IBAN)  
8. Backend → Email Service: Send confirmation email  
9. Backend → Frontend: Return success status  
10. Frontend → User: Display confirmation message  
11. Scheduled Job → Digishares API: Create first asset (one-time)

**Basic Flows**:

1. **Lead Capture Flow**:  
   * User submits form → System validates inputs → System encrypts IBAN → System stores data → System syncs to CRM → System sends confirmation  
2. **First Asset Creation Flow**:  
   * Admin initiates asset creation → System connects to Digishares API → System submits asset metadata → System verifies creation status → System displays a listed (SPV) asset in UI

Exception Flows:  
	Trigger: Invalid IBAN format  
Steps:

1. System detects invalid IBAN pattern  
2. System rejects submission

System returns specific validation error

3. Outcome: User prompted to correct IBAN format

Trigger: Zoho CRM sync failure  
Steps:

1. System detects sync failure  
2. System logs error  
3. System queues for retry

System alerts admin after 3 failures

4. Outcome: Lead stored locally, sync attempted again after 15 minutes

Messages & Responses:Incoming Request: JSON payload with lead data including encrypted IBAN  
Outgoing Response: JSON confirmation with lead ID and status

**Technical Documentation**:Protocols: HTTPS/TLS 1.3, REST API  
Auth, Encryption, Throttling: JWT for admin access, AES-256 for data at rest, rate limiting at 100 requests/minute per IP  
Deployment: GCP Saudi region (Dammam), containerized architecture  
Monitoring/Alerting: Real-time error tracking, performance monitoring, compliance alerts

**Data Schemas**:  
Incoming:

{  
  "full\_name\_ar": "string",  
  "email": "string",  
  "mobile\_number": "string",  
  "iban": "string",  
  "consent\_privacy": "boolean",  
  "consent\_marketing": "boolean"  
}  
Outgoing:

{  
  "status": "success|failure",  
  "lead\_id": "uuid",  
  "message": "string",  
  "next\_steps": \["string"\]  
}  
Business Rules:

* IBAN must follow Saudi format (SA \+ 22 digits)  
* Email addresses must be verified before marketing communications  
* Data retention period: 7 years for compliance purposes  
* Lead data export requires admin approval and audit logging

**Retry Policy & Decoupling**:

* Max 3 synchronous retries for Zoho integration failures  
* After 3 failures: enqueue to "zoho-sync-retry" queue with exponential backoff  
* Critical compliance operations (data deletion requests) processed synchronously with confirmation

**Linked FR/NFR**: FR-002, FR-003, NFR-003, NFR-004, NFR-007  
**Linked Flow**: UF-002

## **11\. User Flows (IFTTT Format)**

### **11.1 User Flow Structure**

**Flow Title**: Lead Capture and IBAN Collection  
**Actor**: Interested Investor  
**Feature**: Lead Generation 

**IFTTT Logic**:  
Basic Structure: IF user submits lead form THEN store encrypted lead data AND sync to Zoho CRM AND send confirmation email AND track conversion event

**Branching**:

* ELSE IF form validation fails THEN display localized error messages AND highlight invalid fields  
* ELSE IF duplicate lead detected THEN update existing record AND send "thank you for your continued interest" message

**Feedback Loops**: LOOP while system services unavailable do queue operation; EXIT when all services restored or after 24 hours with admin notification

**Mathematical Logic:** Lead quality score \= (completeness \* 0.4) \+ (valid IBAN \* 0.4) \+ (engagement history \* 0.2)

**Programmable Logic**:

if (isValidSaudiIBAN(iban)) {  
  encryptAndStoreIBAN(leadId, iban);  
  syncToCRM(leadDataWithoutIBAN);  
  sendConfirmationEmail(email);  
  trackAnalyticsEvent('lead\_submitted', { quality\_score: calculateLeadQuality(lead) });  
}  
**References**:  
**Linked FR/NFR**: FR-002, NFR-004, NFR-007  
**Linked User Story:** US-002  
**Involved Modules**: Landing Page, Data Collection, CRM Integration, Analytics 

**Acceptance Criteria**:  
Given user is on landing page  
When user submits form with valid information including IBAN  
Then system should store data securely with encryption  
And sync non-sensitive data to Zoho CRM within 5 minutes  
And send confirmation email in Arabic  
And record conversion event in analytics system 

**Design Note**: This IFTTT flow handles straightforward lead capture automation. More complex flows involving regulatory compliance reviews will require BPMN modeling with decision gates and parallel approval paths.

## **12\. Assumptions**

**Assumptions**:

* Saudi regulators will approve the landing page and lead capture approach during sandbox phase  
* IBAN collection without verification will be considered acceptable for Phase 0  
* GCP Saudi region will provide sufficient performance and compliance for MVP needs  
* Zoho CRM and Digishares will provide stable sandbox environments for integration  
* First asset creation on Digishares platform will serve as sufficient proof of concept for Phase 0 completion  
* Marketing claims can be carefully calibrated to reflect Phase 0 capabilities without overpromising  
* Arabic language support will be sufficient with standard RTL frameworks  
* Analytics implementation can achieve Saudi compliance with proper configuration

## **13\. Constraints**

**Constraints**:

* Launch deadline of April 17, 2026 (exactly 3 months from PRD approval)  
* Budget cap of SAR 1.2M for entire MVP development  
* Maximum team size of 9 FTEs  
* 100% data residency requirement in Saudi Arabia  
* Saudi Government Design Standards compliance for all customer-facing elements  
* No financial transactions in Phase 0 (lead capture only)  
* Strict scope boundaries preventing feature creep into Phase 1 capabilities  
* All marketing claims must be legally reviewed before launch  
* Performance requirements (Lighthouse score \>90 on mobile devices)

## **14\. Dependencies**

**Internal Dependencies**:

* Completion of legal review for marketing materials and privacy policy  
* GCP Saudi region project setup and configuration  
* Zoho CRM sandbox environment configuration  
* Digishares sandbox API access credentials  
* Admin dashboard development for lead management  
* Compliance sign-off on data handling procedures

**External Dependencies**:

* REGA sandbox approval for landing page and lead capture approach  
* IBAN Verification API sandbox access and documentation  
* Zoho CRM API stability and sandbox environment availability  
* Digishares API stability and sandbox environment availability  
* Saudi Government Design System (SGDS) component library access  
* Third-party security audit for data handling processes  
* Google Analytics compliance configuration for Saudi data laws

## **15\. Risks**

| Risk ID | Description | Likelihood | Impact | Risk Owner | Mitigation Strategy | Notes |
| ----- | ----- | ----- | ----- | ----- | ----- | ----- |
| RISK-001 | Regulatory rejection of landing page/marketing claims | Medium | High | CCO | Early regulatory consultations; conservative marketing claims; legal pre-approval of all content | Most critical risk to timeline |
| RISK-002 | IBAN data security breach | Low | Critical | CTO | End-to-end encryption; security audit before launch; limited data retention | Requires specialized security expertise |
| RISK-003 | Digishares integration delays preventing first asset creation | Medium | High | Tech Lead | Parallel development tracks; manual asset representation fallback; early sandbox access | First asset creation is Phase 0 completion milestone |
| RISK-004 | Lead quality below targets (conversion \<15%) | High | Medium | CBO | A/B testing framework; progressive qualification questions; marketing campaign optimization | Business validation risk |
| RISK-005 | GCP Saudi region performance issues | Low | Medium | DevOps Lead | Performance testing early; CDN implementation; load testing before launch | Technical infrastructure risk |
| RISK-006 | Timeline slippage due to scope creep | High | High | Project Manager | Strict scope governance; phase-boundary enforcement; weekly scope validation meetings | Project management risk |
| RISK-007 | Data residency compliance failure | Low | Critical | CCO | Architectural review by external consultant; data flow mapping; compliance certification | Regulatory compliance risk |

## **16\. Timeline**

Milestone 1: Requirements approval and architecture sign-off by January 25, 2026  
Milestone 2: Landing page and lead capture form completion by February 8, 2026  
Milestone 3: Zoho CRM integration completion by February 22, 2026  
Milestone 4: First asset creation on Digishares by March 7, 2026  
Milestone 5: Compliance validation and security audit by March 28, 2026  
Milestone 6: User acceptance testing completion by April 10, 2026  
Launch Date: April 17, 2026 (exactly 3 months from PRD approval)

## **17\. Glossary**

**IFTTT**: If This Then That, a rule-based method for simple automation used to model user flows and system behaviors.

**BPMN**: Business Process Model and Notation, a standard for visualizing complex workflows with swimlanes and decision gates recommended for regulatory approval processes.

**Gherkin**: Syntax for testable acceptance criteria (Given/When/Then) used in behavior-driven development.

**SGDS**: Saudi Government Design System, official design standards and components for Saudi government and licensed digital services.

**PDPL**: Saudi Personal Data Protection Law, regulatory framework governing data privacy and protection in Saudi Arabia.

**REGA**: Real Estate General Authority, Saudi regulatory body overseeing real estate transactions and ownership.

**IBAN**: International Bank Account Number, standardized banking identifier used in Saudi Arabia for all bank transfers.

**SPV**: Special Purpose Vehicle, legal entity created to isolate financial risk, used for asset tokenization on Digishares platform.

**RTL**: Right-to-Left, text direction standard used for Arabic language interfaces requiring specialized UI implementation.

**RER**: Real Estate Registry, Saudi national property tokenization infrastructure managed by REGA.

**Digishares**: Technology partner providing blockchain-based asset tokenization platform for fractional ownership representation.

**MVP**: Minimum Viable Product, the smallest feature set needed to validate core business hypotheses and gather user feedback.

**Sandbox**: Regulatory testing environment allowing fintech products to operate with limited scope under regulatory supervision before full approval.

**Phase 0**: Current execution phase for CapNest focused on market validation and lead generation without financial transactions.

**Phase Gate**: Decision point between development phases requiring formal stakeholder approval before proceeding.

**END OF BRS**

**Document Reference: CAPNEST-BRS-MVP-2026-001**

**Classification: INTERNAL- EXECUTION READY**

**Distribution: CapNest Project Team Only**

**Copyright © 2026 CapNest. All Rights Reserved.**

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABJoAAAHfCAYAAAAYxLL+AABThUlEQVR4Xu3d+7MkV2Hg+fmfbuxErH/weJYdGMIrBzvIktV+xNryaHcjPKOdsba9MT3yCIy9xjAswoPl9mKE1DBgkMG2hBBYNhL0GgHCgEYW5qEWerR4yTzMQ4BscvtU1ak6eU5m3aq6WXkzKz/fiG9IXTerKqvyZN3Mb5+s/icVAAAAAAAA0AH/JL8BAAAAAAAA2AWhCQAAAAAAAJ0gNAEAAAAAAKAThCYAAAAAAAB0gtAEAAAAAACAThCaAAAAAAAA0AlCEwAAAAAAADpBaAIAAAAAAEAnCE0AAAAAAADoBKEJAAAAAAAAnSA0AQAAAAAAoBOEJgAAAAAAAHSC0AQAAAAAAIBOEJoAAAAAAADQCUITAAAAAAAAOkFoAgAAAAAAQCcITQAAAAAAAOgEoQkAAAAAAACdIDQBAAAAAACgE4QmAAAAAAAAdILQBAAAAAAAgE4QmgAAAAAAANAJQhMAAAAAAAA6QWgCAAAAAABAJwhNAAAAAAAA6AShCQAAAAAAAJ0gNAEAAAAAAKAThCYAAAAAAAB0gtAEAAAAAACAThCaAAAAAAAA0AlCEwAAAAAAADpBaAIAAAAAAEAnCE0AAAAAAADoBKEJAAAAAAAAnSA0AQAAAAAAoBOEJgAAAAAAAHSC0AQAAAAAAIBOEJoAAAAAAADQCUITAAAAAAAAOkFoAgAAAAAAQCcITQAAAAAAAOgEoQkAAAAAAACdIDQBAAAAAACgE4QmAAAAAAAAdILQBAAAAAAAgE4QmgAAAAAAANAJQhMAAAAAAAA6QWgCAAAAAABAJwhNAAAAAAAA6AShCQAAAAAAAJ0gNAEAAAAAAKAThCYAAAAAAAB0gtAEAAAAAACAThCaAAAAAAAA0AlCEwAAAAAAADpBaAIAAAAAAEAnCE0AAAAAAADoBKEJAAAAAAAAnSA0AQAAAAAAoBOEJgAAAAAAAHSC0AQAAAAAAIBOEJoAAAAAAADQCUITAAAAAAAAOkFoAgAAAAAAQCcITQAAAAAAAOgEoQkAAAAAAACdIDQBAAAAAACgE4QmAAAAAAAAdILQBABAxmc/+9bqAx+4liTJnXzssTflv1oAYDIITQAAZHzhC3dVTz55Z/X8858kSXIrn3nmj2a/RwBgqghNAABkhBOES5fC30ZfIklyK8PvD6EJwJQRmgAAyBCaSJK7KjQBmDpCEwAAGUITR+8zt1Vnjo6qo5pXVxeealh2UN5VnRvFepLtCk0Apo7QBABAhtDE0TsLTTdWF/PbO/TyHVdXRzeHk+nyZ7srNHH8Ck0Apo7QBABAhtDE0Ss0kaem0ARg6ghNAABkCE0cvWtC08Wbj6ozdzw0+2+8nG4WjZaX2K3uF5Y5d/ONq59dd2t1OfzsqVtrl+aFx5s9/oPJskkwan2cmSEuje0SP7JdoQnA1BGaAADIEJo4eo8JTelMpPzP84g0v2+MUvOfPVRduO6oOvfgfLl8RtM8XOXOo1Hr4yTPNf+ZGU0cv0ITgKkjNAEAkCE0cfQeE5pW0afj0NRyKV3r4whNPECFJgBTR2gCACBDaOLo3SI0zS93q18uFy9taw1E1SI0pZfAzR6nORK1P878srn4mEITD0GhCcDUEZoAAMgQmjh6twlN1frvaGoORMHku5VicKp9R9PqvmsfJ/u+p7ZYRY5FoQnA1BGaAADIEJpIkrsqNAGYOkITAAAZQhNJcleFJgBTR2gCACBDaCJJ7qrQBGDqCE0AAGQITTwUf/j98jaS+1VoAjB1hCYAADKEJh6KT3328eoPf/3x6i2/cYnkKx+vfvSjcj/pWqEJwNQRmgAAyBCaeCh+7ZnHq/e88enquecqcvLe+ZtPVEITAOwfoQkAgAyhiYei0ESuFJoAoB+EJgAAMoQmHopCE7lSaAKAfhCaAADIEJp4KApN5EqhCQD6QWgCACBDaOKhKDSRK4UmAOgHoQkAgAyhiYei0ESuFJoAoB+EJgAAMvoKTd/55qXqv776ieqtv3WJB+DbXl1u49NWaCJXCk0A0A9CEwAAGX2FpnDC867XP1V97StV9ZUv/Ygj9qtf+VF1xyvLbXzaCk3kSqEJAPpBaAIAIKPP0BROfPKTIY5ToYkctkITAPSD0AQAQIbQxF0UmshhKzQBQD8ITQAAZAhN3EWhiRy2QhMA9IPQBABAhtDEXRSayGErNAFAPwhNAABkCE3cRaFpQ+85Vx0dHS08U51/ZH77vWePqmtvu1wu34uXq/PXxHVaeXrr02B43665UD2a375w4/fvkQvVtcv3vXzdN91T3ufes6vtNDfc71x1b225i9VNyfYcokITAPSD0AQAQIbQxF0UmjZwFjnyQDEE58GlKbIM0zLqnCQ0rV53+biP3nZmEaHS7bYKVOvuOzSFJgDoB6EJAIAMoYm7KDRt4iJQZDNzQiSpzSCaxZB0ps08csTlZi4fIwSOPHgs/lybPRVsCyF5cEmdP14xyylGs7iuZy/Onu/a2y6uZgmFdUzWoSkEzUJOuO/yz+eSdVzEmzsXj7F4zbX3IXlvrj17bvW+JY9Zc11oKmZNhZ+HZfP3ON4vjUtCU1RoAjB1hCYAADKEJu6i0LSpyeVayxgyv20eYupRYxZiksAyXz5dJo8gWWhKwsl8dk7TjKq2S8jS9coeexFsrj2bhJlZVMouS4uvcfazpucOjxlvnz/+8vnCfRb3T9+Hpqgzi0+t8S2xITQtX3cep5L3rx7EkkC1XKZcp6EpNAFAPwhNAABkCE3cRaFpW9Oosm1oSmfi5FGlPTQ1BZry8RJrUWbu8hK1hp/lz1e7nK1p+WS5uL7zGVGrWUpN70PT66hfOtfyeor1aJjRlLyX5frHIFa/33y5C8U6DU2hCQD6QWgCACBDaOIuCk2beLk6v5wBlMal+syhNLCkNoembNbR4lK2ptBUjzXZejWGmTWP3fR9UzuGpmL2Uz6z6bl83fO41lFoSh6n6b1a3Vbeb/3rG4ZCEwD0g9AEAECG0MRdFJo2MH6fUXGpVhma0svY1s9oqurfxXTNmXpoSh8nD0NLG8LJ0nnUiY/RPMMnWY+dQlP+3UxNf66Hn9WXdM/X+yShqfYezbZJ2/3jTKrmn+frPDSFJgDoB6EJAICMgwhNj76zPAnuzPplO/UT3BOah4HG2SfDVGjqzsYvxN4lYBSXznHKCk0A0A9CEwAAGULTce45NOWzNkYSCoSm7kxn69RmEW2r0MREoQkA+kFoAgAgQ2g6zhPMMDnOPAw0XZ40UIUmctgKTQDQD0ITAAAZUwpNs+/CWXxPTvr/9S8bzr+PJQ1N6XfrNH1x8ny5477IeGnTjKb8n1xPv2Mm+96b1WvIY9h83W59sOE5O1JoIoet0AQA/SA0AQCQcfChqeULmVu/TLiYVbQ+NDUFqa1CU8t3NNW/IPqY0JQ/zsL/8K6vlc/ZkUITOWyFJgDoB6EJAICMww5N9ciTzhjaZ2gq/nWrfJZSNL90bmEZqlZxqf59Pov1nIWmpte/P4UmctgKTQDQD0ITAAAZBx2aatFoEX+Sfzq+MTQVM5DKgHRsaArP2xCQCltCU23dFrOVVpf1NX1f1Hydd/4S6R0UmshhKzQBQD8ITQAAZBxEaBqcF6ubkllMjd+9tKP3nk2CWjH7qj+FpnFauyRzkzFZi6F5XO3IluDKkyk0AUA/CE0AAGQITXvwkYvVTemlc53FoMvVvWfTS+f2cNK/oULT+JxFptqXz59rmB2X2XVoaopKTbfxxApNANAPQhMAABlCE3dRaBqZ2RfJb2wfoYl7UWgCgH4QmgAAyBCauItC07isf8F8g9m/zriMSceEpsYvp0+WjT+bf3/Y/LvEapfuxX8xse1fXKw995nqpnRG3yaX/k1YoQkA+kFoAgAgQ2jiLgpN43JtaCr+1cIkKLWGpuxfVkxj07rZUw0zmlbrln7Zfr58Hrnq/xojS4UmAOgHoQkAgAyhibsoNI3MdV8cf4LQ1PgvHQpNg1BoAoB+EJoAAMgQmriLQtP4zL8MPEScebiZX9JWu1wuRpxahKqHoPllc03xKo9CV577tsXzFlGrPtuqPvNqMWtqdolc/phC03EKTQDQD0ITAAAZQhN3UWgap7XvPzoK/+rcYvZQ23c0LS+RW8ShxXcq1WNT0/3q38e0mqWUXnI3f8z8sr7272jKH19oWqfQBAD9IDQBAJAhNHEXhSZy2ApNANAPQhMAABlCE3dRaCKHrdAEAP0gNAEAkCE0cReFJnLYCk0A0A9CEwAAGUITd1FoIoet0AQA/SA0AQCQITRxF4UmctgKTQDQD0ITAAAZvYamV12qLvzWYftffu3TxW2H6NtfU27j01ZoIlcKTQDQD0ITAAAZfYWmqXjDDb9Q3MZ+FJrIlUITAPSD0AQAQIbQ1K1C0+kpNJErhSYA6AehCQCADKGpW4Wm01NoIlcKTQDQD0ITAAAZQlO3Ck2np9BErhSaAKAfhCYAADKEpm4Vmk5PoYlcKTQBQD8ITQAAZAhN3So0nZ5CE7lSaAKAfhCaAADIEJq6VWg6PYUmcqXQBAD9IDQBAJAhNHWr0HR6htB04bcuVXf8Bk/T8+c+U9zG/n3LKy9VQhMA7B+hCQCADKGpW4UmTl37wLQUmgBMHaEJAIAMoalbnWRz6toHpqXQBGDqCE0AAGQITd3qJJtT1z4wLYUmAFNHaAIAIENo6lYn2Zy69oFpKTQBmDpCEwAAGUJTtzrJ5tS1D0xLoQnA1BGaAADIEJq61Uk2p659YFoKTQCmjtAEAECG0NStTrI5de0D01JoAjB1hCYAADKEpm51ks2pax+YlkITgKkjNAEAkCE0dauTbE5d+8C0FJoATB2hCQCADKGpW51kc+raB6al0ARg6ghNAABkCE3d6iSbU9c+MC2FJgBTR2gCACBDaOpWJ9mcuvaBaSk0AZg6QhMAABlCU7c6yebUtQ9MS6EJwNQRmgAAyAgnCJcv/1H1/e9/kh34y798priNnJL2gen4gx98evb7Q2gCMGWEJgAAMh577E3VBz5wDTvy6qt/rLiNnJL2gWn5wAPXz36PAMBUEZoAAMBeueGGG/KbgElhH5geL7zw3fwmAJgMQhMAANgrTrIxdewDAIApITQBAIC94iQbU8c+AACYEkITAADYK06yMXXsAwCAKSE0AQCAveIkG1PHPgAAmBJCEwAA2CtOsjF17AMAgCkhNAEAgL3iJBtTxz4AAJgSQhMAANgrTrIxdewDAIApITQBAIC94iQbU8c+AACYEkITAADYK06yMXXsAwCAKSE0AQCAveIkG1PHPgAAmBJCEwAA2CtOsjF17AMAgCkhNAEAgL3iJBtTxz4AAJgSQhMAANgrTrIxdewDAIApITQBAIC94iQbU8c+AACYEkITAADYK06yMXXsAwCAKSE0AQCAveIkG1PHPgAAmBJCEwAA2CtOsjFlnn322eqWW27JbwYA4GARmgAAwF4RmjBlHn744er8+fP5zQAAHCxCEwAA2CtCE6bM3XffPRMAgKkgNAEAgL0iNGGquGwOADBFhCYAALBXhCZMlTD2w6VzAABMCaEJAADsFaEJUyQEJrOZAABTRGgCAAB7RWjC1AiXzF111VX5zQAATAKhCQAA7BWhCVNCZAIATB2hCQAA7JXwT7v7nhocOmGci6oAAAhNAABgzwhNOGTCDKYQmMI4BwAAQhMAANgzd99990zgkAiBKc5iCv8PAADmCE0AAGCvhNlMZnvgkAjjOXwPk5l6AACUCE0AgEHz3HOPVJcvP8AR+8lPvrt67Wv/Q3E7OQbj+H3pS/9Fdeedryl+TpIk537/+9+YHb8LTQCAQfOtbz1ePfjg9dWnPvVKjtQPfeiV1TXX/HhxOzlU77//16r/9J9+unrJS368etWr/pfZn/NlSJLkyr/8y59fHr8LTQCAQRNC04c+9K+v/N8ljthbbvnV4jZyaD788N2zsXrVVf+yOn/+1cXPSZJks/fd97IqIjQBAAaN0HQY3nDDL1TPPvvR4nbytA3jMkSlGJeMU5Ikt1doAgCMBqHpMAwzRcwQ4WkZY1IInoLSlj54Y3V0dLTyulury/kym/rUrdWZoxuri/ntnXhXde7o6urCU/ntJMk+FJoAAKNBaDoMw0l9OMnPbyf3ZYxL4VK4MPaEzh0NoWkZlx6qLlx3VJ2546FyuU0UmkjyYBWaAACjQWg6HIUm7tMYltLL4MJMunw5bmktNF2qLt9xdXV0813lcpsoNJHkwSo0AQBGg9B0OPqeJnZtvCQzjK04a8kY69iGGU3nHlz8bBaOVpfV1WY61S65W8SlWmiaP9YyWtWWT4JRuP3mG6tzTT+bxaXksj6hiSRPTaEJADAahKbD0QwTdmH+XUvG1J5tC0C5s4i0+PnsPsnMpSs/uxDiVBKaLt6cBKts1lQtSGWPFe43j1NZ9DKjiSRPVaEJADAahKbDMcw0CXEgv51Mbfribt+vdIrmESgJOrPL6JY/W92+ikHZYy1mQIWZT2GZOAOqdfmG519euldchic0keRpKjQBAEaD0HRYhnhgBgpThaWBm4embFbS8nK5xcyn2QyjhvvkM5pqYWh235ZI1BaaFpfNmdFEksNQaAIAjAah6bC8++43z0LT009/pHr1q89Vzz//t8UyPFxDVEq/VymGpTAu8mU5EGuXzmWXz6Xf0XTzXbWZSbMgtLxP03c0xcdOL5FbPU8tYDWGpuz583UjSfaq0AQAGA1C02H43e8+Vt1//3+d/VPz//Sf/nezk8IXveifX7n9b4pleTi2hSWz2kiSPCyFJgDAaBCaDsPnn/9Mdf31P1ubsXDddS8vluN4bItI/uU3kiSnp9AEABgNQtPhGOJDiEsxNIXwlC/D4Rq/SykYZqaFuGR2EkmSDApNAIDRMIXQ9KMflbcdqvFfnguh6c47by1+zmG4braSsESSJHOFJgDAaJhCaPr2Ny9VH3v/49UjH56GH77n09W/vuaV1Ufue7T4Get+/lOPF+NlH5qtRJIkT6LQBAAYDVMITd//3qXq7a95svrkh79dffwvvkXO/Mt3fa269Gj3oSlEpfCvvDXNVvLdSiRJcheFJgDAaJhKaHrrbz1RPfdcRS7983d8tRaa/uIv3l69+MUvqu6//+3FGIqamUSSJE9DoQkAMBqEJk7VNDS99rW/vvwS9d/93d+Y3eZ7lEiS5FAUmgAAo0Fo4lQNoenhD/317F/ni5Ep+BM/8eOzqBRmLIlKJElyCApNAIDRIDRxqobQdN1P/ZtaZAq+9KUvLsYQSZLkaSo0AQBGg9DEqZp/R1O4VO7OO2+tXv3q/1h98pP3FuOIJEnytBSaAACjQWjiVM1DE0mS5FAVmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo4lQVmkiS5FgUmgAAo0Fo6sZ7zx5VR0cLz14sfr4P7z17pjr/SHn7toZ1v/a2y6vb7jlXHV1zoXq0YdndvFydv+aouume/PbTVWgiSZJjUWgCAIwGoemEPvK26tqjboLPNj5625lF2DpX3dvw820sQtOJHGZUalJoIkmSY1FoAgCMBqHpZD76+z+/fvbPIxeqa+NMp6MkwMRZQ+G/RzH0zCPN8TOjwnIhbl2sbkofM3uu4vlqP1vFsVpoisstX1N9neJyq9BVf6zy9tX929azto5nz81eU/64+1BoIkmSY1FoAgCMBqHpZM5CU2sQagpBi3gyC01nqmuX9y1nArXONEoubZuFnfgYs8dPZjjNolH6fKsgNg9C82Xz55n9bLbsfJ3Sn917WxnVVsuHP5evo/4+HPOeJOs/uxyx9b09uUITSZIci0ITAGA0CE0nc+2Mpiyc1CJM/rOG2UgzG0JLLQylcSkPTfnz1dYzBJ954GkNTWkEytYhBqPlem4amvLXvWYdaxFtDwpNJElyLApNAIDRIDSd3NnMmzTi3HOuefbOmhlGy0vUjgkr9dlD2W15aEqjTlPEWfw5nzmUz2iqzbKazWhaRarZbeH+y+ctZ0GtndG05j0RmkiSJOcKTQCA0SA0dWPtX507Ojf7bqLZz9Z9H1ExEyr7jqbii77L8DN3EX7uz2dFJbORZkGn5bHjOi6iTj1m1WcuNX1H0033NMWjdPmmy+WOf0+EJpIkyblCEwBgNAhNB2Q+oym1MWxN2xCabvrfX1VdddW/rG644ReqW2751Znnz7+6uvvuN898+OG7Zz777EeLcUWSJNmXQhMAYDQITQek0LSV+YymEJOCISzF0BSiUwxQIUZFxSmSJNmnQhMAYDQITZyqITTd9to7l3FolzCUxql1gSoPVQIVSZLcRqEJADAahCZO1XxGU24+wynGoxiK0llNMRjtKxTFdTluxlX8rxlXJEkelkITAGA0CE2cqseFpk3M489pxqgm8/VrilNNlwMKUyRJDkuhCQAwGoQmTtUuQtMm5rFn0xgVzB+rD/MwtS5OpbOmmgJVfO35c5Akye0UmgAAo0Fo4lTtKzRt4thiVGq67utmTuWRqi1OmT1FkmSp0AQAGA1CE6dqCE0Pf+ivZ4EjRo8QdMJ/Y/TIx9LQ3TVYjSHsxNeWz7hqC1q+p4okeUgKTQCA0SA0caq2zWgK8SHGpxgsxhyfcvNYk8eosYaoNvPXK06RJMeo0AQAGA1CE6dqW2hq8tDjU2oeZvIQFV97fP2HEKNy8/dAnCJJnrZCEwBgNAhNnKrbhKYmY3wKYeHQ41NuHmLSGBU99BiVGt+PTeNU/h6JUyTJ4xSaAACjQWjiVD1paNrUND6kwSHEhUMPUseZh5kYXoJj/j6pfZnGrKb3LY1YZlqR5GEpNAEARsNUQtOF33yievcbnz4V73rDk8Vt2/yc+/GuNzzdS2hqsi0+xQiQLz9V81lC+cypKVzGd1Lz9zB9H9Ox1zTTSpgiyeEoNAEARsMUQtN3vnmpeu7Zxzv3Q/d/oLru5b9U/f4bbqs+8+mPFz8Pt/3b/+1XZz/PfxYNP/uNm3+zuH1fhvXJb5uyX3ridEJTk2kMSCOK+LTeGFLy2T1pPEln9Agm6+1y1pT3mSS7U2gCAIyGKYSmrg0nUOHkKpxU5T+Lhp+Fk7C2QBBOwI57jH0YnjO/jcM1BpQpfg9UV+YzevJZUW0zePLHYbPx/T1u1tQmYUqcIsl2hSYAwGgQmjY3nuyvi0ObRKiwzLoItU+FpvEb41M8WRefTm4eSWIcie9v/H+zdbpxkzCVBiphiiSFJgDAiBCa2t0kLMXlwsnocSc8mzzWvhWapmF6Eh9P0uOJuhjVvXk4Sd/zNJbEUCKQ7Nd8ezSFrHUzrEQskkNUaAIAjAahqTSGo+Oi0Cazl4LhZCUsN4QTfKFpusaZUPGE20yo/szDR1uIMmOqf+O2ycNUvn2agqEoRbJPhSYAwGgQmlZuOoMpnFDEk438Z7nhBGST2U59KTQxNcanNHyITv2bh450e7Rdupc/Bvdvvp3MlCLZp0ITAGA0CE2bz0wKhpOFTb9fKSw7tLAztPXhsAwnwE0znvLl2K8xcKSzbWLIiNspbishYzg2hak0SqVxSpQieZxCEwBgNEw1NMUT6k3CS5yVtElcCobHHOrJ+Savl2yzaQaUGTbDNo8deeTIt6OwMXzzbdoUsPJZVXG5GLDyxyQ5fIUmAMBomFpoioFp03AUZ3fkt7cZDuw3edzTUmhilwpP4zePUFEzpcZvGqTiNk4v9YthKp1VlX//lG1ODkehCQAwGqYUmuLMpE1mG4WD622j0bbLn4ZCE/ep8HRYbhOh8vtyXB43SyqYzpISpMj+FZoAAKNhCqEpzmLa5DuYgjFIbXPgPIbIFBSa2Kdt4WmbfYvD9LgIlUaI/L4cr8cFqTgG8iAVZ1XZ98ndFZoAAKPh0ENTjEabnuxs+r1NqWOJTMFtXxvZpWl4ikFiLPsONzePUPnlWWbBHL7HBal0PORh0rggmxWaAACj4RBDUzhI3Tb+bLt8cJtZUkNRaOJQzSNU2Le23Sc5XuP2T4NEOjtKgJiuebSK3zN13Awq44WHptAEABgNhxaa4gym/PZ17hKZwvJjjDZjXGdOz3hSaeYTmwJUPjMqvw+n57oY1TR7SojiGBWaAACj4ZBC0y6XvQW3PVEJB6fbxqyhuMv7Q562YZ9L/7WsbfdZHpYxKqyb/ZTfhxSiOHaFJgDAaDiU0BQOEne5jG2X8LLLDKihuMvrJYdkOPmLYWGXfZ6Ha4xP8S8dzHziNjaFqPhZk48l44mnodAEABgNYw9N8cAvv/04d730bawzmaK7vGZy6MYZT2H/3OXzgNOxaTaUGMWTmI6ppll2xhe7UmgCAIyGMYemcPC2y4yGXS99C8839gNFoYmHbAxOu85w5DRNw1N6CV6+HLmt6SypPEDFMOUSPW6q0AQAGA1jDU3xgC2/fRN3ufQtHAgeQqQ5hNdAHmcanAQDbmsenrb9fUEeZ1OAyi/Py+9DCk0AgNEwxtC060ym4C6R6ST3G5pCE6dkDE7hM8OsAe5iGDcxOIWxdAi/BzhMmy7rTONTvjynp9AEABgNYwlN4SDrJH+zfNI4dSgnqUITp2qMTrt+DpDRPAbs+nuJ3MV8xp0QNR2FJgDAaBh6aIqXrJ3k5PAkl8+E5931vkNUaOLUjZfU5beTuxgD5kn+IoQ8iXl4CuPxUP5yjHWFJgDAaBhqaIqXK5xkNlGMVLse/O/6L9MN2UN7PeQuxpOy/HZyV9OT/V1/Z5EnNY7D8Lv+JH/JxmEqNAEARsPQQlMXgSkYZy3s+hjhfrv8y3RDV2gi57qMjvuwi1m4ZBfG2XZxPO56PMThKDQBAEbDEEJTlwdDcRbSSQ7yY+zadSbUkBWayLlxPz/J5w3ZZPyddpLfQ2SXhuOZk3xXJYeh0AQAGA19hqY4pTt+n0UXBzxd/u1xnMV0iIEpKjSRdV1Cx30qOHFopsdi+c84bIUmAMBo2HdoSmcrdfUllfkMqPznuxi/0yC//dCcwmsktzF8hhxyXObpesgzZDluRdDxKTQBAEZD16EpHFSHA+oYgrqMQTEwdTUbKtrlOg5doYmsGz+v8tvJroyXLeW3k6dpjKD57RyuQhMAYDR0EZqaZi119be3+eylk86Gyg3r2dW6jkGhiazrZIt9aIxxiArt4/LEoekf//GH+U0AAOyF40JT+qWm6QylruNMGpT2PcMozorq+jWMQaGJLLVfcN86oedQ9fk3Hk8cmr797S9W9957FUmSG/vxj9+S/zrZiDQ0pV8Qmc5O2sdMomA+Wyk8d75Ml8bANOWDfQeUZKn9gvs2/L4zzjhEjcvxeOLQ9MIL360eeOAXq/yBSZJs8hvfuL/6xCdeVW3Ds88+Wz388MPVG97w29V11/2PswAT/+nbfc30SWdHdX2J3ToFppUOKMlS+wX70DjjEDUux2Mnoen97/9XVf7AJEk2+ZWv/Ona0BSi0t13h2n7568cUNxQXXXVVdUtt9wy+/ODD9699tK5k5h/MXgMWfly+3BfXxw+dh1QkqX2C/ahccYhalyOR6GJJLl308vcfvEXX1695CX/bBaRQjwKhtlKm3DcdzStMw9Jfc5Syo1f6BvWY9+X4I1ZB5Rkqf2CfWiccYgal+NRaCK38cEbq6Ojo8Qbq4v5MuSETYNSCCkxpsRL0ELUOW5G0zq2CU1DCkvB/Due9vE9UoemA0qy1H7BPjTOOESNy/EoNJHbGELTdbdWlxd/vnzH1ZvFpux+5NhtCkrpl3Gvizn7Ck35OsWgs25d+tBlcbvrgJIstV+wD40zDlHjcjwKTeQ2NgSjizcfVWfueKhc9pj7kUM3BJI03oRf7tFNglKbXYWmdIZQH18Ovo1mL3WjA0qy1H7BPjTOOESNy/EoNJHb2BCMZrOabr5r9v8hOpWX1d1VnUsvt1u7LNm/6SVmabg5aVBqc5fQFL8gPP1X57pery4MUS7O7vLdSyfXASVZar9gHxpnHKLG5XgUmshtPCY0VU/dWp1piEpN92tdljyBfUejXcxDU4hI8UvBwxeExy8Jb/qC8HWXzvVpPmPptN/TQ9UBJVlqv2AfGmccosbleBSayG0sgtFD1YXr4qVz85lL5x6c/6wWoIr7rVmWPMammBRn0cTLx8JsmiHGj7Dur3vdv69+/devubKut1xZ56tmUSnMVtqE0wxNeVwyY2n/OqAkS+0X7EPjjEPUuByPQhO5jVkwml/+trjsbTZDKV4CNw9Qy2Vn/1pdcnlcy7LfzJ+PkzXGpKYv3B56TIrm3+8UL3cLoeltb/s31S70HZrSuBQDU74M96cDSrLUfsE+NM44RI3L8Sg0kds4C0bJ5W4NXww+/9nV1YUHQ0y68t+nws8WMSn5PqamZT/29Ybn5MGaf9l2/JfS0pg0lsuy2qJS0/rnl85tQx+hKf+ScXHp9HRASZbaL9iHxhmHqHE5HoUmkjyhm1zK1hRcxmCMLnl4OcnrGUpoEpSGrwNKstR+wT40zjhEjcvxKDSR5AY2xaR89tHQL2VbZ5xdFV9fDGUnjUpNnmZoEpfGpQNKstR+wT40zjhEjcvxKDSRZFVexpbGiPDfeNuYY1I0j2bxkr19RKUm+w5NvmdpvDqgJEvtF+xD44xD1Lgcj0ITyckYA0vTdyLloSUsm99/jKZRKX+t+w5KbfYRmtK4FANhvgyHrwNKstR+wT40zjhEjcvxKDRt4Lf+bu4zn3985mMfnfvQ+54o/MBbjze/T3y8+PjhufJ1YH+m27tpW6fb8q43bGfbWDAGujHOStrlErd8H4/b5iPv/WJtW7/r1i82+GR1+y2XZv9td7X87a+4tHy89194snE87DIWmr5PKb7m/PWepvsKTfH1x0vihvSauZsOKMlS+wX70DjjEDUux+MkQlM8gYwncfFE7963XK4eeM/Xqg+++++qxz7xvZnPPVcN0icff2Hmx//y76uHP/iN2XqH9X/fHc9Ub3nF47OT1Hhyus2J6aGabvM//t0rA/3Op5fbPGzv8D6G7R3e0/y9Hqr5GHjv7V9aRowYseIYyN+PsZlfxrZpLAqGbZ/v6+98/VO1fX1M2z1303Ew5M+Bk4Smz372oercuf9pOR7CWDiU2Wec+/zzn6k+9al7Z/70T79s+f9PP/2RYllyKl6+/NByX/i5n/vp5f9/85ufLpYlu9AJPYfit7/93xqPCxz/DduDDE3xRDPMRGiKC/mJ2yGYnnjGAHVI4eE44zYPUSnd5oe6vXNjfIjhIWz/GB2Guv3zmUchIMUvoI6XO20yKyVu+xiVPvQnX5nUtk8NYyC87nwcfPR9w/oc2DY0Pfvss1fGwvkr4+KG6vrrf2EWmvLH5OH41FN/VR0dHRWeP//bxbLkVHznO3+v2CeCjz3258WyZBcKTRyKjz76geKzL3j77a8rluVwPJjQFC91SU8085OwqZmHhxie8vdujKYzlsI2D7NVphgW1hmjQ3hvwvYPl2j1uf2P+z6k42YmtRnDUpylNtWotKkxQseZT0P4HNgkNMW4dNVVV83+e/fdYYysv3SOh+P11/9s7WDyxS9+UfX1r3+qWI6cit/4xqdn+0G6X7zsZT9ZLEd2pdDEofid7/zN7PMu//wzo3PYjjo0xRPOeLKZn2CxbjjhDNEhnKCH2V5DmuGwqfk2H/MlUH0bw2OMTifd/vnlbeklbmlIirOSTjq9Nd/2+evjZsbPgTADLLyf+fvch02hKYalW265ZRmXHn744doyAaFpGt5331trB5S/8ivXF8uQUzP8Xk33izvvvLVYhuxKoYlDMnzeOS4Yl6MLTeHkOJwgmcHQjU9fen7+fp7yDId1hsAQ4pht3r0hOrz1dx6v3vPmjyxDUdvla9vMOurSsP1t+/0aw1P+3u/DMI5e97p/X73kJf+sNlNpU4Sm6Rhjk4NJcmWMTf4lzXb/8R/K27i9QhOHZoxNjgvG4ehCU7j0Iz9J4skMsSHMcsnf66EYZrCYubQ/w3v7J3/wxepP33E6Iek4w/bP15ndG8ZBuKwuf/9PavyX4NIv777//luLGU2bMqTQ9LH3X6r+5Pe5T9/wf12s3vWGzxa3s1vvedMTxfg+bf/b//d4sZ68NNsf/vNNDxS3c+573/xE9cW/KccTt1do6tZHLvpMO6nh889xwcl98I+fKMbnPhxVaAqzbsJ3jeQnSDy5n/nkt0/tMpp1hm0evlsmX192a5gxFC6nzN//09Y+36/hS/TzbbCLMS7F7+UK/5/+vOnSuU0ZUmgKJ8Kf/qvvVF947AfkaH38Mz+o3v1fyvF92n7mY49XH7v/m8X6km1e+uwPq/fd+eXqucvDnaU/JoWmbn3soSufaX/xrWLckn36mU9+r/rgO58oxuc+HFVoCn/b7rtZ9mM4md/HbIaTGkLDH/0/zxTry261/Rn83f/j87NLFdNt8IMffLbYLrnpvyAYZy2tu9TykELTx+7/VvE+kmPyic/9cLCh6SP3faNYX3Kd737j00JTRwpN3RpC00fe/81izJJ9+ujHvys0NTn715I+8b3ZSbHg1I3hfQwn8vu6bOakxhktYT19+Xe3hvdyLNs/rKPvadqP4X2N72+Y0RRDU7j+PX7h4pe+9LHZbellcPH7u/JttolCEzkchSYekkJTdwpN3So0cQgKTS2GE+EYGsIJ8j23f8U/bb6DMTC8+ZYvLoPd0ENDut5hu9vmuzvG7R/WL2x3wak7Y2RMo30MTddd9/Lav+zx7/7d/7rRTKVNFZrI4Sg08ZAUmrpTaOpWoYlDUGhqMQ1N0XgCGk6awwmpk9Bm00gTzL/3ZuihIV/XGEpEp81MZy8Fm97TIW3/eCnWhd/7s9q6pq+jaRyz3fS9SyNjaghN/+qnfqYWmYK/9mu/Umyjkyg0kcNRaOIhKTR1p9DUrUITh6DQ1GJTaIqG28NJZwwp8SR0qhEinlSmM1eaTizT5YcUGqJNoSld56aANtVtntq0/de9L6e1/dPv9olfHh1mzoT/hj//xZ88tHb7x20fZ+ase41TM34mpoFx3WdAMIamF7/4RbXQ9JKXvKj6h3/4QrH9dlVoIoej0MRDUmjqTqGpW4UmDkGhqcV1oSk3D0/pDIhwMrrp4wzd8DrC64lRIc5WCK81/HnT13laoeE414Wm3PzEOr4PcZsfYoRo2/7xz5u+5n1v/xCU4vf7pP/UfQxKITaFn+f323T7x/ch7vNxfw/vwaHHx/S1n2QMBOOlczEA3nnnrbPvavrlX/656vHHP1Rsn10VmsjhKDTxkBSaulNo6lahiUNQaGpxm9C0jeEx85O1eLKaGk7e4glsNJ7MpYbHyM2XSc2fKz5P08nyNieN27jv0LCL4WR33YyWk5hv8xgo0kiRbpO2bZ5v5+Ns2vb5c6XjLH2ePrf/a1/769VVV720etnLfrLYLun2ufvuNy/DUTTGpC6+y2fT0LStJ932+XaNxm2Umi+Tj4OmMXDcOMhfT1emXwa+T4UmcjgKTTwkhabuFJq6VWjiEBSaWtxXaNrWGCniyWpuflK57iQ0OJTX1HdoirMmYqwIs1vSYBH+/Ds3/+HsvcvXt2/btnm+jY+zadsPafuHbZL+a2PBp5/+yPLytrBN4uVtXQalNvcVmraxadvn2zWah8RNotRQxkBQaNpOoYmHoNDEQ1Jo6k6hqVuFJg5BoanFoYSmQ7QpNL3pTa+pfuZndt+2Td+/Ey+ZiiEp3B5C00kvneLJDNv/tld8aLZt8i+CDv/i2L6DUpu2f78KTdspNPEQFJp4SApN3Sk0davQxCEoNLUoNO3PNDSF4JP+8+Y//OFni20Rv3Nnm5CUP8YmCg39GLb/77/yw8WXQAff9747iu3Sl7Z/vwpN2yk08RAUmnhICk3dKTR1q9DEISg0tSg07c/wvr7m/7yviAzBN7zhN3YORSdVaOjHphltX//6p2Yx8UtfKmea9aXt369C03YKTTwEhSYekkJTdwpN3So0cQgKTS0KTfszvK9/fNvfzL4EOsxmCl8EHUPT29/+xmJb9KXQ0I9NoWkI2v79KjRt595D0yMXqmuPzlTnH4n/H/8C4Fx1b77sc5er89dkt4f7nL1YX+6ec9XRNReqR/P7N95+sbopPn++/BrvPXtUXXvb5eWfH73tzHy9Z48f1vOouume8n47O3tvmt6THa291wNf1w6cYmhajsnUfF/JbdxHdrA2vpL9Kxt3+X7+6G3n6vti0/69XPbMah9MP0calj2J+b4+BIWm7hSaunXvoSl8Rq35DNlofz3ud9RxP+/DPX6mde1G73nPCk0tCk37Mw8NYSZLjE6/8zv/sdgWfSk09GO+/Yei7d+vQtN29h+a5gd34cClOCleHGDWosjixLV2W+vJckNUal12vbUDq+KA8IShqWmdOj3wzdbvngvdHsx2uq7dOMXQVLMYoy02jb1tLfbJK/td3JezsTGLYcnzFScsresTxnAesDZ4fTtYrNMAFJq6U2jq1l5CU/KZMA/qq8+UjfbX435HHffzPtz4M21+XFPevh9n73d2bLbRe96zQlOLQtP+FBqmre3PoNC0nacVmvKDyeAsPoW/wUxvX5zU1v5Ws+G+6WOkB0T5n3dyzfPtZNePV9gQ3A7cqYemppODRjsYe42ROJqfwNX+PA+geXjKZyws71d8DkxnTAtN3Sk0dWvfoSnYye/x1Pxz6jTc+DPt9EPTEBWaWhSa9qfQMG1tfwaFpu08rdBUHjiGg6krP8sPvuJ90oPPhgPRpbWf1YNL/VKj+snvTfcsToKv3P76RfCard9iltXqEqG4XDajI5nqH29fhrPa89WXnR3QNcS02n2Xr2c+y+Oms8nraDkgbD2Bjyf7+f3j+xzX5ewfzNYznbU122avfmOxrvX3qO32TQ6od3faoakhLC7H1NzV7Lawf5yrblqOgXSM1Mdm84ndfJnW2XzZCVz9pGW+j4fxO1/XK3++MrbPL/+8snbZ3PJxk8+R2muI61Ou2+pzpvm1xf1s9Vz1/aPt9rb9riuFpu4Umrr1NEJT/Bwp9tfsc272eZb/Pq0tUz8WuWn5e7btOKHhWGT5OzJ8BrR9LrR9jiRu9JmWHgvUj1nK58yPORbP27Te2fvW9n6G24v3vOWzdN1r2IdCU4tC0/4UGqat7c+g0LSdpxma8gOn+snw4kAzuc/yhPq28kA0NTx2eKzVyWp2YLY0PO78Z/UDwey24sA3OaGdxZSmoFMVB23LA8Li8dLHaVif5fLZ+9QUGAoXr73h4LK2Xul2Wt539fi1E//kNbfNbskPeOeeqe7623z9unG6oamMK+WYTMZNNvaWIahh+5cxuOX5UpP9Nb9srvZcV/4b/rxcp3QMzU5Ysv2j5XNk9rOWuLwcs2tfW7K/NSy3eu58LB9VP3bur+rLdajQ1J1CU7eeZmiq/26ufxbVPm/Sz8C4/+afMWs/Q5J9vXYskoen8nOhHqBajg3yxzt2fRYzmtY8Z/3zNnlv8vVeWP8dnYW22u/09Z+Ry8/SltfwxeQ5u1RoalFo2p9Cw7S1/RkUmrbztEJT7eS38eCp6T7JsvmJaP6cZy9Uq+94aYg3S/N407B8ceC7SWhqOAg+ldCU3L/hIHFp/j4vnJ+sX6hms83Sx9skNDXcvi+nGprymDOzGJNdhqb222e27eO1+4Xbw2yC5EQwW6fi8Vs/R6rG11Qbs2tf2/qTqOK509v3qNDUnUJTt/YfmtLfiQ2/m/NjhuXt2e+zxbKrY46mz5CGx6+FpvxY5LjPhUW0avpduPFnWh6a2p4zxq1VfFrdp/5elFFKaFqn0MSZQsO0tf0ZFJq28/RC0+rgpilKLG/LD16eyw+SmlwccOUn1PmBZ7LszqGpiD1X7ntbvt7Z+rQeBM9vq7++xX2TvyXdJDTdG0/iZ/9fv3/+Xs9seJ9XtzeEr7hs/t5cWf78MsA1r9s+nGZoaptdlN2ebouGKJOOjeV2Xmz38rGbfnblvmdbTsaWY6U+dusnM2F9032lYdy0fo4sniMbg/Uxu+61pT/L968r+85tq5PPxv1mTwpN3Sk0dWvfoWk+86b+uzTuy+FnjZ9RTb9jF8uviyKPZr9Ta8+d32fTz4X88ym68Wfa/PP82OcMj9H6PPX3ovaXBbP3Kvtsrj1O+RnZ+FmaP8/iNQhN1XBCU/m3RNkG7dLF4GgswV2YD7geHGVoaPsA6sCySi/c97YP2v5L127/mWE/7/e9Cs5/gSY2jZUTWn6m7V+haTv7D02rMdccatL7nVt8r0C+fyQnti2Gz7/8AHQem/LnL08ui9+9xed0diLf+LrSfezK67sneR/iweLsZ4vXlh0Y1/bPLDqt1rXlvYt/i1rcP3/u5Pkb3+e4Ltnt2brW39fsQDNZj31+FkwxNOXjubatW8ZkPpbL4LPh9soef3Yp3PL28qRm/p1fyVi9stxNy8dPxnG4f9MxUfE5Up7QpPcpxmzra8uPs9cvt3qvz1Xvz9exQ4Wm7hSaurWX0JTsg02/v9LQ1Lhs8juq8ffTms+QdPmb7kl+1+f3Sdan+fFXt+fHIjO3+EyL65Qesxz3nMvl88fOlz27+O6rpt8Ds3XY8DMyfx6hacV0Q1N94LWGiZr5gW6LDY+/b0cZGhoOkLqydXs2bJvWZWu2ndQ02PAc+3aU2/+55Bdlx+PguG1aft5stn2Pe9zU8jn2r9C0nXsPTWQPTjE08XAVmrpTaOrWvYemLcxje9/Hm4PykYu1L+JumtF1SApNLe4emuoF89iyGAPGogwXO19TCGgpusWXhOW3ZxV19lxFWa3/TVaxfHF7snytbrefCI8yNKwJTY0Vvri9/n7kH7qNQWDHbV//m4Pmgt68LbP13Og+E9n+8ZKB2Wtve82L97rptvxvNuL2bnuPE9s+b1azTDZ/3MaxUdyePE7xs5b7LJdveZ0NCk3bKTTxEBSaeEgKTd0pNHXrkEITp6vQ1OLOoakpDhQzEJITxVk4ODObzpw/z8ymx0umGqbLzsLDMoYcM6NpccJcPH7+52z58BoaZ0rkIWbxOA/mj/PcSEND/voWFu/FuuXSqaL5VMv8/Qw2bYuNtn0+3poeN42P+9v+D+SP89w4t3/6mtP9v/wsaLqt3BfTZRrfzw0eL3/e/DKhTR636TU1/bm8T9MYW/86c4Wm7RSaeAgKTTwkhabuFJq6VWjiEBSaWtw5NC3/Rj85Wa/NcFg5W74lHCxtOvGvndRnMxqOCU312QkNoSm7X758bWZU66yH1fJ/9Jn68wfHGBqKkJK8V+Xrju9n87bJx09rECi2Tb4ezY/fHAHybdQSmjre/u84iO2f7UvpNljs27XPg/y2+H7lLt6/1u2/MB8v+frks+PWhqZ8XVpCU+01rrnPuhlw+fK5QtN2Ck08BIUmHpJCU3cKTd0qNHEICk0trgtNZXRoPrFfLTcPAo1/s188VmYWAuYnlfG56s87P/GLy5azHmonk4uT4fzx0/DVtHxTuFoFs4b3oMHxhYbF62/YTvPt0RQK27dNffZRSxAI7rzt6zNb4s8bt6Xtv7Rt+8/e22z7lLc1hd142yJINm3j58rxkFuPQIu42BSpFqEnLls8bm1bL9apMX4mnx1r7rNcx+Uy619nrtC0nUITD0GhiYek0NSdQlO3Ck0cgkJTi2tDU3jjWmYR5H+rvzrxbJl90hIwlhazBOpRI12P2rfux8de/Gx10rh4nLPzb6+f3RYu3Vs+fssMhcXy4b/1155HitW6Noa158YXGppe28zFdmsbC+u2zTwMJTadnJ9g29d/lj1Wsi1t/5XN2/9rzRF5EVden27HJNrkt5Wz39JtmXw2NHwW5GOl/r7W73tvLS6Vj7t6rDO1f13r3rNXxkC6fsl4bL5P/fMsj1TNrzN7XULTVgpNPASFJh6SQlN3Ck3dKjRxCApNLR4Xmri74woN7Frbn0GhaTuFJh6CQhMPSaGpO4WmbhWaOASFphaFpv0pNExb259BoWk7hSYegkITD0mhqTuFpm4VmjgEhaYWhab9KTRMW9ufQaFpO4UmHoJCEw9Joak7haZuFZo4BIWmFoWm/Sk0TFvbn0GhaTuFJh6CQhMPSaGpO4WmbhWaOASFphaFpv0pNExb259BoWk7hSYegkITD0mhqTuFpm4VmjgEhaYWhab9KTRMW9ufQaFpO4UmHoJCEw9Joak7haZuFZo4BIWmFh963xPVY5/4XvGG8eSG9/XP31a+56ftM59/vPrgu/+uWF9265C3v9DUn++74xmhaQtDaPrrD327eB/JMfnUEy8MNjQ9/EEhl9spNHWn0NStITQ9/EHHtDxdP/PJ7wlNbYbYFP7WPX/TuLsPvOdr1d889ETxXg/FsM1vv8Vstn0Ztv8QZzNFw/bP15ndGvatd9365Czs5e//PjyU0PSdb5a3sVud6PTj975d3nbafvfvy9s4136x3u9/t7yN22ucdet3v1Xexu01Lk9uX5+RowtNwW9+7ckrJ0VfNNPhhIaZQuF97Ovk8iTGbW52U3eG/ef2W+aXp+Xv99C0v+/HEJhCaLz9FeV7vk8PJTRx/zqgJEvtF+xD44xD1Lgcj6MMTcFweUeY6XDfnU/PZji5pG4z0xPLj75v+IEhNWzzMPMqbPPwGmzz7Y3bP4SbsP/k7/FQjfu72NiN6efAaYRGoYmb6oCSLLVfsA+NMw5R43I8jjY0pYaT0PD9MmF2RohOZj6sDCeUIciEk8oQaD7y3i+eyoll14bXMNvmr5hvc9Gp3RgVwva/6w1PjC4wpsbY+P4LT8729xCdbPvNjJ8DYZ8J0a6P72JqU2jipjqgJEvtF+xD44xD1LgcjwcRmqLhxCmeiIYT6jQ8TeVkNESF8HrjrJVgCAtjuDxuV+NslxgfprbNU9Ow+M7XPzWLCiEuHuL2D9s9vK4QHMO2D9tdeJpb/xx4cjmDcSjjQGjipjqgJEvtF+xD44xD1LgcjwcVmjY1nqCGIBVOUsMXIYcwFQwnZeFfXgonreEkLZysxWgRDCdw+/hS6vi44Tnic4bnD4Z1CcEonCyGdQzrG8LKkE4ch266zeP2jmEqBJnwHr/39i/Vtve+tnWb6RgIhmgSx0BYxxgMwrqHeBS3vzHQbrrdY4yM271tP+9zm7eZfx7EsTD/LJh/X1kwjOUwDsIMvzGNA6GJm+qAkiy1X7APjTMOUeNyPE4yNB1nnBkVTtzCCVw8SQ2GE7s0TIWT1njSlxtOZvPbaj9fRIMYj9KAFE8cx3TyOFbbtvf6bR3+v24MVqnhthiJ6m4+Bk7zEqdDdt12X4XndF+eb7t0+4Y4GWPgpqb3bxsPf/y78wB+qGNBaOKmOqAkS+0X7EPjjEPUuByPQhPZoTFeRPOfc9zm2zfG4G00NoQmbq4DSrLUfsE+NM44RI3L8Sg0kSR7VWjipjqgJEvtF+xD44xD1Lgcj0ITSbJXhSZuqgNKstR+wT40zjhEjcvxKDSRJHtVaOKmOqAkS+0X7EPjjEPUuByPQhNJsleFJm6qA0qy1H7BPjTOOESNy/EoNJEke1Vo4qY6oCRL7RfsQ+OMQ9S4HI9CE0myV4UmbqoDSrLUfsE+NM44RI3L8Sg0kSR7VWjipjqgJEvtF+xD44xD1Lgcj0ITSbJXhSZuqgNKstR+wT40zjhEjcvxKDSRJHtVaOKmOqAkS+0X7EPjjEPUuByPQhNJsleFJm6qA0qy1H7BPjTOOESNy/EoNJEke1Vo4qY6oCRL7RfsQ+OMQ9S4HI9CE0myV4UmbqoDSrLUfsE+NM44RI3L8Sg0kSR7VWjipjqgJEvtF+xD44xD1Lgcj0ITSbJXhSZuqgNKstR+wT40zjhEjcvxeOLQ9P3v/1319a8/RpLkxn7ta5/If51sxDe/+bnisXi4/tIv/VxxGzl17RfsQ+OMQ9S4HI/PPvvh6vnnvzo7ft8pNAEAAOyDG264Ib8JmDz2C/SBcYYhYlyOE6EJAAAMBgeUQIn9An1gnGGIGJfjRGgCAACDwQElUGK/QB8YZxgixuU4EZoAAMBgcEAJlNgv0AfGGYaIcTlOhCYAADAYHFACJfYL9IFxhiFiXI4ToQkAAAwGB5RAif0CfWCcYYgYl+NEaAIAAIPBASVQYr9AHxhnGCLG5TgRmgAAwGBwQAmU2C/QB8YZhohxOU6EJgAAMBgcUAIl9gv0gXGGIWJcjhOhCQAADAYHlECJ/QJ9YJxhiBiX40RoAgAAg8EBJVBiv0AfGGcYIsblOBGaAADAYHBACZTYL9AHxhmGiHE5ToQmAAAwGBxQAiX2C/SBcYYhYlyOE6EJAAAMBgeUQIn9An1gnGGIGJfjRGgCAACDwQElUGK/QB8YZxgixuU4EZoAAMBgcEAJlNgv0AfGGYaIcTlOhCYAADAYHFACJfYL9IFxhiFiXI4ToQkAAAwGB5RAif0CfWCcYYgYl+NEaAIAAIPBASVQYr9AHxhnGCLG5TgRmgAAwGBwQAmU2C/QB8YZhohxOU6EJgAAMBgcUAIl9gv0gXGGIWJcjhOhCQAADAYHlECJ/QJ9YJxhiBiX40RoAgAAg8EBJVBiv0AfGGcYIsblOBGaAADAYHBACZTYL9AHxhmGiHE5ToQmAAAwGBxQAiX2C/SBcYYhYlyOE6EJAAAMBgeUQIn9An1gnGGIGJfjRGgCAACDwQElUGK/QB8YZxgixuU4EZoAAMBgcEAJlNgv0AfGGYaIcTlOhCYAADAYHFACJfYL9IFxhiFiXI4ToQkAAAwGB5RAif0CfWCcYYgYl/vhhRe+l9/UKUITAGBSXLx4Y/Wd73z0yv9d4gC94YZfKG4jp679gn1onHGIGpfd+/TTb6+++MX3VvtEaAIATIoQmr7+9fur/Jcuh6EDSrLUfsE+NM44RI3L7v3c594oNAEA0CVC07B1QEmW2i/Yh8YZh6hx2b1CEwAAHSM0DVsHlGSp/YJ9aJxxiBqX3Ss0AQDQMULTsHVASV7xwRuro+turS4v/rzJfnH5jquro5vvKm7fnw9VF647qs49mN8+d7Y+yWtoNXut+7dpvZtum56bjDOyb43L7hWaAADoGKFp2DqgJC8V8WWT/UJo2tT16z1lNxlnZN8al90rNAEA0DFC07B1QEleKuLLcr8Itx9dXV14an77MuY8dWt15ujoys/mnrnjoWT5ePvqfhdvni8T/ju/PcSXq6tzN1+9Wj5Gq7bHPibY1EJTWI+bb6zOFetyV3Jb8pzZ7flzrl7T4vnj+7V4vWH52fMXz7dYr9rtq8eMr6W+zI3VxcVrCu/XuZuT93S5jerrtVrfcenzl0PUuOxeoQkAgI4RmoatA0ryUhaIrvji/zn72Y3VxSxGFTOa8plCs2A0jyaz0BTC0jISzUPJMpDMll3FmaW127cMTVmwWa5rvp6zyJQ+9+p5avdL12X2GFdXZ1pmdNVnVzWt9zxsLaNVsq7pfWvPn94neW/z5x6TPn85RI3L7hWaAADoGKFp2DqgJC8V8SXfL+YzbuohKA9N89lKufP71INJMI8v9dhTf6wdQ1NbFMtDUx7ZkllCa0NTEXqy2VIbhqbivckDXeOMrjijKV+HcZmPM3IIGpfdKzQBANAxQtOwdUBJXiriS7pfrCJNPQYV34k0iy8Ns5KqPJgE8/iyeuzasosIlMaVtsvEtgpNtUAzjz6NjxuWbZq1lMeqxlAWn6NpvdtnNM3um8xoag5N5br8IL1tJPr85RA1LrtXaAIAoGOEpuH5hS88UL3iFTfNfOlL/8Xy/9/61luLZclJ2DSr53+4tvq3P/8TV/7/l1ZRphaTkhk8tUvW6rOCwv22CU2172i6+a7ysreWKLRxaKp9v1EMPC2zkYr3Jb10Lg1N9e9ZOvdgEpKyx5mve/3n676jqTE0Zd9jVcSnAfvpT7+v8fP3oYf+pFiW7MvPfOb+xnH5Z3/2h8Wy3F6hCQCAjhGahud3v/tY9eIXvyg7gTyqHnjgncWy5FT88IfvKvaJn/iJH6+++tWHi2Un41O3VueSqFUGM27r5z73wepFL/rnxVh75pmPFMuSffnEEx+uXv7ynyrG5V/91R8Xy3J7hSYAADpGaBqmv/Ir19cOJkN4ypchp+Q3vvHp6syZl9f2i+uv/9liuUmZzRzKZzFxN8O4SsfZdde9vFiG7Nt8XL7sZT9ZLMPdFJoAAOgYoWm4xtgkMpFzn332o8vYNPnIxL0aT+pFJg7JOC5Fpm4VmgAA6Ji+QtN3v1XexvWGk+pwadCdd/pupl38wfPlbVP3R/9Y3jY2w/7wYz/231cPP3x38TOezO9/r7xtqt5331uNswa//93yNvZnGJeOC7pXaAIAoGP6Ck1ffOzx6o5XPVHd+ZuXuIVvvuXzxW083re/5snqUw88XozDqfsPL1yqbr+lfL9G5asuVW955ePl7SPzba8ut89p+4VPhffV53T09ld+obhtyr7jPz9ZPfW3w/tcfdtvl+t6yN7+iumMy9tfUW7vfSg0AQDQMX2Fpq8+/Xj13tu/VD33XEXu3Yc/+PdCU4MhNF34rSeK94v9+rWv/ujKdii3z2l7+QuPV3/5zq8W60sG3/+2Lw8yNL31/75yjPHlHxXry/H7lleW23sfCk0AAHRMn6HpPb/3THEQQe5DoalZoWkYfvUrww1N993pLwTY7JBD05ef/cdifTl+hSYAAEaK0MRDVGhqVmgahkITx6jQxL4VmgAAGClCEw9RoalZoWkYCk0co0IT+1ZoAgBgpAhNPESFpmaFpmEoNHGMCk3sW6EJAICRIjTxEBWamhWahqHQxDEqNLFvhSYAAEaK0MRDVGhqVmgahkITx6jQxL4VmgAAGClCEw9RoalZoWkYCk0co0IT+1ZoAgBgpAhNPESFpmaFpmEoNHGMCk3sW6EJAICRIjTxEBWamhWahqHQxDEqNLFvhSYAAEaK0MRDVGhqVmgahkITx6jQxL4VmgAAGClCEw9RoalZoWkYCk0co0IT+1ZoAgBgpBxGaLpY3XR0VN10T/j/y9X5a46qo6OV89vr3nv2THX+kfS2cL9z1b3F4+bLXfGRC9W1R/my8+dteq613nOuOrrmQvVo+ufZes8f/96zR9W1t10u77ezO67ncV5Z7/p6rtsO6fbaj0JTs3sPTe97ZW2bz0zHd6Pdjcmwvyyf9+zF5tuP8n3qynhMlp0v37Dfd6jQ1PR5u4ONn8UbmH/u7ury8zrY8Zjpah07dJqh6bnid1nT77pjP7+O2Z7d/67fxYb9sjbG65/nj952ZvbnS8XjdKfQBADASDnU0LQ86JsdJGUHTrOTk/ygbhFGaiecLaEpf47lY570hKcMMCc7+Gxa/4Z1P7GL9652EJ0/T/raytfZtUJTs3sPTTU33c75WNnNWUyqnQSdW479+n6UrVex73azPuucfGhanLye+D0utl2DTSf4Tbdtbf3z9dHbLqxfj23tZB27dcqhKf9dtvo82fDz4pjtebLf9R3ZtF9m6x3jUviz0LQdQhMAYFIcfGhqiC2zg6PZ386VJ5f1g6zyvrXHSKJU/ued3OSkaSvb179TF+Gu/t7l2yE9kN40QOyu0NRsr6HpmBOrleVY2drZGGwf6/lJXO3P+clVY4ju1qmHpuUMs43Gxxo3+czceBxu6SbPfWAKTQv3sO3zz6jTsHG/zPef5LULTdshNAEAJsWhhqblNO88/iQHTfU4lJzsLpdZF2rSk+Ow3OKgc81B2exA8poztQPW9G8Hy4PX+XPMDz7T/5///N7bypOn2uM1rn/yXmWzvdL7zg44l+/NujCUPEdt/fN4kK7LusfrRqGp2d5CUza2gvWxmY6xxT4bx1sSjdrvU3++40JvfulcHkBvuufKOpyNYz8895UxeuV5H294rC6ccmhKt1Xt5DqLhfm2r92/8TOz6TM8+/+Gxyie554Ls3XY7MQ/+X0Tx1/+fGt/B9Q/o9PnPH4d88/YTdd5d4WmaPo7LPn/bAynn1f579d8O82Wrf3uzp+zfMzjxlMcn03Pl9u6XzbNaMpek9C0GUITAGBSHGpoWh54ZbMVyhObhpOU5XIXGkLNynCQNXus8BzJAVp6Qjt3/hjpAWL6GM0nTat1mj3H2hkb89e/fL7awWp+n9V7VaxPfkK0PDAtT2iW1g5C0+WSE7CF9YPhlsfrSKGp2X5CUxlFG29bjp18fMVxu+4+9ecsTsQzV+M5H3urfSQNTPN1OlO9/wvlY3XhdENTw+dz2+dfbVu3fMY13efKZ1rY3o3PsXA1XhrGWPpYRy0/K5yvX1h2p98Bs9vCYzSF/5Z1nL32/HnKx+9SoSma/m7dPjQ1ja21v3PzbZ0eb6Tbe/G4uU3PV3fNfpk/ZrIvCU3bITQBACbFwYem5/ID+fIgrPl+MZTkoSZ73isHWeeTk5riwC+x6W8VTx6aspOQ4uQsv0+3oanxpGr2mO33KU/2u1doaraX0DQ7ManPZirGaVwuOZEu48+6+2TPWew7dWvjuS1uXLn92rPnqpsWy4X73Pmx8rG6cLKhKT9hnrn4jMq3YTY+jt1+M8Oy52rBpmnMHBtx8mWLz9HS+Hum+FxNbPodEAPT+fgXF+njrVvH1t8J+1NoWlj7jKv/PpuPlzi2m8Lh6nHSsdX+O7fh8ZPQVHw+rvkcbB3L6/bLhv2n9nhC08YITQCASTGF0BQPxloP9BpPdquNDuTnoSU7qWm5T3FQ+NwWoalh/eaXztVjUn19moJOclt2UDq772Jd2g96E5ven+VtLffJ16H4WTcKTc3uPzQ923xS/Fx+ojUfH81RcjWm2++TP299/M5uuzK+42M2jefZn9eE2fDcr7/vG8XzdOFUQ1NThFneln/+LbfNms+4hs+g9ER8+TjZyXc6rsrl55fOrdYxH5/J7WfrY3M5pvLPxYVNvwPi7duv4/r9YR8KTdUyyqy2Y3780bztm44/0rHV9Bk1e8zafrHY5o2/p1fr0jTGisdNbl+7XwpNnSE0AQAmxWGEJrKu0NTs/kMTN3GqoakXr5wYN50U8+ROMzRt571nk2CYx1NurdAEAMBIEZp4iApNzQpNw1Bo2oeL2R5XTuzLn7ELhabjDN/RFS5PC+Nwbj57iNspNAEAMFKEJh6iQlOzQtMwFJo4RoUm9q3QBADASBGaeIgKTc0KTcNQaOIYFZrYt0ITAAAjRWjiISo0NSs0DUOhiWNUaGLfCk0AAIwUoYmHqNDUrNA0DIUmjlGhiX0rNAEAMFKEJh6iQlOzQtMwFJo4RoUm9q3QBADASBGaeIgKTc0KTcNQaOIYFZrYt0ITAAAjRWjiISo0NSs0DUOhiWNUaGLfCk0AAIwUoYmHqNDUrNA0DIUmjlGhiX0rNAEAMFKEJh6iQlOzQtMwFJo4RoUm9q3QBADASBGaeIgKTc0KTcNQaOIYFZrYt0ITAAAjRWjiISo0NSs0DUOhiWNUaGLfCk0AAIyUvkLTM1dOYO7+fy+RvfiBtz1ZfeS95Ticut/51qXq3W8s3y/275/+/hPF9jltP//Jcj3J1M8+XI6b0/aeNz1RrCcPw3v+sNze+1BoAgCgY/oKTWTf/uD58rap+6MflbeR5Ka+8MPyNnLsCk0AAHSM0ESSJMmpKjQBANAxQhNJkiSnqtAEAEDHCE0kSZKcqkITAAAdIzSRJElyqgpNAAB0jNBEkiTJqSo0AQDQMUITSZIkp6rQBABAxwhNJEmSnKpCEwAAHSM0kSRJcqoKTQAAdIzQRJIkyakqNAEA0DFCE0mSJKeq0AQAQMcITSRJkpyqQhMAAB0jNJEkSXKqCk0AAHSM0ESSJMmpKjQBANAxITR9+ct/Uj3zzDtIkiTJyfilL72neuKJ24UmAAC65BOf+M3qU596HUmSJDk5H3vsD6rPf/4d+SFypwhNAAAAAAAAE+GFF76X39QpQhMAAAAAAAA6QWgCAAAAAABAJwhNAAAAAAAA6AShCQAAAAAAAJ0gNAEAAAAAAKAThCYAAAAAAAB0gtAEAAAAAACAThCaAAAAAAAA0AlCEwAAAAAAADpBaAIAAAAAAEAnCE0AAAAAAADoBKEJAAAAAAAAnSA0AQAAAAAAoBOEJgAAAAAAAHSC0AQAAAAAAIBOEJoAAAAAAADQCUITAAAAAAAAOkFoAgAAAAAAQCcITQAAAAAAAOgEoQkAAAAAAACdIDQBAAAAAACgE4QmAAAAAAAAdILQBAAAAAAAgE4QmgAAAAAAANAJQhMAAAAAAAA6QWgCAAAAAABAJwhNAAAAAAAA6AShCQAAAAAAAJ0gNAEAAAAAAKAThCYAAAAAAAB0gtAEAAAAAACAThCaAAAAAAAA0AlCEwAAAAAAADpBaAIAAAAAAEAnCE0AAAAAAADoBKEJAAAAAAAAnSA0AQAAAAAAoBOEJgAAAAAAAHSC0AQAAAAAAIBOEJoAAAAAAADQCUITAAAAAAAAOkFoAgAAAAAAQCcITQAAAAAAAOgEoQkAAAAAAACdIDQBAAAAAACgE4QmAAAAAAAAdML/D2DLcuXHr8AEAAAAAElFTkSuQmCC>