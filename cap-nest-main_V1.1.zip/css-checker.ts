/**
 * CSS Checker Utility
 * 
 * Checks if CSS classes and variables are properly applied at runtime.
 * 
 * @fileoverview Runtime CSS validation utility
 */

const LOG_ENDPOINT = 'http://127.0.0.1:7243/ingest/655b401e-78b2-4cd9-abd7-bb6c02ec2b62';

/**
 * Check if CSS variable exists and has value
 */
export function checkCSSVariable(varName: string, sessionId: string, runId: string, hypothesisId: string): void {
  if (typeof document === 'undefined') return;
  
  const styles = getComputedStyle(document.documentElement);
  const value = styles.getPropertyValue(varName);
  
  fetch(LOG_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      location: 'css-checker.ts',
      message: `CSS variable check: ${varName}`,
      data: { varName, hasValue: !!value, value: value || 'undefined' },
      timestamp: Date.now(),
      sessionId,
      runId,
      hypothesisId,
    }),
  }).catch(() => {});
}

/**
 * Check if Tailwind class is applied
 */
export function checkTailwindClass(element: HTMLElement | null, className: string, sessionId: string, runId: string, hypothesisId: string): void {
  if (!element) return;
  
  const hasClass = element.classList.contains(className);
  const computedStyles = getComputedStyle(element);
  
  fetch(LOG_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      location: 'css-checker.ts',
      message: `Tailwind class check: ${className}`,
      data: { className, hasClass, elementTag: element.tagName },
      timestamp: Date.now(),
      sessionId,
      runId,
      hypothesisId,
    }),
  }).catch(() => {});
}

/**
 * Run comprehensive CSS checks
 */
export function runCSSChecks(sessionId = 'debug-session', runId = 'run1'): void {
  if (typeof document === 'undefined') return;
  
  // Check SGDS green variables
  checkCSSVariable('--sgdsGreen', sessionId, runId, 'F');
  checkCSSVariable('--color-sgds-green', sessionId, runId, 'F');
  checkCSSVariable('--sgdsGreen-light', sessionId, runId, 'F');
  checkCSSVariable('--sgdsGreen-dark', sessionId, runId, 'F');
  
  // Check if navbar has green colors applied
  const navbar = document.querySelector('app-navbar');
  if (navbar) {
    const navbarElement = navbar.querySelector('header');
    if (navbarElement) {
      const styles = getComputedStyle(navbarElement);
      fetch(LOG_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          location: 'css-checker.ts',
          message: 'Navbar styles check',
          data: {
            backgroundColor: styles.backgroundColor,
            color: styles.color,
          },
          timestamp: Date.now(),
          sessionId,
          runId,
          hypothesisId: 'F',
        }),
      }).catch(() => {});
    }
  }
  
  // Check hero section
  const hero = document.querySelector('app-hero-section');
  if (hero) {
    const heroElement = hero.querySelector('section');
    if (heroElement) {
      const styles = getComputedStyle(heroElement);
      fetch(LOG_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          location: 'css-checker.ts',
          message: 'Hero section styles check',
          data: {
            backgroundColor: styles.backgroundColor,
            backgroundImage: styles.backgroundImage,
          },
          timestamp: Date.now(),
          sessionId,
          runId,
          hypothesisId: 'F',
        }),
      }).catch(() => {});
    }
  }
}
